"""
superfluid.qwen2_model — a minimal Qwen2 forward pass, in PyTorch.

WHY
---
The memory layer must be attachable to a REAL pretrained checkpoint.  The
project stays dependency-free (the numpy package never imports this
module); torch is needed only here and for `superfluid.torch_graft`.

This is the Qwen2 architecture, implemented directly from
`config.json` + `model.safetensors`:
  RMSNorm -> GQA attention with RoPE -> SwiGLU MLP, tied embeddings.

It is verified two ways:
  1. the model must GENERATE coherent English (it does);
  2. the graft must be a provable no-op on attach (bit-identical logits).

The `h_override` argument is the graft hook: it replaces the residual
stream after the embedding, exactly like `superfluid.gpt2_model`.
"""

from __future__ import annotations

import json
import math
import os

__all__ = ["Qwen2Model"]

import torch  # noqa: E402  (deliberately after the docstring, so the numpy
                         #  package never imports torch)


def _rms_norm(x, weight, eps: float):
    # the norm is computed in fp32: in bf16 the variance underflows
    dt = x.dtype
    xf = x.float()
    xf = xf * torch.rsqrt(xf.pow(2).mean(-1, keepdim=True) + eps)
    return (xf * weight.float()).to(dt)


class Qwen2Model:
    """A Qwen2 causal LM loaded from a local folder."""

    def __init__(self, path: str, dtype=torch.float32, device="cpu"):
        from safetensors.torch import load_file
        with open(os.path.join(path, "config.json"), encoding="utf-8") as f:
            cfg = json.load(f)
        self.cfg = cfg
        self.n_layer = cfg["num_hidden_layers"]
        self.n_head = cfg["num_attention_heads"]
        self.n_kv = cfg.get("num_key_value_heads", cfg["num_attention_heads"])
        self.n_embd = cfg["hidden_size"]
        self.head_dim = self.n_embd // self.n_head
        self.eps = cfg.get("rms_norm_eps", 1e-6)
        self.rope_theta = cfg.get("rope_theta", 10000.0)
        self.device = device
        self.dtype = dtype

        sd = load_file(os.path.join(path, "model.safetensors"))

        def g(name):
            return sd[name].to(device=device, dtype=dtype)

        self.wte = g("model.embed_tokens.weight")
        self.norm_w = g("model.norm.weight")
        # tie_word_embeddings -> lm_head IS the embedding matrix
        self.lm_head_w = g("lm_head.weight") if "lm_head.weight" in sd else self.wte
        self.layers = []
        for i in range(self.n_layer):
            p = f"model.layers.{i}."
            self.layers.append({
                "ln1": g(p + "input_layernorm.weight"),
                "ln2": g(p + "post_attention_layernorm.weight"),
                "q": g(p + "self_attn.q_proj.weight"),
                "k": g(p + "self_attn.k_proj.weight"),
                "v": g(p + "self_attn.v_proj.weight"),
                # Qwen2.5-0.5B DOES ship q/k/v biases (a checkpoint with
                # them is silently wrong without this: the logits come
                # out as noise).
                "q_bias": g(p + "self_attn.q_proj.bias") if (p + "self_attn.q_proj.bias") in sd else None,
                "k_bias": g(p + "self_attn.k_proj.bias") if (p + "self_attn.k_proj.bias") in sd else None,
                "v_bias": g(p + "self_attn.v_proj.bias") if (p + "self_attn.v_proj.bias") in sd else None,
                "o": g(p + "self_attn.o_proj.weight"),
                "gate": g(p + "mlp.gate_proj.weight"),
                "up": g(p + "mlp.up_proj.weight"),
                "down": g(p + "mlp.down_proj.weight"),
            })

    # ------------------------------------------------------------------ RoPE
    def _rope(self, T: int):
        dim = self.head_dim
        inv = 1.0 / (self.rope_theta ** (
            torch.arange(0, dim, 2, device=self.device, dtype=torch.float32) / dim))
        pos = torch.arange(T, device=self.device, dtype=torch.float32)
        freqs = torch.outer(pos, inv)                  # (T, dim/2)
        emb = torch.cat((freqs, freqs), dim=-1)         # (T, dim)
        cos = emb.cos()[None, None].to(self.dtype)
        sin = emb.sin()[None, None].to(self.dtype)
        return cos, sin

    @staticmethod
    def _apply_rope(x, cos, sin):
        # x: (B, H, T, D); the "rotate_half" convention Qwen2 uses
        d = x.shape[-1] // 2
        x1, x2 = x[..., :d], x[..., d:]
        rot = torch.cat((-x2, x1), dim=-1)
        return x * cos + rot * sin

    # --------------------------------------------------------------- forward
    def forward(self, ids, h_override=None, keep_last=False):
        """ids: (T,) int64 -> logits (T, V).

        `h_override` replaces the embedding output: the graft hook.
        `keep_last=True` returns only the logits of the final position:
        for a long context that is 40x less memory (the vocabulary is
        152k wide, so the full logits of a 2k-token window are 1.2 GB).
        """
        ids = torch.as_tensor(ids, dtype=torch.long, device=self.device)
        T = ids.shape[0]
        h = self.wte[ids]
        if h_override is not None:
            h = h_override
        cos, sin = self._rope(T)
        for L in self.layers:
            x = _rms_norm(h, L["ln1"], self.eps)
            q = x @ L["q"].T
            k = x @ L["k"].T
            v = x @ L["v"].T
            if L["q_bias"] is not None:
                q = q + L["q_bias"]
                k = k + L["k_bias"]
                v = v + L["v_bias"]
            q = q.view(1, T, self.n_head, self.head_dim).transpose(1, 2)
            k = k.view(1, T, self.n_kv, self.head_dim).transpose(1, 2)
            v = v.view(1, T, self.n_kv, self.head_dim).transpose(1, 2)
            q = self._apply_rope(q, cos, sin)
            k = self._apply_rope(k, cos, sin)
            if self.n_kv != self.n_head:            # grouped-query attention
                rep = self.n_head // self.n_kv
                k = k.repeat_interleave(rep, dim=1)
                v = v.repeat_interleave(rep, dim=1)
            att = torch.nn.functional.scaled_dot_product_attention(
                q, k, v, is_causal=True)
            att = att.transpose(1, 2).reshape(1, T, self.n_embd)
            h = h + (att @ L["o"].T)
            y = _rms_norm(h, L["ln2"], self.eps)
            y = torch.nn.functional.silu(y @ L["gate"].T) * (y @ L["up"].T)
            h = h + (y @ L["down"].T)
        h = _rms_norm(h, self.norm_w, self.eps)
        if keep_last:
            # (1, V): the callers treat the logits as a (T, V) matrix
            return (h[0, -1:] @ self.lm_head_w.T).float()
        return (h[0] @ self.lm_head_w.T).float()

    # ------------------------------------------------------------ generation
    @torch.no_grad()
    def generate(self, ids, n_new=20, temperature=0.0, seed=0, max_ctx=2048):
        ids = list(ids)
        for _ in range(n_new):
            window = ids[-max_ctx:]
            logits = self.forward(torch.tensor(window, dtype=torch.long,
                                               device=self.device))
            nxt = logits[-1]
            if temperature > 0:
                torch.manual_seed(seed)
                probs = torch.softmax(nxt / temperature, dim=-1)
                nxt = torch.multinomial(probs, 1)
            else:
                nxt = nxt.argmax(dim=-1)
            ids.append(int(nxt))
        return ids
