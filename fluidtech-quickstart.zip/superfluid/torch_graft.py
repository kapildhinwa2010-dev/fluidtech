"""
superfluid.torch_graft — the same memory layer, in PyTorch, for a REAL LLM.

This is the GPU-scale twin of `superfluid/graft.py`.  It exists because the
numpy implementation cannot be attached to a pretrained transformer: it
needs a *tied* embedding table to turn a stored token id back into a
vector, and it needs the model's own scales.

WHAT IS THE SAME AS THE NUMPY VERSION
-------------------------------------
* the two tiers: a lossy (diffusion) state and an exact, content-keyed
  store of token ids;
* the attach-is-a-no-op property: `Wo_exact` and `Wo_lossy` start at ZERO,
  so attaching the branch leaves the logits bit-identical;
* the read gain and the contrast transform (`pc1`), because with a tied
  readout a raw embedding injection boosts the token's embedding-space
  neighbours too;
* causality: the store is written from the pair (context ending at t-1,
  token at t), so a token is never read back before it was written.

WHAT IS DIFFERENT
------------------
* the state lives in a torch tensor (it can be a parameter, a buffer, or
  just an attribute);
* the writes are done under `no_grad` -- the layer is a MEMORY, and the
  exactness of the tier does not depend on differentiating through it;
* the contrast transform is computed once from the model's embedding table
  (on the right device) and can be refreshed after the model is trained.

NOT EXECUTED IN THIS SANDBOX
----------------------------
This module has NOT been run here: the development environment has no
torch, no GPU and 3 GB of RAM.  It is written to be read, reviewed and
run on a GPU box.  `experiments/gpu_graft.py` is the driver.
"""

from __future__ import annotations

import torch
import torch.nn as nn

__all__ = ["SAABranchTorch", "ctx_hash"]


def ctx_hash(tokens) -> int:
    """FNV-1a 64-bit hash of a token sequence (the content key)."""
    h = 0xCBF29CE484222325
    for t in tokens:
        h ^= int(t) & 0xFFFFFFFFFFFFFFFF
        h = (h * 0x100000001B3) & 0xFFFFFFFFFFFFFFFF
    return h


class SAABranchTorch(nn.Module):
    """The attachable memory layer (torch).

    Parameters
    ----------
    M, r, d   : anchors, rank, model width
    emb       : the model's input embedding matrix (tied or not).  Used to
                turn a stored token id back into a vector.
    ctx_len   : how many trailing tokens form the content key
    capacity  : max entries in the exact store
    read_gain : the scalar gain of the exact injection (CALIBRATE it; see
                the gain sweep in results/e6_graft.json)
    transform : "raw" | "center" | "pc1" -- the selectivity of the injection
    """

    def __init__(self, M: int = 64, r: int = 8, d: int = 64, emb=None,
                 ctx_len: int = 1, capacity: int = 8192, read_gain: float = 300.0,
                 transform: str = "pc1", use_exact: bool = True,
                 use_lossy: bool = False, seed: int = 0):
        super().__init__()
        g = torch.Generator().manual_seed(seed)
        self.M, self.r, self.d = int(M), int(r), int(d)
        self.ctx_len = int(ctx_len)
        self.capacity = int(capacity)
        self.read_gain = float(read_gain)
        self.transform = str(transform)
        self.use_exact, self.use_lossy = bool(use_exact), bool(use_lossy)

        self.protos = nn.Parameter(torch.randn(M, d, generator=g) * d ** -0.5)
        self.Wq = nn.Parameter(torch.randn(d, d, generator=g) * d ** -0.5)
        self.Wk = nn.Parameter(torch.randn(d, d, generator=g) * d ** -0.5)
        self.Wv = nn.Parameter(torch.randn(d, r, generator=g) * d ** -0.5)
        self.Wr = nn.Parameter(torch.randn(r, d, generator=g) * d ** -0.5)
        # ZERO => attaching the branch is an EXACT identity
        self.Wo_exact = nn.Parameter(torch.zeros(d, d))
        self.Wo_lossy = nn.Parameter(torch.zeros(d, d))

        self.emb = emb          # NOT a parameter: it belongs to the model
        self.state = torch.zeros(M, r)
        self.readonly = False       # the evaluation must NOT write
        self._last_retrieved: list = []
        self._last_router: list = []
        self.store: dict[int, int] = {}
        self.support: dict[int, int] = {}      # key -> times confirmed
        self.disagree: dict[int, int] = {}     # key -> times contradicted
        self.store_order: list[int] = []
        # the ROUTER tier: one majority continuation per anchor of the fluid
        self.anchor_store: dict[int, int] = {}
        self.anchor_support: dict[int, int] = {}
        self.anchor_disagree: dict[int, int] = {}
        self._buf: list[int] = []
        self._contrast = None

    # ------------------------------------------------------------- lifecycle
    def reset(self):
        self.state = torch.zeros_like(self.state)
        self.store.clear()
        self.support.clear()
        self.disagree.clear()
        self.store_order.clear()
        self.anchor_store.clear()
        self.anchor_support.clear()
        self.anchor_disagree.clear()
        self._buf.clear()

    def refresh_contrast(self):
        """Recompute the (optionally transformed) embedding table."""
        self._contrast = None

    def _contrast_table(self, device, dtype):
        if self._contrast is None:
            E = self.emb.weight if hasattr(self.emb, "weight") else self.emb
            E = E.detach().to(device=device, dtype=torch.float32)
            t = self.transform
            if t == "center":
                E = E - E.mean(0, keepdim=True)
            elif t.startswith("pc"):
                k = int(t[2:] or 1)
                # the principal directions via the covariance (d x d): cheap
                # even for a 50k vocabulary
                C = (E.T @ E) / max(E.shape[0], 1)
                w, V = torch.linalg.eigh(C)
                for j in torch.argsort(w, descending=True)[:k]:
                    p = V[:, j]
                    E = E - torch.outer(E @ p, p)
            self._contrast = E.to(dtype=dtype)
        return self._contrast

    def state_bytes(self) -> int:
        return self.state.numel() * 4 + len(self.store) * 20

    # ----------------------------------------------------------------- maths
    def _route(self, content: torch.Tensor):
        """content (T, d) -> soft top-k weights (T, M) and the argmax (T,)."""
        q = content @ self.Wq
        kk = self.protos @ self.Wk
        sc = (q @ kk.T) / (self.d ** 0.5)
        k = min(4, self.M)
        top = sc.topk(k, dim=-1).indices
        w = torch.zeros_like(sc)
        s = sc.gather(1, top)
        s = s - s.max(dim=-1, keepdim=True).values
        e = torch.softmax(s, dim=-1)
        w.scatter_(1, top, e)
        return w, top[:, 0]

    def _key(self, buf):
        if len(buf) < self.ctx_len:
            return None
        if self.ctx_len == 1:
            return int(buf[-1])
        return ctx_hash(buf[-self.ctx_len:])

    def _put(self, key: int, value: int):
        if key in self.store:
            if self.store[key] == value:
                self.support[key] = self.support.get(key, 1) + 1
            else:
                a = self.support.get(key, 1)
                b = self.disagree.get(key, 0) + 1
                if b > a:
                    self.store[key] = int(value)
                    self.support[key] = b
                    self.disagree[key] = a
                else:
                    self.disagree[key] = b
            return
        if len(self.store) >= self.capacity:
            self.store.pop(self.store_order.pop(0), None)
        self.store[key] = int(value)
        self.support[key] = 1
        self.disagree[key] = 0
        self.store_order.append(int(key))

    def _anchor_put(self, anchor: int, value: int):
        """The ROUTER tier: the pair is filed under the anchor of the
        previous position, so the fluid's geometry decides where a context
        belongs.  The MAJORITY is kept, exactly as in the numpy port."""
        if anchor in self.anchor_store:
            if self.anchor_store[anchor] == value:
                self.anchor_support[anchor] = self.anchor_support.get(anchor, 1) + 1
            else:
                a = self.anchor_support.get(anchor, 1)
                b = self.anchor_disagree.get(anchor, 0) + 1
                if b > a:
                    self.anchor_store[anchor] = int(value)
                    self.anchor_support[anchor] = b
                    self.anchor_disagree[anchor] = a
                else:
                    self.anchor_disagree[anchor] = b
            return
        self.anchor_store[anchor] = int(value)
        self.anchor_support[anchor] = 1
        self.anchor_disagree[anchor] = 0

    # ---------------------------------------------------------------- forward
    def forward(self, h: torch.Tensor, content: torch.Tensor,
                token_ids: torch.Tensor):
        """h, content: (T, d);  token_ids: (T,) int64."""
        T = token_ids.shape[0]
        ids = token_ids.detach().cpu().tolist()
        out_e = None
        hits = 0
        retrieved = torch.full((T,), -1, dtype=torch.long, device=h.device)
        support = torch.zeros(T, dtype=torch.long, device=h.device)
        router_retrieved = torch.full((T,), -1, dtype=torch.long, device=h.device)
        router_conf = torch.zeros(T, dtype=torch.float32, device=h.device)

        if self.use_exact and self.emb is not None:
            C = self._contrast_table(h.device, h.dtype)
            rows = torch.zeros(T, self.d, device=h.device, dtype=h.dtype)
            buf = list(self._buf)
            for t in range(T):
                prev_key = self._key(buf)
                buf.append(int(ids[t]))
                if len(buf) > self.ctx_len:
                    buf = buf[-self.ctx_len:]
                key = self._key(buf)
                v = self.store.get(key, -1)
                if v >= 0:
                    rows[t] = C[v] * self.read_gain
                    retrieved[t] = int(v)
                    support[t] = int(self.support.get(key, 1))
                    hits += 1
                if prev_key is not None and not self.readonly:
                    self._put(prev_key, int(ids[t]))
            self._buf = buf
            out_e = rows

        if self.use_lossy:
            with torch.no_grad():
                w, _ = self._route(content.detach())
                self.state = self.state + w.T @ (h.detach() @ self.Wv.detach())
                self.state = 0.9 * self.state        # a simple decay
            out_l = (w @ self.state) @ self.Wr
        else:
            out_l = None

        # THE ROUTER TIER.
        # The READ happens BEFORE the WRITES (the same snapshot semantics as
        # the numpy port): a position must never see a value that this very
        # window has just written.
        w_np, am = self._route(content.detach())
        for t in range(T):
            a = int(am[t])
            av = self.anchor_store.get(a, -1)
            if av >= 0:
                router_retrieved[t] = av
                s_a = self.anchor_support.get(a, 1)
                d_a = self.anchor_disagree.get(a, 0)
                router_conf[t] = s_a / max(s_a + d_a, 1)
        if not self.readonly:
            for t in range(1, T):
                self._anchor_put(int(am[t - 1]), int(ids[t]))

        h_out = h
        if out_e is not None:
            h_out = h_out + out_e @ self.Wo_exact
        if out_l is not None:
            h_out = h_out + out_l @ self.Wo_lossy
        self._last_retrieved = [int(v) for v in retrieved.tolist()]
        self._last_router = [int(v) for v in router_retrieved.tolist()]
        return h_out, {"hits": hits, "retrieved": retrieved,
                       "support": support,
                       "router_retrieved": router_retrieved,
                       "router_confidence": router_conf}

    # ------------------------------------------------------------- the gate
    def gated_logits(self, logits, info, gain: float = 8.0,
                     use_support: bool = False, support_scale: float = 1.0,
                     router_weight: float = 0.3, gate_space: str = "logit",
                     tau: float | None = None, c_min: float = 2.0,
                     big: float = 20.0):
        """Apply the retrieval as a GATED override, in logit space.

        The base model's OWN uncertainty at that position is the gate:

            u_t = 1 - max_v p(v)

        and the retrieved token's logit is boosted by  gain * u_t.

        One knob serves both use cases: in the recall task the model is
        clueless (u ~ 1) so the retrieval decides; in the generation task
        the model is usually confident (u ~ 0) so the retrieval is ignored.
        Measured (E10): the recall is unchanged (0.975) and the base
        model's perplexity IMPROVES by 0.145 nats at gain 8, where the
        ungated override would have cost +0.11 nats at the same gain.
        """
        retrieved = info.get("retrieved")
        if retrieved is None:
            return logits
        rr = info.get("router_retrieved")
        rconf = info.get("router_confidence")
        if rr is not None:
            fallback = (retrieved < 0) & (rr >= 0)
            retrieved = torch.where(fallback, rr, retrieved)
        else:
            fallback = torch.zeros_like(retrieved, dtype=torch.bool)
        if tau is None:
            tau = 2.0 if str(gate_space) != "logit" else 20.0
        p = torch.softmax(logits.float(), dim=-1)
        if str(gate_space) == "logit":
            # scale-free: how many nats the model is from being sure
            u = -torch.log(torch.clamp(p.max(dim=-1).values, min=1e-12))
        else:
            u = 1.0 - p.max(dim=-1).values
        boost = gain * u
        conf = info.get("confidence")
        if conf is None:
            conf = torch.zeros_like(u)
        else:
            conf = torch.as_tensor(conf, dtype=torch.float32, device=logits.device)
        decide = (u >= tau) | (conf >= c_min)
        boost = torch.where(decide, torch.full_like(boost, float(big)), boost)
        if rr is not None:
            rc = torch.clamp(torch.as_tensor(rconf, dtype=torch.float32,
                                             device=logits.device), 0.0, 1.0)
            boost = torch.where(fallback, boost * router_weight * rc, boost)
        if use_support:
            sup = info.get("support")
            if sup is not None:
                conf = torch.clamp(
                    torch.as_tensor(sup, dtype=torch.float32,
                                    device=logits.device) / support_scale,
                    max=1.0)
                boost = boost * conf
        out = logits.clone()
        rows = torch.nonzero(retrieved >= 0, as_tuple=False).squeeze(-1)
        if rows.numel():
            out[rows, retrieved[rows]] += boost[rows].to(out.dtype)
        return out
