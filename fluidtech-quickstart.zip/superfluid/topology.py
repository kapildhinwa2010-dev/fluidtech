"""
superfluid.topology — building the data's geometry in one forward pass.

This module implements the "instant geometry" of the proposal:

  1. content routing      -> semantic edges (top-k over QK similarity)
  2. temporal chain      -> order edges (position as 1-dimensional topology)
  3. 0-D persistence     -> exact barcode via union-find (Kruskal filtration)
  4. Betti numbers       -> beta_0 (components), beta_1 (cycle rank)

(3) and (4) are *exact*, not approximated, and cost O(m log m) — which is why
the geometry can be recomputed every forward pass instead of being cached
offline.  This is the concrete answer to "jam the data's geometry in one pass".
"""

from __future__ import annotations
import numpy as np

__all__ = [
    "route_topk", "edges_from_topk", "chain_edges", "unique_edges",
    "kruskal_barcode", "betti_numbers", "topo_descriptor",
    "connected_components",
    "hodge_relevance", "hodge_embedding", "hodge_edge_participation",
    "local_density", "persistence_landmarks",
]


# ------------------------------------------------------- selection criteria
def hodge_embedding(n: int, edges: np.ndarray, alpha: np.ndarray) -> np.ndarray:
    """The Hodge embedding  Psi = (L + (1/n) 11^T)^{-1}  of the signed sheaf
    Laplacian.  Psi_ij measures how strongly nodes i and j are coupled by the
    global (harmonic) structure of the complex."""
    from .sheaf import build_laplacian
    L = build_laplacian(n, edges, np.asarray(alpha, dtype=np.float64))
    A = np.ones((n, 1)) / np.sqrt(max(n, 1))
    try:
        return np.linalg.inv(L + A @ A.T)
    except np.linalg.LinAlgError:
        return np.linalg.pinv(L + A @ A.T)


def hodge_edge_participation(Psi: np.ndarray, a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Normalised Hodge participation of a SET OF NODE PAIRS, in [0, 1].

        part(a, b) = |Psi_ab| / sqrt(|Psi_aa| * |Psi_bb|)

    This is the quantity that says "these two cells of the complex belong
    together": it is 1 when they are the same cell, and it decays as the two
    cells drift apart in the global structure.  Used to score candidate
    (context, next-token) associations: a fact is a NEW association that the
    geometry says belongs together, a distractor is a new association that
    does not.
    """
    Psi = np.asarray(Psi, dtype=np.float64)
    a = np.asarray(a, dtype=np.int64)
    b = np.asarray(b, dtype=np.int64)
    num = np.abs(Psi[a, b])
    den = np.sqrt(np.maximum(np.abs(Psi[a, a]), 1e-18) *
                  np.maximum(np.abs(Psi[b, b]), 1e-18))
    return np.clip(num / den, 0.0, 1.0)


def hodge_relevance(n: int, edges: np.ndarray, alpha: np.ndarray) -> np.ndarray:
    """Per-node harmonic participation on the signed sheaf Laplacian.

    The Hodge embedding of a Laplacian is  Psi = (L + (1/n) 11^T)^{-1}, and
    the harmonic participation of node i is  hp_i = sum_{j != i} |Psi_ij|.
    A node with a large hp sits on many long-lived global structures; a node
    with hp ~ 0 is locally trivial.

    PRIOR ART NOTE: Hodge-based topological relevance for selecting points is
    not new -- see "Topologically Relevant Landmark Selection on Point
    Clouds", arXiv 2610.00019, which scores points by harmonic participation
    to choose PH landmarks.  What is new here is the APPLICATION: we use it
    to allocate the exact slots of a constant-size neural memory, where the
    quantity being budgeted is "how many bytes of exactness this fact gets",
    not "which points to subsample".

    Returns an (n,) array of non-negative scores.
    """
    Psi = hodge_embedding(n, edges, alpha)
    hp = np.abs(Psi).sum(axis=1) - np.abs(np.diag(Psi))
    return np.clip(hp, 0.0, None)


def local_density(protos: np.ndarray, radius: float | None = None,
                  k: int = 8) -> np.ndarray:
    """How crowded is each prototype's neighbourhood?  (n,) counts.

    Two flavours, both cheap and both computable ONCE per document:
      * `radius` given -> number of prototypes within Euclidean distance r.
      * otherwise -> effective neighbourhood size from the top-k cosine
        similarity:  sum_j sim_ij / max_j sim_ij  (in [1, k]).
    """
    P = np.asarray(protos, dtype=np.float64)
    n = P.shape[0]
    if radius is not None:
        D = np.sqrt(np.maximum(
            (P ** 2).sum(1)[:, None] + (P ** 2).sum(1)[None, :] - 2.0 * (P @ P.T), 0.0))
        return (D <= radius).sum(axis=1).astype(np.float64)
    Pn = P / (np.linalg.norm(P, axis=1, keepdims=True) + 1e-12)
    S = Pn @ Pn.T
    np.fill_diagonal(S, -np.inf)
    k = int(min(k, n - 1)) if n > 1 else 1
    part = np.partition(S, -k, axis=1)[:, -k:]
    mx = np.abs(part).max(axis=1, keepdims=True) + 1e-12
    return (np.abs(part) / mx).sum(axis=1)


def persistence_landmarks(n: int, edges: np.ndarray, weights: np.ndarray,
                          k: int = 10) -> np.ndarray:
    """Nodes whose topological class survives LONGEST in the Kruskal filtration.

    Implementation: replay the Kruskal merge order; whenever two components
    merge at weight w, every node in the merged component has its class
    "killed" at w.  The last such w for a node is its persistence, and
    nodes in the component that survives to the end have infinite
    persistence.  Ties are broken by node index, so the result is
    deterministic.

    Returns an (k,) array of node indices, most persistent first.
    """
    edges = np.asarray(edges, dtype=np.int64)
    weights = np.asarray(weights, dtype=np.float64)
    if edges.shape[0] == 0:
        return np.arange(min(k, n), dtype=np.int64)
    parent = list(range(n))
    members = {i: [i] for i in range(n)}

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    death = np.full(n, -np.inf, dtype=np.float64)
    order = np.argsort(weights, kind="stable")
    for e in order:
        u = int(edges[e, 0]); v = int(edges[e, 1]); w = float(weights[e])
        ru, rv = find(u), find(v)
        if ru == rv:
            continue
        w_nodes = members[ru] + members[rv]
        for x in w_nodes:
            death[x] = w
        if len(members[ru]) < len(members[rv]):
            ru, rv = rv, ru
        parent[rv] = ru
        members[ru] = members[ru] + members[rv]
        del members[rv]
    # nodes still in separate surviving components: mark them infinite
    for r in list(members):
        for x in members[r]:
            death[x] = np.inf
    order_nodes = np.lexsort((np.arange(n), -death))
    return order_nodes[:min(k, n)].astype(np.int64)


def connected_components(n: int, edges: np.ndarray):
    """Connected components of the undirected graph (union-find, O(m alpha(n))).

    Returns (labels, n_components).  The harmonic projection of a graph
    Laplacian is the per-component mean, so this is what the "frozen state"
    of the fluid actually is.
    """
    parent = list(range(n))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    for e in edges:
        ru, rv = find(int(e[0])), find(int(e[1]))
        if ru != rv:
            parent[rv] = ru
    roots = np.array([find(i) for i in range(n)])
    _, labels = np.unique(roots, return_inverse=True)
    return labels.astype(np.int64), int(labels.max()) + 1 if n else 0


# ------------------------------------------------------------------ routing
def route_topk(Q: np.ndarray, K: np.ndarray, k: int, causal: bool = True):
    """Top-k content routing.

    Q, K : (n, d) query / key projections
    Returns idx : (n, k) int neighbour indices (padded with self if exhausted),
            logits : (n, k) the corresponding similarity scores.
    """
    n = Q.shape[0]
    scores = Q @ K.T / np.sqrt(Q.shape[1])
    if causal:
        mask = np.triu(np.ones((n, n), dtype=bool), k=1)
        scores = np.where(mask, -np.inf, scores)
    k = int(min(k, n))
    idx = np.argpartition(-scores, kth=k - 1, axis=1)[:, :k]
    row = np.arange(n)[:, None]
    logits = scores[row, idx]
    # fix the ordering so that position 0 is the best match (not needed for
    # correctness, but keeps softmax numerics well behaved)
    order = np.argsort(-logits, axis=1)
    idx = np.take_along_axis(idx, order, axis=1)
    logits = np.take_along_axis(logits, order, axis=1)
    return idx, logits


def edges_from_topk(idx: np.ndarray) -> np.ndarray:
    """Unique undirected edges from a (n,k) neighbour index array."""
    n, k = idx.shape
    u = np.repeat(np.arange(n), k)
    v = idx.reshape(-1)
    mask = u < v                       # keep one orientation per pair
    u, v = u[mask], v[mask]
    if u.size == 0:
        return np.zeros((0, 2), dtype=np.int64)
    key = u.astype(np.int64) * n + v
    uniq, idx2 = np.unique(key, return_index=True)
    return np.stack([u[idx2], v[idx2]], axis=1)


def chain_edges(n: int) -> np.ndarray:
    """The temporal chain: edges (i, i+1). Order as 1-dimensional topology."""
    if n < 2:
        return np.zeros((0, 2), dtype=np.int64)
    return np.stack([np.arange(n - 1), np.arange(1, n)], axis=1)


def unique_edges(*edge_sets):
    """Union several edge lists, removing duplicates."""
    all_e = np.concatenate([e for e in edge_sets if e.size], axis=0)
    if all_e.size == 0:
        return np.zeros((0, 2), dtype=np.int64)
    u = np.minimum(all_e[:, 0], all_e[:, 1])
    v = np.maximum(all_e[:, 0], all_e[:, 1])
    key = u.astype(np.int64) * (int(max(u.max(), v.max())) + 1) + v
    _, keep = np.unique(key, return_index=True)
    return np.stack([u[keep], v[keep]], axis=1)


# ------------------------------------------------------------- persistence
def kruskal_barcode(n: int, edges: np.ndarray, weights: np.ndarray):
    """Exact 0-dimensional persistence barcode via the Kruskal filtration.

    Returns (pairs, beta0) where pairs is a list of (birth, death) with
    death = +inf for the component that survives to the end.
    """
    parent = list(range(n))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    m = edges.shape[0]
    if m:
        order = np.argsort(weights)
    birth = [0.0] * n
    pairs = []
    alive = 0
    for e in order:
        u = int(edges[e, 0]); v = int(edges[e, 1]); w = float(weights[e])
        ru, rv = find(u), find(v)
        if ru == rv:
            continue
        b = min(birth[ru], birth[rv])
        pairs.append((b, w))
        if birth[ru] > birth[rv]:
            ru, rv = rv, ru
        parent[rv] = ru
        birth[ru] = b
        alive += 1
    # surviving component
    roots = {find(i) for i in range(n)}
    for r in roots:
        pairs.append((birth[r], float("inf")))
    return pairs, len(roots)


def betti_numbers(n: int, edges: np.ndarray) -> dict:
    """beta_0 (components) and beta_1 (cycle rank) of the 1-dimensional complex."""
    m = edges.shape[0]
    parent = list(range(n))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    for e in edges:
        ru, rv = find(int(e[0])), find(int(e[1]))
        if ru != rv:
            parent[rv] = ru
    comps = len({find(i) for i in range(n)})
    beta1 = m - n + comps
    return {"beta0": comps, "beta1": int(max(beta1, 0)), "m": int(m), "n": int(n)}


def topo_descriptor(n: int, edges: np.ndarray, weights: np.ndarray) -> np.ndarray:
    """Fixed-length topological signature of the routed complex.

    [ beta0, beta1, sum finite lifetimes, max lifetime, mean lifetime,
      #bars longer than 1/4 of the max, #bars longer than 1/2 of the max,
      density (m/n), log(m) ]
    """
    b = betti_numbers(n, edges)
    pairs, _ = kruskal_barcode(n, edges, weights)
    finite = [(bb, dd) for bb, dd in pairs if np.isfinite(dd)]
    lifes = np.array([dd - bb for bb, dd in finite], dtype=np.float64)
    if lifes.size:
        mx = float(lifes.max())
        s = float(lifes.sum())
        mean = float(lifes.mean())
        n_long4 = int((lifes > 0.25 * mx).sum())
        n_long2 = int((lifes > 0.50 * mx).sum())
    else:
        mx = s = mean = 0.0
        n_long4 = n_long2 = 0
    return np.array([
        b["beta0"], b["beta1"], s, mx, mean, n_long4, n_long2,
        b["m"] / max(n, 1), np.log1p(b["m"]),
    ], dtype=np.float64)
