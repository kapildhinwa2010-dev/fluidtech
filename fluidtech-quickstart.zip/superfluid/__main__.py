"""
python -m superfluid -- run the self-verification checks.

The whole point of this project is that the claims are machine-checked, and
that you can check them yourself without installing anything:

    python -m superfluid
    python -m superfluid --selftest
"""

from __future__ import annotations

import os
import sys


def main() -> int:
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    st = os.path.join(here, "selftest.py")
    if not os.path.exists(st):
        sys.stderr.write("selftest.py not found next to the package\n")
        return 2
    sys.path.insert(0, here)
    import runpy
    runpy.run_path(st, run_name="__main__")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
