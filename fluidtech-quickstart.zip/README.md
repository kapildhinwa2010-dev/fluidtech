# fluidtech-quickstart

The six files, ready to use.

| file | what it is |
|---|---|
| `examples/appkit/load_model.py` | **only the model loading** — drop it into your app |
| `examples/appkit/attach_layer.py` | **paste it below `load_model.py`** — the layer attaches and every test runs |
| `experiments/e15_scale_model.py` | the E15 code (Qwen2.5-0.5B, the scale ladder) |
| `results/e15_scale_model.json` | the E15 results |
| `docs/PROCESS.md` | the whole process: the design, every experiment, every bug, every negative |
| `superfluid/` + `superfluid_single.py` | the layer package (numpy-only) and the single-file bundle |

## Run it

```bash
pip install numpy
python selftest.py                                  # 50/50

# the real model (torch is optional, only for the model)
pip install torch --index-url https://download.pytorch.org/whl/cpu
python tools/download_hf.py Qwen/Qwen2.5-0.5B --out models/qwen05b

python examples/appkit/load_model.py                # the model
python examples/appkit/attach_layer.py --model models/qwen05b   # the layer + the tests
python experiments/e15_scale_model.py --model models/qwen05b    # the full experiment
```

## The measured result (Qwen2.5-0.5B)

```
the attach            : bit-identical (max abs diff 0.000e+00)
the capability        : a fact 1411 tokens back -> the base predicts 146187,
                        the LAYER predicts the fact
the perplexity        : the base 32.58 -> 31.39 with the layer (gain 1.0)
                        (the appkit's own corpus slice)
the kNN-LM baseline   : on the E15 protocol, the base 42.28 -> 32.14 with the
                        kNN-LM interpolation, against 40.57 with the layer
                        -- the interpolation wins the perplexity on a strong
                        model (see N11 and N12 in docs/NEGATIVE-RESULTS.md)
```
