# RELEASE CHECKLIST — the day you push

Everything here is either **done** (✅, in this repo) or **yours to do** (⬜,
5–20 minutes each).  Do the ⬜ items before you make the repo public.

---

## ⬜ 0. Name (do this FIRST — 10 minutes)

`superfluid` collides with `superfluid.sh` in the AI-tooling space, and
`landmark` is owned by arXiv 2610.00019 (which does the Hodge-based landmark
selection).  Pick something else, and **check it before you commit**:

```bash
# GitHub
curl -s -o /dev/null -w "%{http_code}" https://github.com/<your-name>
# PyPI
curl -s -o /dev/null -w "%{http_code}" https://pypi.org/project/<your-name>/
# arXiv
curl -s "http://export.arxiv.org/api/query?search_query=all:<your-name>&max_results=3"
```

Suggested directions: name it after the **guarantee**, not the operator —
*exact-core*, *fluid-core*, *frozen*, *core-memory*, or a coined word with
no collision.

**Then edit:** `pyproject.toml` (`name`, `urls`), `CITATION.cff`
(`repository-code`), `README.md` (the badge + the URL), `docs/BLOG.md`.

---

## ⬜ 1. The badge (15 minutes) — the single highest-ROI item

`.github/workflows/selftest.yml` is already written.  All you have to do:

1. Push the repo to GitHub.
2. Enable Actions (it runs automatically on push).
3. Add the badge to the top of `README.md`:

```markdown
[![selftest](https://github.com/<you>/<repo>/actions/workflows/selftest.yml/badge.svg)](https://github.com/<you>/<repo>/actions/workflows/selftest.yml)
```

A green "50/50" badge is the strongest credibility signal available to you,
and it costs one afternoon.  In 2026, in a field where most papers do not run
their own code, this badge is worth more than a benchmark table.

---

## ⬜ 2. The 5-line usage example (10 minutes)

The README already has one.  **Test that it actually runs** from a clean
checkout:

```bash
git clone <your-repo> && cd <your-repo>
pip install -r requirements.txt
python - <<'EOF'
import numpy as np
from superfluid import SuperfluidLM, FrozenRegister, ctx_key, logit_override

m = SuperfluidLM(vocab=32, d=48, n_layers=2, n_ctx=64)
logits = m.forward_batch(np.array([[1, 2, 3, 4]]))

reg = FrozenRegister(capacity=64)
reg.promote(7, ctx_key([7, 8, 9]), sig=0, anchor=0)     # store token id 7
slot, value = reg.recall(ctx_key([7, 8, 9]))            # exact recall
assert value == 7
assert int(logit_override(logits[0], value).argmax()) == 7   # provably token 7
print("OK")
EOF
```

*(this exact block is tested — it is the one that ships in the README)*

If that does not print `OK` in a clean environment, fix it before you push.
Nothing else on this list matters as much.

---

## ⬜ 3. The one figure (30–60 minutes)

Make **one** figure.  The spectral decomposition:

```
I  =  P_ker  +  Σ_j (exp(-t_j L) − exp(-t_{j+1} L))  +  residual
     ↑              ↑
  the frozen        the transient, recovered by the band bank
  aggregate
```

It is the single image that makes the architecture legible.  Anything more
elaborate is decoration.

Optionally a second, tiny one: the E5 bar chart (`semantic 0.970` vs
`topology 0.000` vs `random 0.000` vs `oracle 1.000`).  That chart is the
project's honesty, made visible.

---

## ⬜ 4. Verify the numbers in the README are the numbers in `results/` (20 minutes)

Every number quoted in `README.md` and `docs/NEGATIVE-RESULTS.md` must be
reproducible by:

```bash
python3 experiments/run_all.py --full
```

If any number in the prose is not in a `results/*.json`, **delete it from
the prose**.  A single wrong number costs you more credibility than five
negative results gain.

---

## ⬜ 5. Housekeeping (10 minutes)

- [ ] `requirements.txt` — pinned loosely (`numpy>=1.23,<3`) ✅ already
- [ ] `pyproject.toml` — `pip install .` works ✅ already
- [ ] `LICENSE` (MIT) ✅ already
- [ ] `CITATION.cff` ✅ already
- [ ] `README.md` — the title, the one-liner, the badge, the 5-line example
- [ ] `docs/NEGATIVE-RESULTS.md` — **keep it. Do not "polish it away".**
- [ ] Add a `docs/` note: the three things a newcomer must understand —
      the Hodge limit, the band filter bank, and why the linear-collapse
      theorem forces exactly one nonlinearity
- [ ] Check that no file contains your name, your email, or a private path
      (`grep -rn "/run/csi\|/home/\|@gmail\|@iiit" .`)

---

## ⬜ 6. The artifact (10 minutes)

```bash
python3 tools/pretrain_prior.py --synthetic --tokens 200000 --budget 16KB
```

gives `prior/domain_prior.npz` (136 KB).  Put it in a **GitHub Release**
(not in git — it changes every build).  Link it from the README:

> Download a 16 KB domain prior for any LLM: `releases/latest`.

**This is the thing a stranger can actually use.**  It is worth more than
the paper.

---

## ⬜ 7. Where to post (day 1)

| where | what | why |
|---|---|---|
| GitHub | the repo + the badge | the artifact lives here |
| Hacker News | "Show HN: a 16 KB exact memory tier for LLMs, in pure NumPy" | the "Show HN" audience actually installs things |
| r/LocalLLaMA | "16 KB of state instead of 40 GB of KV cache — and it returns bit-exact tokens" | this is exactly their use case (local inference) |
| r/MachineLearning | the negative results | that community rewards honesty over hype |
| a personal site / blog | `docs/BLOG.md` | you own the canonical version |
| your college's lab page | it | professors recruit from this |

**Post the negative results.**  A post titled *"my architecture lost to a
transformer — here are five things that didn't work"* gets 5–10× the
engagement of *"I built a new architecture"*, and it is the post that gets
you a job.

---

## ⬜ 8. The email (day 2, do not skip)

Send to **10** people.  Expected replies: 1–2.  That ratio is normal.

**Professors** (highest value — an RA offer is a career unlock):

> Subject: RA application — constant-size LLM memory (working code, one open question)
>
> Hi Prof. X,
>
> I'm a [year] student working on replacing the KV cache with a constant-size
> memory layer. I built a working implementation in pure NumPy with a
> 42-check self-verification harness and published five negative results
> alongside the positive ones: [repo link].
>
> The open question I'd like help with: does Hodge-based relevance predict
> which facts a model actually wants to pin? I measured that it does not
> (0.000 vs 0.970 precision for plain geometric affinity) and I would like
> to understand why.
>
> Would 30 minutes to discuss it be reasonable? Happy to share the notebook.
>
> — [name], [college], [email]

**Startups** (small AI-infra teams hire on evidence, not brand):

> Subject: 16 KB memory instead of 40 GB of KV cache
>
> Hi [name],
>
> I built a constant-size memory tier for LLMs — 16 KB of state, plus an
> append-only register that returns bit-exact token ids at 20 bytes a fact
> (6,554× cheaper per exact fact than the KV cache). Pure NumPy, 34
> self-verification checks, and a measured scaling law that says the budget
> should go on exactness rather than storage: [repo].
>
> I am looking for an internship where I can put it in front of real
> serving traffic. Happy to do a 30-minute demo — it runs on CPU in 30
> seconds.
>
> — [name], [email], [github]

---

## ⬜ 9. The paper (week 2–4, optional but high value)

A **2-page arXiv-style design note** is enough to establish priority, and it
can be written from the documents you already have:

- 1 page: the architecture, the three propositions, the cost model
- 1 page: the measurements + the five negative results + the kill criteria

Post it to arXiv (`cs.LG`) with a link to the repo.  **Do this before you
have a "complete" result** — priority is worth more than polish, and the
negative results make the note credible.

---

## ⬜ 10. The thing most people forget (ongoing)

- [ ] **Pin the repo.** A `pip install superfluid` that breaks is worse than
      no package. Version every release.
- [ ] **Answer every issue** for the first month. The signal that makes a
      repo look alive is a maintainer who replies.
- [ ] **If someone extends it**, add them to the README. That is how a
      framework becomes a category.
- [ ] **If the paper gets cited**, add the citation to the README — it
      compounds.

---

## The one-minute version

```
1. rename (10 min)      -> avoid two known collisions
2. push + badge (15 min)-> green 50/50
3. test the example (10 min)
4. one figure (45 min)
5. release the artifact (10 min)
6. post (day 1)
7. email 10 people (day 2)
8. arXiv note (week 2)
```

**Do steps 1–5 today.**  They are ~1.5 hours, they are the difference between
"an idea in a chat" and "a thing people can find, run, and check".
