# PLAN — 6 weeks, ~2h/day, zero prior art required

> **Read this instead of DESIGN-pinned-memory.md / COMPARISON.md / POSITIONING.md.**
> Those three are for the repo and for reviewers. You do not need them.
> You need **3 deliverables** and **1 number**.

---

## 0. The project in one sentence (memorise this)

> **A 16 KB "memory layer" you can bolt onto any LLM. It remembers a million-token
> document in constant space, and for the ~1,000 most important facts it
> remembers them *bit-exactly* — at 14 bytes per fact instead of 2.6 MB.**

Everything else is detail. If you can explain that sentence in 30 seconds to
a stranger, you understand your own project.

---

## 1. The 3 deliverables (ignore everything else)

| # | deliverable | why it's the one | GPU? |
|---|---|---|---|
| **D1** | `memory.py` — the frozen register + logit override | the thing that makes "exact" true | ❌ CPU |
| **D2** | **E5** — 1M-token doc, 16 KB, exact extraction, measured | your **first real result** | ❌ CPU |
| **D3** | **Gate-1** — 7B/70B: fluid+register vs full-KV on needle retrieval | your **headline number** | ✅ ~$3 |

> **D2 is the one that matters most and it needs no GPU.** If you only finish
> D1 + D2 you still have a real, publishable, demo-able result.

---

## 2. Week-by-week

### Week 1 — D1: the frozen register
- [ ] `FrozenRegister` class: append-only, 8-byte ctx-key + 4-byte token id + 2-byte trust
- [ ] `promote(token_id, ctx)` → slot; `recall(slot)` → exact token id
- [ ] **logit override**: `next_logit[token_id] = +inf` → argmax is *provably* that token
- [ ] collision check on read → fall back, never silently wrong
- [ ] 5 new checks in `selftest.py` → target **26/26**

**Done means:** `python3 selftest.py` prints `26/26 checks passed`.

### Week 2 — D2: the result (CPU only, no GPU)
- [ ] build a synthetic 1M-token corpus (repeat a base text; vary the "needles")
- [ ] run the fluid over it (token-wise, streaming) → 16 KB state
- [ ] promote N facts (N = 100, 500, 1,000)
- [ ] measure **exact extraction accuracy** vs baselines:
  - random promotion (the control — *this is the one that matters*)
  - no register (fluid only)
  - full-KV upper bound (= 100 %, costs 131 GB → that **is** the headline)
- [ ] **table + one figure**

**Done means:** a table with a row for each baseline and one honest sentence
about whether topology-selection beat random. *(If it didn't — say so. That's a
result too, and it's the reason the project is trustworthy.)*

### Week 3 — D3: the headline (≈ $3 of GPU)
- [ ] rent **A100 80GB** on Vast.ai spot (~$0.33–0.39/hr) or **H100 PCIe** (~$0.67/hr)
- [ ] run a 7B (or 70B-in-4bit) model on a needle-retrieval task at 32K → 128K ctx, two arms:
  - **arm A:** full KV cache (the status quo)
  - **arm B:** 2K sliding window + 16 KB fluid + register
- [ ] measure: accuracy, peak VRAM, sessions/GPU, tok/s

**Done means:** one number pair, e.g. *"same 95 % needle accuracy at 16 KB vs
16 GB — 1,000× less memory, 65× more sessions."*

**Budget: 4 GPU-hours ≈ $1.50–2.70. That's the whole experiment. Not $300.**

### Week 4 — make it visible (this is where job value is created)
- [ ] GitHub: rename the repo (NOT "superfluid" — collision), LICENSE, `requirements.txt`
- [ ] **CI badge**: GitHub Actions running `selftest.py` → green "26/26"
- [ ] README: the one-sentence claim, the 5-line usage example, the results table, the **negative result**
- [ ] one figure: `I = P_ker + Σ bands + residual` (the spectral decomposition)
- [ ] a 700-word blog post → post it (X / LinkedIn / personal site)
- [ ] a 2-page arXiv-style design note (theory + measurements + kill criteria) → establishes priority

### Weeks 5–6 — the actual job hunt (don't skip!)
- [ ] resume bullet (see below) — one line, measurable
- [ ] **cold-email 30–50 AI-infra / research-engineering startups** (small teams hire on evidence, not brand)
- [ ] **email 5–10 professors** working on efficient attention / memory / topology → ask for an RA role
- [ ] **one real OSS PR** to vLLM / SGLang / transformers / llama.cpp. *A merged PR there beats your own repo.*
- [ ] apply to roles titled: *AI infra engineer, research engineer, inference optimization, applied scientist (early career)*

---

## 3. Your resume bullet (use this verbatim)

> **Designed and open-sourced a constant-size (16 KB) geometry-addressed memory
> layer for LLMs** — pure NumPy, 21/21 self-verification checks; demonstrated
> **65× higher KV-cache serving concurrency** and **bit-exact fact extraction at
> 14 B/fact** (196,234× cheaper than a KV cache); **published a negative result**
> on LM quality rather than hiding it.

That bullet does four things at once: *shipped*, *measured*, *quantified*, *honest*.
Most new-grad resumes do **none** of those.

---

## 4. What to say in the interview (the real asset)

Not "I invented a new architecture." Say this:

> *"I built a constant-size memory layer for LLMs and had to write my own
> autodiff and test harness in NumPy, because I wanted every claim to be
> re-verifiable. It caught 10 real bugs in my own code — sign errors, a Chebyshev
> recurrence missing a factor of 2, a scatter op that never scattered. The
> headline result is a 65× serving improvement, and I also published the case
> where my method loses to a plain transformer. The thing I'm proudest of isn't
> the result, it's that anyone can run `selftest.py` and check me."*

**That answer works in every interview, for any role, even if the project
later turns out to be wrong.** It demonstrates: ownership, rigour, honesty,
and the ability to finish. Those four get students hired.

---

## 5. The email to a professor (keep it under 150 words)

> **Subject:** RA application — constant-size LLM memory (working code, one open question)
>
> Hi Prof. X,
>
> I'm a [year] student working on replacing the KV cache with a constant-size
> memory layer. I built a working implementation in pure NumPy with a 21-check
> self-verification harness and published a negative result alongside the
> positive one: [repo link].
>
> The open question I'd like help with: [one specific question — e.g. "does
> Hodge-based relevance predict which facts a model actually wants to pin?"].
>
> Would 30 minutes to discuss it be reasonable? Happy to share the notebook.
>
> — [name], [college], [email]

Send to **10** professors. Expect 1–2 replies. That is a normal, good ratio —
and one RA offer is worth more than the whole project.

---

## 6. What to ignore while you're in weeks 1–3

| ignore | why |
|---|---|
| `docs/DESIGN-pinned-memory.md` | it's the *design*; you don't need to re-read it to code |
| `docs/COMPARISON.md` | it's for the README; the numbers are already settled |
| `docs/POSITIONING.md` | it's for after week 4, when you're writing the paper |
| "revolutionary vs not" | not a week-1–3 question. It is a week-4 question. |
| scaling curves, G0/G1/G2, 3 SKUs | later. Ship D1+D2 first. |

**Your only question for the next 14 days is:**
> *"Can I pull an exact token out of a 1M-token document using 16 KB?"*

Everything else is downstream of that.

---

## 7. The two questions I need from you

1. **Which year are you in** (and when's your placement season)? → decides the timeline
2. **Do you have GPU access** (college lab / Colab / can you spend $5)? → decides
   whether D3 runs in week 3 or week 5
