# PLAN — the Superfluid Memory Graft
### One constant-size layer that replaces the KV cache, and attaches to *any* LLM

> **Status:** design note, not yet implemented. Every number below is computed,
> not estimated by feel. Implementation estimate: 1–2 days on the existing
> framework (`superfluid/` already contains 80 % of the primitives).

---

## 0. The idea, and the one correction it needs

**The idea as stated:** the transformer is bottlenecked by the KV cache; the
Superfluid fluid has a *constant* state (16 KB); therefore build **one layer**
that holds only that state, in place of the KV cache, and graft it onto any
LLM.

**The correction:** the KV cache and the Superfluid state are addressed
*differently*, and that difference is the whole point:

| | KV cache | Superfluid state |
|---|---|---|
| indexed by | **position** (token #1373) | **geometry** (the corpus's topological neighbourhood) |
| holds | **instance-specific** facts of *this* sequence | **distributional** facts of the *corpus* |
| grows with | context length | never |

A 16 KB state therefore **cannot** replace instance memory: at 70B scale, the
KV cache carries ~2.6 MB *per token*, so a constant 16 KB is throwing away
~5 orders of magnitude of instance information. Any claim that it can hold
"the token at position 1373" is false by counting.

**But that is exactly why the idea is good.** Position-addressed and
geometry-addressed memory are *complementary*, and today's LLMs only have the
first. So the target is not "replace the KV cache" but:

> **A second, geometry-addressed memory — distributional, constant-size,
> graftable onto any LLM without touching its weights or its attention.**

This is the deployment target already sketched in `docs/FRAMEWORK.md` §9; this note
makes it concrete.

---

## 1. Why the KV cache is the right target (measured)

| model | d | L | KV/token | @32K ctx | @1M ctx | vs 16 KB |
|---|---|---|---|---|---|---|
| Llama-3-8B | 4096 | 32 | 0.52 MB | 17.2 GB | 0.52 TB | 32× |
| Qwen2.5-32B | 5120 | 64 | 1.31 MB | 42.9 GB | 1.31 TB | 80× |
| Llama-3-70B | 8192 | 80 | 2.62 MB | 85.9 GB | **2.62 TB** | 160× |
| GPT-4 class | 12288 | 96 | 4.72 MB | 154.6 GB | 4.72 TB | 288× |

Decode is *memory-bandwidth* bound: at 70B the cache must be streamed at
2.6 MB **per token per layer**. The Superfluid state's read is
`2·r·d + 2·M·d_route` bytes — three orders of magnitude less, and **constant**.

---

## 2. The graft architecture ("Sheaf-Attention Adapter", SAA)

### 2.1 The theoretical bridge: attention *is* a Hopfield network

Modern Hopfield networks (Ramsauer et al., 2020) and transformer attention are
the same object — associative retrieval with a soft kernel:

```
attention :  out = softmax(Q Kᵀ/β) V          ← retrieve from a GROWING V
Hopfield  :  out = softmax(Q Kᵀ/β) Xᵀ A X    ← retrieve from a FIXED matrix A
```

So: **keep the query, replace the key/value set with a fixed set of anchors,
and change the metric from a dot product to a sheaf-Laplacian one.** That is
the entire graft, and it drops into any LLM because every transformer
architecture has the same residual stream.

### 2.2 The module

```
state  S ∈ R^{M×r}          M anchors, r dims per anchor   (16 KB, CONSTANT)
graph  K : (M nodes, E edges)  fixed simplicial complex, corpus-level
codebook C ∈ R^{M×d_route}  routing keys (frozen, ~70 KB with d_route=64)

WRITE (per token t):
    a        = topk_route(h_t, C)                  # k anchors this token touches
    S        = e^{-tL_K} ( S + Σ_{j∈a} u_j ⊗ v(h_t) )  # sheaf-diffused write
READ:
    out      = S[a_t]  ⊗  W_v h_t   →  W_o out
    h_t      = h_t + out
```

The diffusion is the *only* structural difference from a learned-KV
compression: **a write does not stay in the anchor it landed in — it spreads
along the corpus geometry.** Two tokens that topologically co-occur share
state capacity; two that never co-occur do not. That is the prior that a
position-indexed cache cannot express.

### 2.3 Cost (d = 8192, M = 1024, r = 8, k = 16, m = 24)

| stage | flops/token |
|---|---|
| route (d_route = 64) | 131,072 |
| write (scatter r-dim into k anchors) | 2,304 |
| **sheaf diffusion over the anchor graph** | 393,216 |
| read (gather + project to d) | 262,144 |
| **TOTAL** | **788,736** |
| one transformer layer (for reference) | 1.74 × 10⁹ |

**The Superfluid memory layer costs 0.045 % of a single transformer layer.**
You can afford ~2,200 of them inside one layer's budget. This is the single
most important number in the plan: the memory is not a compromise on compute,
it is essentially free — which means you can put several of them at *different
depths* and give each a different topology scale.

---

## 3. Three graft protocols (pick by how much you are willing to train)

| | what trains | cost | what you get |
|---|---|---|---|
| **G0** training-free | nothing | minutes | a static *domain prior*: the model's own corpus statistics, injected into the residual stream. Usable as a downloadable artifact. |
| **G1** adapter-only | the SAA (1–5 M params) | hours on domain data | the model learns to *use* the geometric memory; the LLM is frozen |
| **G2** full retrain | LLM + SAA, from a checkpoint | the real cost | the model internalises the geometry — the strongest version, and the one that could beat MLA on long context |

**G0 is the interesting product.** Because the state is 16 KB and the codebook
is ~70 KB, a *domain prior* is a file you can download:

> `domain-prior-code.safetensors` — 16 KB state + 70 KB codebook.
> Plug it into any LLM. No fine-tune, no weight changes.

---

## 4. The honest capability table

| capability | full KV cache | 16 KB SAA | verdict |
|---|---|---|---|
| needle retrieval ("copy token #1373") | exact | ✗ lossy | **needs a small position-indexed window** |
| long-range collocation ("what usually follows X") | ✓ but expensive | ✓ **this is its home turf** | SAA wins |
| decode memory | O(n) → 2.6 TB @1M | **O(1) → 16 KB** | SAA wins decisively |
| long-context perplexity | ✓ | partial, needs training | G1/G2 |
| perplexity on domain text | ✓ | G0 may already help | test it |
| exact copying / arithmetic | ✓ | ✗ | never delegate this to it |

**The honest architecture is two memories:**

```
[ P-memory ]  small sliding window of K,V   (position-indexed, exact, needles)
[ G-memory ]  Superfluid SAA, 16 KB         (geometry-indexed, distributional)
```

…with the split chosen per task. A 1M-token document that must be *queried*
("what did the contract say about clause 47?") needs P-memory or a tool;
a 1M-token document that must be *understood* ("summarise this codebase")
may be served largely by G-memory.

---

## 5. Falsifiable experiments (each < 1 GPU-day)

| # | experiment | pass criterion | what it kills |
|---|---|---|---|
| **E1** | G0 on a domain corpus (protein sequences, code, legal text): perplexity of a frozen LLM with vs without the prior | > 0.02 nats improvement | the whole "domain prior as a file" product |
| **E2** | G1 vs MLA (DeepSeek-style latent KV) vs Infini-attention on long-context QA at equal memory budget (16 KB) | SAA ≥ MLA on *distributional* questions; both ≈ 0 on needles | the SAA-vs-MLA thesis |
| **E3** | G2: finetune a 1B model with SAA in the loop, measure loss vs context length 4K→128K | SAA's long-context curve flatter than the transformer's | the "topology is a useful prior" thesis |
| **E4** | G-balance probe: does the learned sheaf become G-balanced? does λ₂ predict the quality of long-context retrieval? | correlation > 0.5 | the *mechanistic* story (the "why" of the framework) |

**Kill criteria:** if E2 shows SAA is dominated by MLA at equal budget *and*
G1 gives nothing over a plain learned-KV compression of the same size, then
the topology is decoration and the honest write-up is "a learned KV
compressor with extra steps" — a real, but much smaller, contribution.

---

## 6. Prior art this must be positioned against (honesty section)

| work | relation |
|---|---|
| **DeepSeek-V2 MLA** | compresses KV into a low-rank latent — *position*-indexed. SAA is *geometry*-indexed and constant-size. Complementary, not competing. |
| **Infini-attention** (Google, 2024) | constant-size memory with a learned delta-rule. The closest competitor; SAA's difference is the *diffusion on a topological graph* instead of a position-indexed delta rule. |
| **Mamba-2 / state-space models** | constant state, but position-ordered and geometry-free. |
| **Landmark attention** (NeurIPS 2023) | learns a small fixed set of landmark vectors to approximate attention. **Structurally the same idea** (fixed keys/values), but the landmark set is *learned in isolation*; SAA's anchors carry a topological structure that determines how writes spread. This is the closest prior art and must be cited. |
| **StreamingLLM / attention sinks** | keeps a few sink tokens + a window — the position-indexed part of the two-memory design. |
| **KV cache quantization / LoLCATs** | lossy compression of the existing cache; requires fine-tuning, and remains O(n). |

---

## 7. Implementation plan (1–2 days on the existing framework)

1. `superfluid/memory.py` — `SheafMemoryAdapter`: anchor codebook, fixed
   complex, write/read, and the state buffer. Reuses `diffusion.cheb_coeffs_exp`
   (band filter bank) and `topology.connected_components` (harmonic branch).
2. `superfluid/blocks.py` — add a `SAA` mode to `SuperfluidBlock` (or a thin
   wrapper) so the same block serves both the full model and the graft.
3. `tools/pretrain_prior.py` — build a domain prior: run a corpus through a
   frozen LLM, accumulate anchor statistics, write a 16 KB state + codebook.
4. `experiments/e1_graft.py` — E1 (G0 perplexity), then E2 (G1 vs MLA vs
   Infini) and E4 (G-balance probe).
5. Hook the adapter into a HuggingFace Llama/Qwen checkpoint via a forward
   hook on the residual stream — **no model surgery**: the graft is one
   `h = h + W_o·SAA(h)` insertion, which is why it attaches to *any* LLM.

**Risks, stated up front**

* The 16 KB state is genuinely lossy — a needle test will fail. Any framing
  that promises otherwise is dishonest.
* G0 may do nothing on general-domain text; the geometry only pays where the
  corpus has structure (code, molecules, legal, scientific text).
* The literature (see §6) is closer to this than it first appears. The
  defensible novelty is **the sheaf metric and its spreading rule**, not
  "constant-size memory".
* Everything above is design. E1 is cheap and decides whether E2 is worth
  running.
