# LAUNCH — what the grafted layer does, and what open-sourcing it does to you

> Companion to `docs/PLAN-memory-graft.md`. Part 1: the capability ledger.
> Part 2: the honest GitHub strategy, including what happens if it fails.

---

# PART 1 — What the grafted layer can actually do

## 1.1 The one thing it does better than anything else

**Constant-memory decode.** The state is 16 KB and never grows, so the
per-token, per-layer memory traffic of the model drops from
`2·d·2·L` bytes (2.6 MB at 70B) to `2·r·d + 2·M·d_route` (≈ 0.4 MB) and, on
the long-range path, to **zero** — no cache to stream, nothing to page, nothing
to shard.

Concretely, at 70B / 1M context:

| | full KV cache | grafted SAA |
|---|---|---|
| memory at 1M ctx | 2.62 TB per sequence | 16 KB |
| per-token decode read | 2.6 MB × 80 layers | 0 on the long-range path |
| multi-tenant serving (10k tenants @32K) | 859 TB | 160 MB of states |
| growth with context | linear | constant |

**This is the only claim in the whole project that is already true by
construction.** Everything else is a bet on E1–E4.

## 1.2 Capability ledger, tiered by confidence

### Tier A — works by construction (no experiment needed)

| capability | why it holds |
|---|---|
| O(1) decode memory | the state is a fixed buffer |
| ~2,200 memory layers per transformer layer's budget | 0.045 % of a layer's FLOPs |
| plug into *any* LLM | one residual-stream insertion; no surgery, no KV rewiring |
| per-tenant / per-user memory | states are independent buffers, swappable at inference |
| zero per-tenant training | the state is written, not optimised |

### Tier B — plausible, needs E1/E3

| capability | hypothesis | test |
|---|---|---|
| domain prior improves a frozen LLM's perplexity | the geometry carries collocation statistics the weights do not | E1 |
| long-context loss curve flattens with the memory in the loop | distributional context substitutes for some of the KV cache | E3 |
| a learned sheaf becomes G-balanced, and λ₂ predicts long-context quality | the mechanism story of the whole framework | E4 |

### Tier C — real but bounded

| capability | bound |
|---|---|
| geometry-indexed associative retrieval | lossy; no exact needles |
| continual learning without touching weights | writes only — cannot unlearn, and saturates slowly (the harmonic branch keeps it alive) |
| memory poisoning resilience | the contraction bound ‖e^(−tL)‖ = e^(−tλ₂) limits a single write's blast radius; it does not prevent poisoning |

### The "cannot" list — do not let anyone (including you) overclaim

- exact needle retrieval ("token #1373")
- verbatim copying, arithmetic, code execution
- per-user facts that must be exact — 16 KB is a *prior*, not a database
- anything that must be **proved** — distributional, not deductive

## 1.3 What the topology buys over a learned-KV compressor (the real differentiator)

1. **Spreading.** A write lands in one anchor and *diffuses along the corpus
   geometry* → generalises to combinations never seen together.
2. **Certified stability.** `‖e^(−tL)‖ = e^(−tλ₂) < 1` is a worst-case bound on
   how far one write can move the state. A learned compressor has no bound.
3. **No dead memory.** The harmonic branch (per-component mean) keeps a
   slowly-updating aggregate alive, so the memory does not saturate.
4. **Inspectable.** The persistence diagram of the anchor complex tells you
   what the memory *believes* the domain looks like — 16 KB of self-describing
   structure.

## 1.4 The product framing that follows from the numbers

| artifact | size | vs LoRA adapter | vs full finetune | vs KV cache @32K |
|---|---|---|---|---|
| domain-prior file (16 KB state + 70 KB codebook) | **86 KB** | 1,667× smaller | 1,706,984× smaller | 1,048,576× smaller |

> *"Download a 16 KB memory of your domain. Plug it into any LLM. No
> fine-tuning, no gradient steps, no weight changes."*

That is a shippable artifact, and it is the one thing in this project that a
reviewer can hold in their hand.

---

# PART 2 — Putting it on GitHub: what actually happens to you

## 0.0 What changed after the measurements (read this first)

The implementation is done and measured, and **five results came out negative
or against expectation** (see `docs/NEGATIVE-RESULTS.md`):

| what we expected | what happened |
|---|---|
| topology selects the facts | **no** — 0.000 vs 0.970 for plain geometric affinity |
| `‖L·1‖∞` detects the frozen state | **no** — the frustration index does; fixed + tested |
| λ₂ predicts long-context quality | **barely** — pearson 0.20 |
| a transformer loses at some scale | it **wins** at every scale we could train |
| a domain prior beats a frequency table | it **helps** (0.006 nats) but the unigram table wins 6× more |

**The launch plan does not change; the CLAIM does.**  The project is
positioned as *"exact-where-it-matters memory with a certified bound, an
append-only audit trail, and a published account of five things that did not
work"* — not as a new attention replacement.  The negative results are the
credibility asset, not a liability.

## 2.1 The realistic upside

**Establishing priority.** In research, the first public artifact with a name
and a date usually gets the citation. The cost of being second is the whole
paper. The cost of publishing is a few days. The asymmetry is enormous — this
is the single strongest argument for publishing *now*.

**A differentiator that is cheap to be first at.** Almost everyone is piling
into "attention + more layers + more data". A *different architecture family*
with a verified, runnable, numpy-only implementation is rare. And the
verification is the moat: your repo prints `21/21 checks passed` and every
claim in it is machine-checked. That is unusually rare in this field, and it
is much harder to copy than the idea itself.

**Extension compounding.** Frameworks get extended by other people. If someone
builds a Torch port, a sparse backend, or a molecule-domain variant, *your*
repo is the root of that tree. This is how LoRA, Mamba and xformers turned
into categories.

## 2.2 The realistic risks, ranked

| risk | likelihood | damage | mitigation |
|---|---|---|---|
| **"This is just MLA / Infini-attention / landmark attention"** | **high** | review-rejection unless answered | position the contribution as *the sheaf metric + the spreading rule*, cite landmark attention explicitly, and let E2's measurement speak |
| **A big lab does it better, with GPUs** | medium | you become a footnote | publish fast; ship the *artifact* (the 86 KB prior file) that is hard to reproduce, not just the idea |
| **E1 shows the topology is decoration** | medium | the project shrinks to a negative result | the repo already contains the kill criteria — publish that too; a clean negative result is citable and it protects your credibility for the next idea |
| **Slop-detection**: someone runs it and it breaks | low (it self-verifies) | high | keep the CI green, pin numpy, and never claim a number the JSON does not contain |
| **Naming collision** (`superfluid.sh` already exists in the AI tooling space) | certain | SEO confusion, possible trademark friction | check availability and pick a distinct project name; `Superfluid` is also common in the physics-ML literature |
| **Scope creep** — you keep adding features instead of measuring | high | never ships E1 | the launch is gated on E1 only |
| **IP/employment** | varies | serious | if employed, check your contract; if a student, get your advisor's sign-off **before** publishing |

## 2.3 The most underrated asset: the negative result is already in the repo

Your LM A/B says the **transformer wins at small scale** (2.633 vs 2.740
nats, despite 39 % fewer parameters on your side), and the mechanism test
says the **fluid wins on global aggregation** (97.3 % vs 65–71 % for local
aggregators). Most repos would hide the first number. Publishing it is the
single best credibility lever you have: it signals that every other number in
the repo is trustworthy. A reviewer who sees "we also report where we lose"
will read the rest of the claims much more carefully — and more generously.

## 2.4 Pre-publish checklist (do these before the first public push)

- [ ] **CI on GitHub Actions** running `python3 selftest.py` — a green
      "21/21" badge on the README. This is the strongest credibility signal
      available to you and it costs 20 minutes.
- [x] `requirements.txt` (numpy only) + `pyproject.toml` so `pip install` works.
- [x] `LICENSE` (MIT) + `CITATION.cff` ✅ written
- [x] `.github/workflows/selftest.yml` — the CI that earns the green badge ✅ written
- [ ] A **5-line usage example** at the top of the README (build a model, run a
      forward pass, print the loss).
- [ ] A **Results** section with the measured JSON numbers — the mechanism
      table, the LM table, the 21 checks — and the kill criteria.
- [ ] `LICENSE` (Apache-2.0 or MIT) + a `CITATION.cff` + a short
      `paper/` note (a 2-page arXiv-style design note with the plan, the
      theory, and the measurements — enough to establish priority *now*, with
      the full paper later).
- [ ] **Name check** before you create the repo. `superfluid` is taken in the
      AI tooling space; pick something else (a scoped repo name is fine, but
      the project name should be distinct).
- [ ] A `docs/` page explaining the three things a newcomer must understand:
      the Hodge limit, the band filter bank, and why the linear-collapse
      theorem forces exactly one nonlinearity.
- [ ] One figure: the spectral decomposition `I = P_ker + Σ bands + residual`.
      It is the single image that makes the architecture legible.
- [ ] A second, tiny figure: the E5 bar chart (semantic 0.970 / topology
      0.000 / random 0.000 / oracle 1.000).  That chart IS the project's
      honesty, made visible.

## 2.5 A 14-day launch plan

| day | what | why it matters |
|---|---|---|
| 1–2 | CI, requirements, 5-line example, LICENSE, CITATION.cff, name | removes every reason for a visitor to bounce |
| 3 | the one figure + a 700-word README that states the claim, the mechanism, **and the negative result** | this is the artifact that gets shared |
| 4–5 | arXiv-style 2-page design note (theory + measurements + kill criteria) | establishes priority; a design note is publishable while the full paper is not |
| 6 | public push: Hacker News, r/MachineLearning, r/LocalLLaMA, the topology/TDA communities, the alignment of people working on SSM/KV-compression | the people who would *use* this are the ones who must see it |
| 7–8 | **E1** — domain prior + perplexity, on a free GPU (Colab/Kaggle) | this is the gate: if E1 fails, the project pivots to a negative-result paper |
| 9–11 | **E2** — SAA vs MLA vs Infini at equal 16 KB budget | the comparison that decides the thesis |
| 12–13 | **E4** — G-balance probe + λ₂ vs long-context quality | this is the *mechanistic* result; it is what makes the project a theory and not a trick |
| 14 | v1.0 release + a blog post titled honestly | — |

## 2.6 What to do if E1 fails

Do not disappear. Publish it as: *"A topological memory layer: what it can
and cannot do."* with the mechanism result (97.3 %), the negative LM result,
and the E1 null. Then the repo becomes a **tool** others extend — and tools
get cited long after papers stop being read. In practice the framework's
value may end up being the *measurement harness* (21 checks + 4 falsifiable
experiments + a one-file bundle) rather than the architecture itself. Plan for
that outcome: it is a good one.

## 2.7 The one-line positioning statement

> *Attention remembers by position. A sheaf memory remembers by geometry:
> 16 KB, constant, and attachable to any LLM.*

Use that line. It is the version that survives contact with a reviewer.
