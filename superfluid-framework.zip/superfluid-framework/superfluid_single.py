#!/usr/bin/env python3
"""Generated single-file entry point for the Superfluid package."""

import os
import sys
import types

_SOURCES = r'''
#--- FILE: superfluid/__init__.py ---
"""
superfluid — a topological "fluid" architecture for sequence models.
Core idea
Replace the transformer's dense attention with a cellular sheaf diffusion:
X(t) = exp(-t L_F) X(0),      L_F = delta^T delta   (sheaf Laplacian)
The fluid "freezes" the data's geometry onto the space of global sections
(the Hodge limit).  A multi-scale band filter bank recovers the transient,
a top-k route head restores sharp retrieval, and a single pointwise
nonlinearity keeps the model from collapsing to a linear map.
Second idea: the EXACT tier
A diffusion smears, so an exact value must never live inside one.  The
`memory` module splits the memory in two:
L1  FROZEN REGISTER -- an append-only, write-once table of exact facts
(20 bytes each).  The value is an INTEGER token id, so a recall is
bit-exact rather than approximate.
L2  SUPERFLUID STATE -- a constant-size (M x r) state that carries the
aggregate.  It never grows, no matter how much is streamed through it.
L3  an external source -- a 6-byte pointer, unbounded, costs a call.
The two tiers are separate on purpose: the fluid answers WHERE, the register
answers WHAT.
"""
from .autodiff import Tensor, concat, softmax_rows, softplus
from .blocks import RMSNorm, SuperfluidBlock
from .diffusion import (
                    apply_bands,
                    band_energies,
                    band_times,
                    cheb_basis,
                    cheb_coeffs_exp,
                    cheb_degree,
                    exact_exp_action,
                    jam_time,
                    power_iteration_lmax,
                    spectral_gap,
                    spectral_summary,
)
from .graft import GRAFT_STATE_BYTES, SAABranch, ctx_hash
from .losses import (
                    band_decorrelation,
                    cross_entropy,
                    cross_entropy_grad,
                    cross_entropy_tensor,
)
from .memory import (
                    SLOT_BYTES,
                    FrozenRegister,
                    SheafMemoryAdapter,
                    budget_split,
                    ctx_key,
                    embedding_signature,
                    fnv1a64,
                    logit_override,
)
from .model import SuperfluidLM, TinyTransformer
from .sheaf import (
                    balance_residual,
                    build_laplacian,
                    component_balance,
                    is_balanced,
                    laplacian_from_dense_A,
                    sheaf_energy,
)
from .topology import (
                    betti_numbers,
                    chain_edges,
                    connected_components,
                    edges_from_topk,
                    hodge_edge_participation,
                    hodge_embedding,
                    hodge_relevance,
                    kruskal_barcode,
                    local_density,
                    persistence_landmarks,
                    route_topk,
                    topo_descriptor,
                    unique_edges,
)

__version__ = "1.2.0"
version = __version__

__all__ = [
    "SAABranch", "GRAFT_STATE_BYTES", "ctx_hash",
    "Tensor", "concat", "softmax_rows", "softplus",
    "build_laplacian", "sheaf_energy", "balance_residual", "is_balanced",
    "laplacian_from_dense_A", "component_balance",
    "power_iteration_lmax", "cheb_coeffs_exp", "cheb_basis",
    "apply_bands", "band_energies", "spectral_gap", "jam_time",
    "cheb_degree", "exact_exp_action", "spectral_summary",
    "band_times",
    "route_topk", "edges_from_topk", "chain_edges", "unique_edges",
    "kruskal_barcode", "betti_numbers", "topo_descriptor",
    "connected_components",
    "hodge_relevance", "hodge_embedding", "hodge_edge_participation",
    "local_density", "persistence_landmarks",
    "SuperfluidBlock", "RMSNorm", "SuperfluidLM", "TinyTransformer",
    "cross_entropy", "cross_entropy_grad", "cross_entropy_tensor",
    "band_decorrelation",
    # --- the exact tier -------------------------------------------------
    "FrozenRegister", "SheafMemoryAdapter", "logit_override", "budget_split",
    "ctx_key", "fnv1a64", "embedding_signature", "SLOT_BYTES",
]

#--- FILE: superfluid/autodiff.py ---
"""
superfluid.autodiff — a tiny reverse-mode automatic differentiation engine.

Pure NumPy, ~1 op set, enough to train the Superfluid stack end-to-end inside
this sandbox (no torch available).  Every op has a hand-written backward and
is verified against finite differences in `selftest.py`.

Design: each Tensor holds `data`, `grad`, its parent Tensors and a closure
`_backward` that pushes gradient contributions into the parents.  The graph is
rebuilt every forward pass; parameter leaves accumulate `.grad` across the
traversal (zero them between steps).
"""

from __future__ import annotations

import numpy as np

_SQRT_PI = np.sqrt(np.pi)


def _unbroadcast(g: np.ndarray, shape: tuple) -> np.ndarray:
    """Reduce a broadcasted gradient back to `shape`."""
    if g.shape == shape:
        return g
    # sum over broadcast axes
    while g.ndim > len(shape):
        g = g.sum(axis=0)
    for i, s in enumerate(shape):
        if s == 1 and g.shape[i] != 1:
            g = g.sum(axis=i, keepdims=True)
    return g.reshape(shape)


class Tensor:
    __slots__ = ("data", "grad", "parents", "op", "_backward", "requires_grad")

    def __init__(self, data, parents=(), op="", requires_grad=True):
        self.data = np.array(data, dtype=np.float64, copy=True)
        self.grad = np.zeros_like(self.data)
        self.parents = tuple(parents)
        self.op = op
        self.requires_grad = requires_grad
        self._backward = None

    # -------------------------------------------------------------- plumbing
    @property
    def shape(self):
        return self.data.shape

    def _apply(self, data, op, parents, backward):
        out = Tensor(data, parents=parents, op=op)
        out._backward = backward
        return out

    def __repr__(self):
        return f"Tensor(shape={self.data.shape}, op={self.op})"

    # ------------------------------------------------------------ arithmetic
    def __add__(self, other):
        o = other if isinstance(other, Tensor) else Tensor(other, requires_grad=False)
        out = self._apply(self.data + o.data, "+", (self, o), lambda: None)

        def bw():
            g = out.grad
            if self.requires_grad:
                self.grad += _unbroadcast(g, self.data.shape)
            if o.requires_grad:
                o.grad += _unbroadcast(g, o.data.shape)
        out._backward = bw
        return out

    __radd__ = __add__

    def __sub__(self, other):
        o = other if isinstance(other, Tensor) else Tensor(other, requires_grad=False)
        neg = o.data
        out = self._apply(self.data - neg, "-", (self, o), lambda: None)

        def bw():
            g = out.grad
            if self.requires_grad:
                self.grad += _unbroadcast(g, self.data.shape)
            if o.requires_grad:
                o.grad += _unbroadcast(-g, o.data.shape)
        out._backward = bw
        return out

    def __rsub__(self, other):
        o = other if isinstance(other, Tensor) else Tensor(other, requires_grad=False)
        return o - self

    def __mul__(self, other):
        o = other if isinstance(other, Tensor) else Tensor(other, requires_grad=False)
        out = self._apply(self.data * o.data, "*", (self, o), lambda: None)

        def bw():
            g = out.grad
            if self.requires_grad:
                self.grad += _unbroadcast(g * o.data, self.data.shape)
            if o.requires_grad:
                o.grad += _unbroadcast(g * self.data, o.data.shape)
        out._backward = bw
        return out

    __rmul__ = __mul__

    def __truediv__(self, other):
        o = other if isinstance(other, Tensor) else Tensor(other, requires_grad=False)
        out = self._apply(self.data / o.data, "/", (self, o), lambda: None)

        def bw():
            g = out.grad
            if self.requires_grad:
                self.grad += _unbroadcast(g / o.data, self.data.shape)
            if o.requires_grad:
                o.grad += _unbroadcast(-g * self.data / (o.data ** 2), o.data.shape)
        out._backward = bw
        return out

    def __rtruediv__(self, other):
        o = other if isinstance(other, Tensor) else Tensor(other, requires_grad=False)
        return o / self

    def __neg__(self):
        return self * -1.0

    def __pow__(self, p):
        p = float(p)
        out = self._apply(self.data ** p, "pow", (self,), lambda: None)

        def bw():
            if self.requires_grad:
                self.grad += out.grad * p * (self.data ** (p - 1))
        out._backward = bw
        return out

    def __matmul__(self, other):
        o = other if isinstance(other, Tensor) else Tensor(other, requires_grad=False)
        out = self._apply(self.data @ o.data, "@", (self, o), lambda: None)

        def bw():
            g = out.grad
            if self.requires_grad:
                self.grad += g @ o.data.T
            if o.requires_grad:
                o.grad += self.data.T @ g
        out._backward = bw
        return out

    # --------------------------------------------------------------- shapes
    def reshape(self, *shape):
        if len(shape) == 1 and isinstance(shape[0], (tuple, list)):
            shape = tuple(shape[0])
        old = self.data.shape
        out = self._apply(self.data.reshape(shape), "reshape", (self,), lambda: None)

        def bw():
            self.grad += out.grad.reshape(old)
        out._backward = bw
        return out

    @property
    def T(self):
        return self.transpose()

    def transpose(self):
        out = self._apply(self.data.T, "T", (self,), lambda: None)

        def bw():
            self.grad += out.grad.T
        out._backward = bw
        return out

    def __getitem__(self, key):
        out = self._apply(self.data[key], "getitem", (self,), lambda: None)

        def bw():
            g = out.grad
            src = np.zeros_like(self.data)
            k = key
            # --- strip newaxis (None) entries: they only add output axes ---
            if isinstance(k, tuple):
                pos = [i for i, kk in enumerate(k) if kk is None]
                for p in reversed(pos):
                    g = np.squeeze(g, axis=p)
                k = tuple(kk for kk in k if kk is not None)
                if len(k) == 1:
                    k = k[0]
            if isinstance(k, tuple):
                has_arr = any(isinstance(kk, np.ndarray) for kk in k)
                if not has_arr:
                    src[k] += g                      # pure basic indexing
                else:
                    arrs = [kk for kk in k if isinstance(kk, np.ndarray)]
                    bshape = np.broadcast_shapes(*[kk.shape for kk in arrs])
                    idx_arrays = []
                    for _, kk in enumerate(k):
                        if isinstance(kk, np.ndarray):
                            idx_arrays.append(np.broadcast_to(kk, bshape))
                        else:
                            idx_arrays.append(kk)    # slices/ints kept as-is
                    np.add.at(src, tuple(idx_arrays), g)
            elif isinstance(k, np.ndarray):
                np.add.at(src, k, g)
            elif k is None:                      # x[None]
                src[...] = g.reshape(self.data.shape)
            else:
                src[k] += g
            self.grad += src
        out._backward = bw
        return out

    def gather_rows(self, idx):
        """out[i, j] = self[idx[i, j]]   (self is (n, d), idx is (n, k) -> (n, k, d))"""
        out = self._apply(
            self.data[idx], "gather_rows", (self,), lambda: None
        )

        def bw():
            np.add.at(self.grad, idx, out.grad)
        out._backward = bw
        return out

    # ------------------------------------------------------------ reductions
    def sum(self, axis=None, keepdims=False):
        out = self._apply(
            self.data.sum(axis=axis, keepdims=keepdims),
            "sum",
            (self,),
            lambda: None,
        )

        def bw():
            g = out.grad
            if axis is not None and not keepdims:
                g = np.expand_dims(g, axis)
            self.grad += np.broadcast_to(g, self.data.shape).copy()
        out._backward = bw
        return out

    def max(self, axis=None, keepdims=False):
        am = np.argmax(self.data, axis=axis, keepdims=True)
        out = self._apply(
            np.max(self.data, axis=axis, keepdims=keepdims),
            "max",
            (self,),
            lambda: None,
        )
        mask = np.zeros_like(self.data, dtype=bool)
        np.put_along_axis(mask, am, True, axis=axis)

        def bw():
            g = out.grad
            if axis is not None and not keepdims:
                g = np.expand_dims(g, axis)
            self.grad += g * mask
        out._backward = bw
        return out

    def mean(self, axis=None, keepdims=False):
        n = self.data.size if axis is None else self.data.shape[axis]
        s = self.sum(axis=axis, keepdims=keepdims)
        return s * (1.0 / n)          # do NOT override s._backward: the mul
                                       # backward already routes out.grad -> s.grad

    def square(self):
        return self * self

    def abs(self):
        out = self._apply(np.abs(self.data), "abs", (self,), lambda: None)

        def bw():
            self.grad += out.grad * np.sign(self.data)
        out._backward = bw
        return out

    def exp(self):
        out = self._apply(np.exp(self.data), "exp", (self,), lambda: None)

        def bw():
            self.grad += out.grad * out.data
        out._backward = bw
        return out

    def log(self):
        out = self._apply(np.log(self.data), "log", (self,), lambda: None)

        def bw():
            self.grad += out.grad / self.data
        out._backward = bw
        return out

    def sqrt(self):
        out = self._apply(np.sqrt(self.data), "sqrt", (self,), lambda: None)

        def bw():
            self.grad += out.grad * 0.5 / out.data
        out._backward = bw
        return out

    def tanh(self):
        out = self._apply(np.tanh(self.data), "tanh", (self,), lambda: None)

        def bw():
            self.grad += out.grad * (1 - out.data ** 2)
        out._backward = bw
        return out

    def erf(self):
        out = self._apply(0.5 * (1 + _erf_np(self.data)), "erf", (self,), lambda: None)

        def bw():
            self.grad += out.grad * (2.0 / _SQRT_PI) * np.exp(-self.data ** 2)
        out._backward = bw
        return out

    def relu(self):
        out = self._apply(np.maximum(self.data, 0.0), "relu", (self,), lambda: None)

        def bw():
            self.grad += out.grad * (self.data > 0)
        out._backward = bw
        return out

    def gelu(self):
        out = self._apply(
            0.5 * self.data * (1 + _erf_np(self.data / np.sqrt(2.0))),
            "gelu",
            (self,),
            lambda: None,
        )

        def bw():
            x = self.data
            cdf = 0.5 * (1 + _erf_np(x / np.sqrt(2.0)))
            pdf = np.exp(-0.5 * x ** 2) / np.sqrt(2 * np.pi)
            self.grad += out.grad * (cdf + x * pdf)
        out._backward = bw
        return out

    # --------------------------------------------------------------- scatter
    def index_add(self, idx, src):
        """out = zeros_like(self.data) with src scattered into rows idx.

        The scatter MUST happen in the forward pass too -- an earlier version
        returned zeros here, which silently turned every Laplacian built with
        this op into the zero matrix (and the whole fluid into a no-op).
        """
        out_data = np.zeros_like(self.data)
        np.add.at(out_data, idx, src.data)
        out = self._apply(out_data, "index_add", (self, src), lambda: None)

        def bw():
            # out = base + scatter(src, idx)  =>  d/d(src) = out.grad[idx]
            src.grad += out.grad[idx]
            self.grad += out.grad             # d/d(base): base is the zero base
        out._backward = bw
        return out

    def gather(self, idx):
        """out[i] = self[idx[i]]"""
        out = self._apply(self.data[idx], "gather", (self,), lambda: None)

        def bw():
            src = np.zeros_like(self.data)
            np.add.at(src, idx, out.grad)
            self.grad += src
        out._backward = bw
        return out

    # ----------------------------------------------------------------- misc
    def pow(self, p):
        return self ** float(p)

    def backward(self, seed=None):
        """Reverse-mode backward pass.

        If `seed` is given it overwrites the output gradient.  Otherwise the
        output gradient is seeded with ones *only if it is still all zeros*
        (so an externally supplied gradient, e.g. dCE/dlogits, is respected).
        """
        if seed is not None:
            self.grad = np.array(seed, dtype=np.float64, copy=True)
        elif not np.any(self.grad):
            self.grad = np.ones_like(self.data)
        topo, seen = [], set()

        def build(t):
            if id(t) in seen:
                return
            seen.add(id(t))
            for p in t.parents:
                build(p)
            topo.append(t)

        build(self)
        for t in reversed(topo):
            if t._backward is not None:
                t._backward()

    def zero_grad(self):
        self.grad = np.zeros_like(self.data)


def softplus(t: Tensor) -> Tensor:
    """log(1 + exp(t)), numerically stable for large |t|."""
    return (1.0 + t.exp()).log()


def _erf_np(x: np.ndarray) -> np.ndarray:
    """Vectorised erf (Abramowitz & Stegun 7.1.26 is too weak; use tanh form)."""
    sign = np.sign(x)
    ax = np.abs(x)
    p = 0.3275911
    a1, a2, a3, a4, a5 = (
        0.254829592,
        -0.284496736,
        1.421413741,
        -1.453152027,
        1.061405429,
    )
    t = 1.0 / (1.0 + p * ax)
    y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * np.exp(-ax * ax)
    return sign * y


def concat(tensors, axis=0):
    datas = [t.data for t in tensors]
    out = Tensor(np.concatenate(datas, axis=axis), parents=tuple(tensors), op="concat")

    def bw():
        sizes = [d.shape[axis] for d in datas]
        idx = 0
        for t, s in zip(tensors, sizes):
            sl = [slice(None)] * out.data.ndim
            sl[axis] = slice(idx, idx + s)
            t.grad += out.grad[tuple(sl)]
            idx += s
    out._backward = bw
    return out


def stack(tensors, axis=0):
    datas = [t.data for t in tensors]
    out = Tensor(np.stack(datas, axis=axis), parents=tuple(tensors), op="stack")

    def bw():
        for i, t in enumerate(tensors):
            sl = [slice(None)] * out.data.ndim
            sl[axis] = i
            t.grad += out.grad[tuple(sl)]
    out._backward = bw
    return out


def softmax_rows(x: Tensor, mask: np.ndarray | None = None) -> Tensor:
    """Row-wise softmax with optional additive -1e9 mask (mask=True -> masked)."""
    z = x.data if mask is None else np.where(mask, -1e9, x.data)
    z = z - z.max(axis=-1, keepdims=True)
    e = np.exp(z)
    if mask is not None:
        e = np.where(mask, 0.0, e)
    s = e.sum(axis=-1, keepdims=True)
    p = e / s
    out = x._apply(p, "softmax", (x,), lambda: None)

    def bw():
        g = out.grad
        dot = (g * p).sum(axis=-1, keepdims=True)
        x.grad += p * (g - dot)
    out._backward = bw
    return out

#--- FILE: superfluid/sheaf.py ---
"""
superfluid.sheaf — Cellular sheaf Laplacians on graphs.

The mathematical object that makes "Superfluid" real.

A cellular sheaf F on a graph G assigns:
  * a stalk (vector space) F(v) ~ R^d  to every vertex v
  * a restriction map  F_{v<-e} : F(v) -> F(e)  to every incidence (v, e)

Its coboundary  delta : C^0(G;F) -> C^1(G;F)  induces the **sheaf Laplacian**

    L_F = delta* delta = delta^T delta      (PSD by construction)

and the diffusion (the "fluid") is the heat flow on that operator:

    dX/dt = -L_F X      =>      X(t) = exp(-t L_F) X(0)

Two facts we rely on throughout (Hansen & Ghrist 2019; Bodnar et al. 2022):

1.  lim_{t->inf} exp(-t L_F) = P_{ker(L_F)}      (the Hodge limit: the fluid
    freezes onto the space of *global sections* -- consistent assignments).
2.  On ker(L_F)^perp the flow contracts at rate exp(-lam_2 t).

Implementation note: we use the **signed** sheaf Laplacian with absolute degree

    L = D_abs - A ,   D_abs[i,i] = sum_j |A[i,j]| ,   A[i,j] = alpha_ij

which is PSD for any sign pattern, reduces to the ordinary graph Laplacian
when all signs are positive, and reproduces the G-balance phase transition:
a *balanced* signed component freezes onto a NON-TRIVIAL sign pattern,
an *unbalanced* one decays to zero (it "evaporates" instead of freezing).
"""

from __future__ import annotations

import numpy as np

__all__ = [
    "build_laplacian", "sheaf_energy", "balance_residual", "is_balanced",
    "laplacian_from_dense_A", "signed_laplacian_from_edges",
]


def build_laplacian(n: int, edges: np.ndarray, alpha: np.ndarray) -> np.ndarray:
    """Signed sheaf Laplacian L = D_abs - A.

    edges : (m, 2) int array of undirected edges (u, v), u != v
    alpha : (m,) float array of signed edge weights (the restriction maps)
    Returns L : (n, n) symmetric PSD.
    """
    L = np.zeros((n, n), dtype=np.float64)
    if edges.shape[0] == 0:
        return L
    u = edges[:, 0].astype(np.int64)
    v = edges[:, 1].astype(np.int64)
    w = np.asarray(alpha, dtype=np.float64)

    # A contribution (symmetric)
    np.add.at(L, (u, v), w)
    np.add.at(L, (v, u), w)
    # D_abs: sum of |A[i,j]| over j
    absA = np.zeros_like(L)
    np.add.at(absA, (u, v), np.abs(w))
    np.add.at(absA, (v, u), np.abs(w))
    diag = absA.sum(axis=1)
    L = np.diag(diag) - L          # L = D_abs - A   (PSD)
    return L


def laplacian_from_dense_A(A: np.ndarray) -> np.ndarray:
    """L = D_abs - A for a dense symmetric A."""
    A = np.asarray(A, dtype=np.float64)
    A = 0.5 * (A + A.T)
    D = np.diag(np.abs(A).sum(axis=1))
    return D - A


def signed_laplacian_from_edges(
    n: int, edges: np.ndarray, alpha: np.ndarray
) -> np.ndarray:
    """Alias kept for readability at call sites."""
    return build_laplacian(n, edges, alpha)


def sheaf_energy(x: np.ndarray, edges: np.ndarray, alpha: np.ndarray) -> float:
    """Total variation of the field across the sheaf edges.

    E = sum_e  alpha_e^2 * (x_u - x_v)^2      (scalar stalk; x is (n,) or (n,d))

    This is the quantity the "smoothness" regularizer anneals toward, and it
    is exactly x^T L x / 2 for the signed Laplacian up to the sign convention.
    """
    if edges.shape[0] == 0:
        return 0.0
    u = edges[:, 0]
    v = edges[:, 1]
    w = np.asarray(alpha, dtype=np.float64)
    diff = x[u] - x[v]
    if diff.ndim == 1:
        diff = diff[:, None]
    return float(np.sum((w[:, None] ** 2) * (diff ** 2)))


def balance_residual(L: np.ndarray) -> float:
    """||L 1||_inf for the constant vector 1.

    Zero  <=>  the sheaf is (G-)balanced: every node's incident restriction
    maps sum to zero, so the constant field is a global section and the fluid
    has a non-trivial frozen state.
    """
    n = L.shape[0]
    if n == 0:
        return 0.0
    return float(np.max(np.abs(L @ np.ones(n))))


def is_balanced(L: np.ndarray, tol: float = 1e-8) -> bool:
    return balance_residual(L) < tol


def component_balance(L: np.ndarray, adj: np.ndarray) -> np.ndarray:
    """Per-component balance residual.

    For each connected component (of the underlying unsigned graph) returns
    ||L 1_C||_inf.  Zero means that component is balanced (freezes onto a
    sign pattern); non-zero means it is unbalanced (decays to zero).
    """
    n = L.shape[0]
    seen = np.zeros(n, dtype=bool)
    out = []
    for s in range(n):
        if seen[s]:
            continue
        stack, comp = [s], []
        seen[s] = True
        while stack:
            u = stack.pop()
            comp.append(u)
            nb = np.nonzero(adj[u])[0]
            for w in nb:
                if not seen[w]:
                    seen[w] = True
                    stack.append(w)
        idx = np.array(comp)
        res = L[np.ix_(idx, idx)].sum(axis=1)
        out.append(float(np.max(np.abs(res))))
    return np.array(out)

#--- FILE: superfluid/diffusion.py ---
"""
superfluid.diffusion — the "freezing" operator.

Everything needed to run the fluid in a forward pass, in closed form:

  * power iteration for lambda_max
  * Chebyshev expansion of exp(-t L)   (DCT-I interpolation, numerically stable)
  * a multi-scale BAND filter bank      (the fix for the rank-c trap)
  * spectral gap lambda_2               (the "critical temperature")
  * predicted jamming time t_jam        (= log(1/eps) / lambda_2)

Cost model (per layer, per token):
  * m Laplacian matvecs for ALL bands combined (the Chebyshev basis is shared)
  * B x (m+1) coefficient combinations afterwards (free)
  * so the fluid costs m matvecs, NOT m*B matvecs.
"""

from __future__ import annotations

import math

import numpy as np

__all__ = [
    "power_iteration_lmax", "power_iteration_lmax_autodiff", "cheb_coeffs_exp",
    "cheb_basis", "apply_bands", "band_energies", "spectral_gap", "jam_time",
    "cheb_degree", "exact_exp_action", "spectral_summary", "band_times",
                        "cheb_coeffs_exp_autodiff", "spectral_bound_autodiff",
]


def power_iteration_lmax_autodiff(L, iters: int = 15, seed: int = 0):
    """Differentiable lambda_max estimate (power iteration, no stop-gradient).

    The spectral scale enters the Chebyshev recurrence as 1/lambda_max, so
    treating it as a constant silently drops a large part of the gradient
    w.r.t. the restriction maps.  Keeping it in the graph costs a handful of
    extra mat-vecs and makes the gradient exact.
    """
    from .autodiff import Tensor
    n = L.shape[0]
    rng = np.random.default_rng(seed)
    v = Tensor(rng.standard_normal(n))
    for _ in range(iters):
        w = L @ v
        nrm = (w * w).sum().sqrt()
        if float(nrm.data) < 1e-12:
            break
        v = w / nrm
    lam = (v * (L @ v)).sum()          # Rayleigh quotient v^T L v (1-D safe)
    return lam


# --------------------------------------------------------------------- norms
def power_iteration_lmax(L: np.ndarray, iters: int = 60, tol: float = 1e-10) -> float:
    """Largest eigenvalue of a symmetric PSD matrix (power iteration)."""
    n = L.shape[0]
    if n == 0:
        return 0.0
    v = np.random.default_rng(0).standard_normal(n)
    v /= np.linalg.norm(v) + 1e-16
    lam = 0.0
    for _ in range(iters):
        w = L @ v
        nw = np.linalg.norm(w)
        if nw < 1e-16:
            return 0.0
        v_new = w / nw
        lam_new = float(v_new @ (L @ v_new))
        if abs(lam_new - lam) < tol * max(1.0, abs(lam_new)):
            lam = lam_new
            v = v_new
            break
        lam, v = lam_new, v_new
    return max(lam, 0.0)


def spectral_summary(L: np.ndarray) -> dict:
    """Exact spectrum for small matrices; the key numbers of the fluid."""
    n = L.shape[0]
    if n <= 512:
        w = np.linalg.eigvalsh(L)
        w = np.clip(w, 0.0, None)
        nz = w[w > 1e-10]
        lam2 = float(nz[0]) if nz.size else 0.0
        return {
            "lam_max": float(w.max()) if w.size else 0.0,
            "lam_min": float(w.min()) if w.size else 0.0,
            "lam2": lam2,
            "kernel_dim": int(n - nz.size),
            "eigs": w,
        }
    lam_max = power_iteration_lmax(L)
    return {"lam_max": lam_max, "lam_min": 0.0, "lam2": float("nan"),
            "kernel_dim": -1, "eigs": None}


# --------------------------------------------------------------- chebyshev
def cheb_coeffs_exp(t: float, lam_max: float, m: int) -> np.ndarray:
    """Coefficients a_k with   exp(-t L) ~= sum_k a_k T_k(Ltilde),
    where Ltilde = 2L/lam_max - I  (spectrum in [-1, 1]).

    Method: Chebyshev interpolation of g(x) = exp(-alpha x) on [-1,1],
    alpha = t*lam_max/2, at the Chebyshev-Gauss nodes, then scaled by exp(-alpha).
    """
    if m < 0:
        raise ValueError("m must be >= 0")
    if lam_max <= 0.0:
        a = np.zeros(m + 1)
        a[0] = 1.0
        return a
    alpha = 0.5 * t * lam_max
    if alpha > 500.0:
        # exp(+alpha) would overflow; beyond this the truncated expansion is
        # meaningless anyway -- see band_times() for the safe regime.
        raise ValueError(
            "Chebyshev expansion of exp(-tL) unstable for "
            f"alpha=t*lam_max/2={alpha:.1f} "
            f"(>500). Use band_times() to place bands in spectral time units."
        )
    j = np.arange(m + 1)
    x = np.cos(np.pi * (j + 0.5) / (m + 1))
    g = np.exp(-alpha * x)
    k = np.arange(m + 1)
    Cm = np.cos(np.pi * np.outer(j + 0.5, k) / (m + 1))       # (m+1, m+1)
    c = (2.0 / (m + 1)) * (g @ Cm)                            # DCT-I coeffs
    a = np.exp(-alpha) * c
    a[0] *= 0.5                                                # c_0 / 2 convention
    return a


def spectral_bound_autodiff(L, tau: float = 0.5):
    """Differentiable UPPER BOUND on lambda_max (Gershgorin + smooth max).

    The Chebyshev recurrence T_k(2L/l - I) is only stable when l >= lambda_max.
    A power-iteration ESTIMATE can undershoot, and then the recurrence
    explodes geometrically (measured: band energies of 1e15).  So we normalise
    with a guaranteed upper bound instead:

        lambda_max <= max_i ( L_ii + sum_{j != i} |L_ij| ) = max_i rowsum|L|

    The max is replaced by a log-sum-exp (smooth, differentiable, and still an
    upper bound), so the whole thing stays in the autodiff graph.
    """
    row_abs = L.abs().sum(axis=1)                 # (n,) differentiable
    e = (row_abs / tau).exp()
    lse = tau * e.sum().log()
    return 2.0 * lse


def cheb_coeffs_exp_autodiff(t: float, lam_max_t, m: int):
    """Differentiable version of cheb_coeffs_exp.

    The Chebyshev coefficients depend on the spectral scale alpha = t*lam_max/2,
    so treating lam_max as a constant inside the coefficient computation drops
    a real part of the gradient w.r.t. the restriction maps.  The whole
    expansion is a matrix multiply, so it can be kept in the autodiff graph.
    """
    from .autodiff import Tensor
    j = np.arange(m + 1)
    k = np.arange(m + 1)
    x = np.cos(np.pi * (j + 0.5) / (m + 1))
    Cm = np.cos(np.pi * np.outer(j + 0.5, k) / (m + 1))
    Cm[0, :] *= 0.5                       # the c_0 / 2 convention
    alpha = 0.5 * t * lam_max_t           # Tensor scalar
    g = (-alpha * Tensor(x)).exp()        # g(x) = exp(-alpha x), differentiable
    a = (-alpha).exp() * ((2.0 / (m + 1)) * (g @ Tensor(Cm)))
    return a


def cheb_basis(L: np.ndarray, lam_max: float, X: np.ndarray, m: int):
    """Y[k] = T_k(Ltilde) @ X for k = 0..m.  (m matvecs total, shared by all bands)

    Ltilde = 2L/lam_max - I  so that sigma(Ltilde) subset [-1, 1].
    Chebyshev recurrence:  T_0 = I,  T_1 = Ltilde,  T_k = 2*Ltilde*T_{k-1} - T_{k-2}.
    """
    if lam_max <= 0.0:
        return [X.copy()]
    Lt = (2.0 / lam_max) * L - np.eye(L.shape[0])
    Y = [X.copy()]
    if m >= 1:
        Y.append(Lt @ X)
    for k in range(2, m + 1):
        Y.append(2.0 * (Lt @ Y[k - 1]) - Y[k - 2])
    return Y


def band_times(lam_max: float, m: int, n_bands: int, alpha_min: float = 0.05,
               alpha_max: float | None = None):
    """Spectrum-adaptive band times.

    The Chebyshev expansion of exp(-tL) needs alpha = t*lam_max/2 <= m, otherwise
    the truncation error blows up (this is the "conditioning cliff").  So the
    bands are placed in *spectral* time units alpha_j, and converted to t at run
    time.  The band range then always spans the whole spectrum of L, whatever
    its scale, and the Chebyshev degree stays sufficient by construction.

    t_j = 2*alpha_j / lam_max
    """
    if alpha_max is None:
        alpha_max = float(m) * 0.75
    a = np.geomspace(alpha_min, max(alpha_max, alpha_min * 2), n_bands + 1)
    if lam_max <= 0:
        return a
    return 2.0 * a / lam_max


def apply_bands(L: np.ndarray, lam_max: float, X: np.ndarray,
                ts: np.ndarray, m: int) -> np.ndarray:
    """Multi-scale band filter bank.

    band_j = exp(-t_j L) - exp(-t_{j+1} L),  t = [t_0, ..., t_B] (B+1 times)

    Returns array of shape (B, n, d).  Cost: m Laplacian matvecs total
    (the Chebyshev basis T_k(Ltilde) X is computed once and reused by every band).
    """
    ts = np.asarray(ts, dtype=np.float64)
    B = ts.shape[0] - 1
    if B <= 0:
        raise ValueError("need at least two time constants")
    Y = cheb_basis(L, lam_max, X, m)
    out = np.zeros((B,) + X.shape)
    for j in range(B):
        a = cheb_coeffs_exp(ts[j], lam_max, m)
        b = cheb_coeffs_exp(ts[j + 1], lam_max, m)
        coef = a - b
        acc = np.zeros_like(X)
        for k in range(m + 1):
            if coef[k] != 0.0:
                acc += coef[k] * Y[k]
        out[j] = acc
    return out


def band_energies(bands: np.ndarray) -> np.ndarray:
    """Relative energy carried by each band: ||band_j||^2 / sum_j ||band_j||^2."""
    e = (bands ** 2).sum(axis=(1, 2))
    s = e.sum()
    return e / s if s > 0 else e


# ------------------------------------------------------------------- theory
def spectral_gap(L: np.ndarray) -> float:
    """Smallest strictly positive eigenvalue (the spectral gap lambda_2)."""
    s = spectral_summary(L)
    return s["lam2"]


def jam_time(lam2: float, eps: float = 1e-6) -> float:
    """Predicted freezing time:  t_jam = log(1/eps) / lambda_2."""
    if lam2 <= 0:
        return math.inf
    return math.log(1.0 / eps) / lam2


def cheb_degree(kappa: float, eps: float = 1e-6) -> int:
    """Chebyshev degree needed for relative accuracy eps at condition number kappa."""
    return int(math.ceil(math.sqrt(max(kappa, 1.0)) * math.log(2.0 / eps)))


def exact_exp_action(L: np.ndarray, t: float, X: np.ndarray) -> np.ndarray:
    """Ground truth exp(-tL) X via eigendecomposition (for verification only)."""
    w, V = np.linalg.eigh(L)
    return V @ (np.exp(-t * w)[:, None] * (V.T @ X))

#--- FILE: superfluid/topology.py ---
"""
superfluid.topology — building the data's geometry in one forward pass.

This module implements the "instant geometry" of the proposal:

  1. content routing      -> semantic edges (top-k over QK similarity)
  2. temporal chain      -> order edges (position as 1-dimensional topology)
  3. 0-D persistence     -> exact barcode via union-find (Kruskal filtration)
  4. Betti numbers      -> beta_0 (components), beta_1 (cycle rank)

(3) and (4) are *exact*, not approximated, and cost O(m log m) — which is why
the geometry can be recomputed every forward pass instead of being cached
offline.  This is the concrete answer to "jam the data's geometry in one pass".
"""

from __future__ import annotations

import numpy as np

__all__ = [
    "route_topk", "edges_from_topk", "chain_edges", "unique_edges",
    "kruskal_barcode", "betti_numbers", "topo_descriptor",
    "connected_components",
    "hodge_relevance", "hodge_embedding", "hodge_edge_participation",
    "local_density", "persistence_landmarks",
]


# ------------------------------------------------------- selection criteria
def hodge_embedding(n: int, edges: np.ndarray, alpha: np.ndarray) -> np.ndarray:
    """The Hodge embedding Psi = (L + (1/n) 11^T)^-1 of the sheaf Laplacian."""
    from .sheaf import build_laplacian

    laplacian = build_laplacian(n, edges, np.asarray(alpha, dtype=np.float64))
    constant = np.ones((n, 1)) / np.sqrt(max(n, 1))
    matrix = laplacian + constant @ constant.T
    try:
        return np.linalg.inv(matrix)
    except np.linalg.LinAlgError:
        return np.linalg.pinv(matrix)


def hodge_edge_participation(
    Psi: np.ndarray, a: np.ndarray, b: np.ndarray
) -> np.ndarray:
    """Return normalized Hodge participation for a set of node pairs."""
    Psi = np.asarray(Psi, dtype=np.float64)
    a = np.asarray(a, dtype=np.int64)
    b = np.asarray(b, dtype=np.int64)
    numerator = np.abs(Psi[a, b])
    denominator = np.sqrt(
        np.maximum(np.abs(Psi[a, a]), 1e-18)
        * np.maximum(np.abs(Psi[b, b]), 1e-18)
    )
    return np.clip(numerator / denominator, 0.0, 1.0)


def hodge_relevance(n: int, edges: np.ndarray, alpha: np.ndarray) -> np.ndarray:
    """Return per-node harmonic participation scores for the sheaf Laplacian."""
    embedding = hodge_embedding(n, edges, alpha)
    participation = np.abs(embedding).sum(axis=1) - np.abs(np.diag(embedding))
    return np.clip(participation, 0.0, None)


def local_density(
    protos: np.ndarray, radius: float | None = None, k: int = 8
) -> np.ndarray:
    """Return prototype neighborhood counts or effective top-k density."""
    prototypes = np.asarray(protos, dtype=np.float64)
    n = prototypes.shape[0]
    if radius is not None:
        squared_norms = (prototypes**2).sum(1)
        distances = np.sqrt(
            np.maximum(
                squared_norms[:, None]
                + squared_norms[None, :]
                - 2.0 * (prototypes @ prototypes.T),
                0.0,
            )
        )
        return (distances <= radius).sum(axis=1).astype(np.float64)
    normalized = prototypes / (
        np.linalg.norm(prototypes, axis=1, keepdims=True) + 1e-12
    )
    similarities = normalized @ normalized.T
    np.fill_diagonal(similarities, -np.inf)
    k = int(min(k, n - 1)) if n > 1 else 1
    nearest = np.partition(similarities, -k, axis=1)[:, -k:]
    maximum = np.abs(nearest).max(axis=1, keepdims=True) + 1e-12
    return (np.abs(nearest) / maximum).sum(axis=1)


def persistence_landmarks(
    n: int, edges: np.ndarray, weights: np.ndarray, k: int = 10
) -> np.ndarray:
    """Return node indices whose topological classes persist the longest."""
    edges = np.asarray(edges, dtype=np.int64)
    weights = np.asarray(weights, dtype=np.float64)
    if edges.shape[0] == 0:
        return np.arange(min(k, n), dtype=np.int64)
    parent = list(range(n))
    members = {i: [i] for i in range(n)}

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    death = np.full(n, -np.inf, dtype=np.float64)
    order = np.argsort(weights, kind="stable")
    for edge_index in order:
        u = int(edges[edge_index, 0])
        v = int(edges[edge_index, 1])
        weight = float(weights[edge_index])
        root_u, root_v = find(u), find(v)
        if root_u == root_v:
            continue
        merged_nodes = members[root_u] + members[root_v]
        for node in merged_nodes:
            death[node] = weight
        if len(members[root_u]) < len(members[root_v]):
            root_u, root_v = root_v, root_u
        parent[root_v] = root_u
        members[root_u] = members[root_u] + members[root_v]
        del members[root_v]
    for root in list(members):
        for node in members[root]:
            death[node] = np.inf
    order_nodes = np.lexsort((np.arange(n), -death))
    return order_nodes[:min(k, n)].astype(np.int64)


def connected_components(n: int, edges: np.ndarray):
    """Return connected-component labels and the number of components."""
    parent = list(range(n))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    for edge in edges:
        root_u, root_v = find(int(edge[0])), find(int(edge[1]))
        if root_u != root_v:
            parent[root_v] = root_u
    roots = np.array([find(i) for i in range(n)])
    _, labels = np.unique(roots, return_inverse=True)
    return labels.astype(np.int64), int(labels.max()) + 1 if n else 0


# ------------------------------------------------------------------ routing
def route_topk(Q: np.ndarray, K: np.ndarray, k: int, causal: bool = True):
    """Return each query's k most similar keys, masking future keys if causal."""
    n = Q.shape[0]
    scores = Q @ K.T / np.sqrt(Q.shape[1])
    if causal:
        mask = np.triu(np.ones((n, n), dtype=bool), k=1)
        scores = np.where(mask, -np.inf, scores)
    k = int(min(k, n))
    idx = np.argpartition(-scores, kth=k - 1, axis=1)[:, :k]
    row = np.arange(n)[:, None]
    logits = scores[row, idx]
    order = np.argsort(-logits, axis=1)
    idx = np.take_along_axis(idx, order, axis=1)
    logits = np.take_along_axis(logits, order, axis=1)
    return idx, logits


def edges_from_topk(idx: np.ndarray) -> np.ndarray:
    """Return unique undirected edges from a (n, k) neighbor-index array."""
    n, k = idx.shape
    u = np.repeat(np.arange(n), k)
    v = idx.reshape(-1)
    mask = u < v
    u, v = u[mask], v[mask]
    if u.size == 0:
        return np.zeros((0, 2), dtype=np.int64)
    key = u.astype(np.int64) * n + v
    _, idx2 = np.unique(key, return_index=True)
    return np.stack([u[idx2], v[idx2]], axis=1)


def chain_edges(n: int) -> np.ndarray:
    """Return temporal-chain edges (i, i+1)."""
    if n < 2:
        return np.zeros((0, 2), dtype=np.int64)
    return np.stack([np.arange(n - 1), np.arange(1, n)], axis=1)


def unique_edges(*edge_sets):
    """Return the union of edge lists with duplicates removed."""
    nonempty = [edges for edges in edge_sets if edges.size]
    if not nonempty:
        return np.zeros((0, 2), dtype=np.int64)
    all_edges = np.concatenate(nonempty, axis=0)
    u = np.minimum(all_edges[:, 0], all_edges[:, 1])
    v = np.maximum(all_edges[:, 0], all_edges[:, 1])
    key = u.astype(np.int64) * (int(max(u.max(), v.max())) + 1) + v
    _, keep = np.unique(key, return_index=True)
    return np.stack([u[keep], v[keep]], axis=1)


# ------------------------------------------------------------- persistence
def kruskal_barcode(n: int, edges: np.ndarray, weights: np.ndarray):
    """Return the exact 0-dimensional persistence barcode and beta_0."""
    parent = list(range(n))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    m = edges.shape[0]
    order = np.argsort(weights) if m else ()
    birth = [0.0] * n
    pairs = []
    for edge_index in order:
        u = int(edges[edge_index, 0])
        v = int(edges[edge_index, 1])
        weight = float(weights[edge_index])
        root_u, root_v = find(u), find(v)
        if root_u == root_v:
            continue
        birth_value = min(birth[root_u], birth[root_v])
        pairs.append((birth_value, weight))
        if birth[root_u] > birth[root_v]:
            root_u, root_v = root_v, root_u
        parent[root_v] = root_u
        birth[root_u] = birth_value
    roots = {find(i) for i in range(n)}
    for root in roots:
        pairs.append((birth[root], float("inf")))
    return pairs, len(roots)


def betti_numbers(n: int, edges: np.ndarray) -> dict:
    """Return beta_0, beta_1, and graph size for a 1-dimensional complex."""
    m = edges.shape[0]
    parent = list(range(n))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    for edge in edges:
        root_u, root_v = find(int(edge[0])), find(int(edge[1]))
        if root_u != root_v:
            parent[root_v] = root_u
    components = len({find(i) for i in range(n)})
    beta1 = m - n + components
    return {
        "beta0": components,
        "beta1": int(max(beta1, 0)),
        "m": int(m),
        "n": int(n),
    }


def topo_descriptor(n: int, edges: np.ndarray, weights: np.ndarray) -> np.ndarray:
    """Return a fixed-length topological signature of the routed complex."""
    betti = betti_numbers(n, edges)
    pairs, _ = kruskal_barcode(n, edges, weights)
    finite = [(birth, death) for birth, death in pairs if np.isfinite(death)]
    lifetimes = np.array(
        [death - birth for birth, death in finite], dtype=np.float64
    )
    if lifetimes.size:
        maximum = float(lifetimes.max())
        total = float(lifetimes.sum())
        mean = float(lifetimes.mean())
        longer_quarter = int((lifetimes > 0.25 * maximum).sum())
        longer_half = int((lifetimes > 0.50 * maximum).sum())
    else:
        maximum = total = mean = 0.0
        longer_quarter = longer_half = 0
    return np.array(
        [
            betti["beta0"],
            betti["beta1"],
            total,
            maximum,
            mean,
            longer_quarter,
            longer_half,
            betti["m"] / max(n, 1),
            np.log1p(betti["m"]),
        ],
        dtype=np.float64,
    )

#--- FILE: superfluid/blocks.py ---
"""
superfluid.blocks — the Superfluid block.

One block, five stages.  Every stage exists to fix a named weakness of the
naive "replace attention with diffusion" idea:

  ROUTER      top-k content routing  -> semantic edges
  TOPOLOGY    semantic edges + temporal chain  -> the complex
  SHEAF       learned signed restriction maps -> content-adaptive geometry
  FREEZE      multi-scale band filter bank (exp(-t_j L) - exp(-t_{j+1} L))
  READ        channel mixing + ONE nonlinearity + residual + sharp route head

Stage notes
-----------
* The signed restriction maps make the G-balance phase transition learnable:
  a balanced component freezes onto a non-trivial sign pattern, an unbalanced
  one decays to zero.  `tanh` keeps |alpha| <= 1 so L stays bounded and
  gradients cannot explode.
* The band filter bank (not a single exponential) is what prevents the
  "frozen state has rank c" information loss.
* The route head is a hard top-k gather (winner-take-all).  It is the sharp
  retrieval path the smooth fluid cannot provide -- this is what keeps the
  model from being a pure smoother.
"""

from __future__ import annotations

import numpy as np

from .autodiff import Tensor, concat, softmax_rows, softplus
from .diffusion import (
    band_times,
    cheb_coeffs_exp,
    cheb_coeffs_exp_autodiff,
    power_iteration_lmax,
    spectral_bound_autodiff,
)
from .topology import (
    chain_edges,
    connected_components,
    edges_from_topk,
    topo_descriptor,
)

__all__ = ["SuperfluidBlock", "RMSNorm", "softplus"]


class RMSNorm:
    def __init__(self, d: int, seed: int = 0):
        self.g = Tensor(np.ones(d))
        self.eps = 1e-6

    def __call__(self, x: Tensor) -> Tensor:
        ms = (x * x).mean()
        inv = (ms + self.eps).pow(-0.5)
        n = x * inv
        return n * self.g


class SuperfluidBlock:
    def __init__(self, d: int, k_neighbors: int = 8, bands: int = 6, cheb_m: int = 12,
                 t_min: float = 1e-3, t_max: float = 1e3, edge_hidden: int = 16,
                 use_route_head: bool = True, seed: int = 0,
                 alpha_min: float = 0.05, alpha_max: float | None = None):
        rng = np.random.default_rng(seed)
        self.d = d
        self.k = int(k_neighbors)
        self.B = int(bands)
        self.m = int(cheb_m)
        # Bands live in SPECTRAL time units alpha = t*lam_max/2 so that the
        # Chebyshev degree m stays sufficient for any graph scale.
        self.alpha_min = alpha_min
        self.alpha_max = alpha_max if alpha_max is not None else 0.75 * self.m
        self.ts = np.geomspace(t_min, t_max, self.B + 1)   # fallback / reference
        self.use_route_head = use_route_head

        s = d ** -0.5
        self.Wq = Tensor(rng.normal(0, s, (d, d)))
        self.Wk = Tensor(rng.normal(0, s, (d, d)))
        self.Wv = Tensor(rng.normal(0, s, (d, d)))
        self.Wo = Tensor(rng.normal(0, s, (d, d)))
        self.Wmix = Tensor(rng.normal(0, s, (d, d)))
        self.Wr = Tensor(rng.normal(0, s, (d, d))) if use_route_head else None
        self.edge1 = Tensor(rng.normal(0, (2 * d) ** -0.5, (2 * d, edge_hidden)))
        self.edge2 = Tensor(rng.normal(0, edge_hidden ** -0.5, (edge_hidden, 1)))
        self.beta_chain = Tensor(np.array([[0.3]]))       # order / temporal edges
        # Band gates start NEAR ZERO (softplus(-3) ~ 0.05): the transient is
        # much larger in magnitude than the harmonic component, so starting
        # with the bands "open" would swamp the frozen state.
        self.band_g = Tensor(np.full((self.B, 1), -3.0))    # band gates (softplus)
        self.harm_g = Tensor(np.array([[1.0]]))            # gate on the HARMONIC branch
        self.norm = RMSNorm(d)
        self.diag = {}

    # ------------------------------------------------------------- helpers
    def _laplacian(self, n: int, edges: np.ndarray, alpha: Tensor) -> Tensor:
        """Differentiable signed sheaf Laplacian  L = D_abs - A."""
        m = edges.shape[0]
        if m == 0:
            return Tensor(np.zeros((n, n)))
        idx_uv = (edges[:, 0].astype(np.int64) * n + edges[:, 1].astype(np.int64))
        idx_vu = (edges[:, 1].astype(np.int64) * n + edges[:, 0].astype(np.int64))
        Z = Tensor(np.zeros(n * n))
        # two SEPARATE scatter bases, then added: index_add starts from zeros,
        # so chaining it would silently discard the first contribution.
        A = (Z.index_add(idx_uv, alpha) + Z.index_add(idx_vu, alpha)).reshape(n, n)
        deg = A.abs().sum(axis=1)                          # (n,)
        diag_idx = np.arange(n) * n + np.arange(n)
        D = Tensor(np.zeros(n * n)).index_add(diag_idx, deg).reshape(n, n)
        return D - A

    def _harmonic(self, x: Tensor, edges: np.ndarray):
        """Exact Hodge projection of the graph Laplacian: the PER-COMPONENT MEAN.

        ker(L) for a graph Laplacian is the space of per-component constants,
        so the frozen state of the diffusion is the component mean.  Cost
        O(n + m): union-find for the components, then a scatter-add and a
        gather.  This is the branch that lets the block represent a GLOBAL
        aggregate -- the band bank alone only carries the transient.
        """
        n, d = x.shape[0], x.shape[1]
        labels, ncomp = connected_components(n, edges)
        if ncomp <= 0:
            return Tensor(np.zeros((n, d)))
        sums = Tensor(np.zeros((ncomp, d))).index_add(labels, x)
        ones = Tensor(np.ones(n))
        counts = Tensor(np.zeros(ncomp)).index_add(labels, ones).reshape(ncomp, 1)
        comp_mean = sums / counts
        return comp_mean.gather(labels)

    def _bands(self, L: Tensor, lam_max: float, X: Tensor, lam_max_t=None):
        """Chebyshev band filter bank; the basis T_k(Ltilde)X is computed ONCE."""
        n = L.shape[0]
        inv = (2.0 / lam_max) if lam_max_t is None else (2.0 / lam_max_t)
        Y = [X]
        if self.m >= 1:
            Lt = inv * L - Tensor(np.eye(n))
            Y.append(Lt @ X)
            for k in range(2, self.m + 1):
                Y.append(2.0 * (Lt @ Y[k - 1]) - Y[k - 2])
        ts = band_times(lam_max, self.m, self.B, self.alpha_min, self.alpha_max)
        out = []
        for j in range(self.B):
            if lam_max_t is not None:
                a = cheb_coeffs_exp_autodiff(ts[j], lam_max_t, self.m)
                b = cheb_coeffs_exp_autodiff(ts[j + 1], lam_max_t, self.m)
                coef = a - b
                acc = None
                for k in range(self.m + 1):
                    if abs(float(coef.data[k])) > 0.0:
                        term = Y[k] * coef[k]
                        acc = term if acc is None else acc + term
            else:
                a = cheb_coeffs_exp(ts[j], lam_max, self.m)
                b = cheb_coeffs_exp(ts[j + 1], lam_max, self.m)
                coef = a - b
                acc = None
                for k in range(self.m + 1):
                    if coef[k] != 0.0:
                        term = Y[k] * float(coef[k])
                        acc = term if acc is None else acc + term
            out.append(acc)
        self.last_ts = ts
        return out

    # -------------------------------------------------------------- forward
    def __call__(self, x: Tensor):
        n = x.shape[0]
        d = self.d
        xn = self.norm(x)

        # ---- ROUTER --------------------------------------------------------
        q = xn @ self.Wq
        k = xn @ self.Wk
        scores = (q @ k.T) * (d ** -0.5)
        causal = np.triu(np.ones((n, n), dtype=bool), k=1)
        sc_masked = scores.data - 1e9 * causal
        idx = np.argsort(-sc_masked, axis=1)[:, : self.k]   # (n, k) neighbours
        row = np.arange(n)[:, None]
        sel = scores[row, idx]                                # Tensor (n, k)

        # ---- TOPOLOGY: semantic edges + temporal chain ----------------------
        sem = edges_from_topk(idx)
        chain = chain_edges(n)

        # ---- SHEAF: content-adaptive signed restriction maps -----------------
        if sem.shape[0] > 0:
            eu = xn[sem[:, 0]]
            ev = xn[sem[:, 1]]
            feat = concat([eu, ev], axis=1)
            h = (feat @ self.edge1).tanh()
            alpha = (h @ self.edge2).reshape(-1)              # (m,) in (-1, 1)
        else:
            alpha = Tensor(np.zeros(0))
        L_sem = self._laplacian(n, sem, alpha)

        if chain.shape[0] > 0:
            beta = softplus(self.beta_chain)                   # (1,1) > 0
            a_ch = beta.reshape(1) * Tensor(np.ones(chain.shape[0]))
            L_chain = self._laplacian(n, chain, a_ch)
        else:
            L_chain = Tensor(np.zeros((n, n)))
        L = L_sem + L_chain

        # Spectral scale.  We use a GUARANTEED UPPER BOUND (Gershgorin +
        # smooth max) for the Chebyshev normalisation: an estimate that
        # undershoots lambda_max makes the recurrence explode.  The bound is
        # differentiable, so no gradient is lost.
        lam_bound_t = spectral_bound_autodiff(L)
        lam_est = power_iteration_lmax(L.data, iters=40)
        lam_max_t = lam_bound_t
        lam_max = float(lam_max_t.data)
        if lam_max < 1e-8:
            lam_max = 1e-8
            lam_max_t = Tensor(np.array([[lam_max]]))

        # ---- FREEZE: multi-scale band filter bank --------------------------
        bands = self._bands(L, lam_max, xn, lam_max_t)
        gates = softplus(self.band_g).reshape(self.B)
        z = None
        for j in range(self.B):
            term = bands[j] * gates[j]
            z = term if z is None else z + term

        # ---- HARMONIC BRANCH: the frozen state (exact Hodge projection) -----
        # For a graph Laplacian, ker(L) = per-component constants, so the
        # Hodge limit of the diffusion is the PER-COMPONENT MEAN.  The band
        # bank only carries the transient, so without this branch the block
        # cannot represent a global aggregate at all (measured: sign acc =
        # chance on the global-mean task).  Cost: O(n + m) via union-find.
        all_edges = (
            np.concatenate([sem, chain], axis=0)
            if sem.shape[0] or chain.shape[0]
            else np.zeros((0, 2), dtype=np.int64)
        )
        harmonic = self._harmonic(xn, all_edges)
        _, diag_ncomp = connected_components(n, all_edges)
        z = z + self.harm_g * harmonic

        # ---- READ: mix channels, one nonlinearity, residual -----------------
        z = z @ self.Wmix
        z = z.gelu()
        out = x + z @ self.Wo

        # ---- sharp retrieval path (winner-take-all over the routed edges) ---
        if self.use_route_head:
            v = xn @ self.Wv
            vg = v.gather_rows(idx)                            # (n, k, d)
            w = softmax_rows(sel)                              # (n, k)
            sr = (vg * w[:, :, None]).sum(axis=1)              # (n, d)
            out = out + sr @ self.Wr

        # ---- diagnostics ---------------------------------------------------
        try:
            desc = topo_descriptor(n, sem, np.abs(alpha.data) + 1e-9)
        except Exception:
            desc = np.zeros(9)
        self.diag = {
            "n_edges": int(sem.shape[0]),
            "n_components": int(diag_ncomp),
            "lam_max": float(lam_max),
            "lam_est": float(lam_est),
            "alpha_abs_mean": (
                float(np.abs(alpha.data).mean()) if alpha.data.size else 0.0
            ),
            "alpha_neg_frac": (
                float((alpha.data < 0).mean()) if alpha.data.size else 0.0
            ),
            "band_energy": np.array(
                [float((band.data**2).sum()) for band in bands]
            ),
            "topo": desc,
            "balance_res": float(np.max(np.abs(L.data.sum(axis=1)))),
        }
        return out

#--- FILE: superfluid/memory.py ---
"""
superfluid.memory — the FROZEN REGISTER and the geometry-addressed memory graft.
This module implements the two ideas that make the fluid trustworthy:
A frozen register (L1): an append-only, write-once table of EXACT
facts.  A fact's value is stored as an INTEGER token id, so a retrieved
value is bit-identical to the source -- not float-approximate.  The
register is never diffused, so the fluid's smoothing cannot destroy it.
A sheaf memory adapter (L2, the "graft"): a constant-size state
S in R^{M x r} plus a static prototype codebook.  The adapter routes
(geometry decides WHERE) and the register stores (content decides
WHAT).  That split is what makes exactness possible at all: a diffusion
smears, so an exact value must never live inside one.
An external tier (L3): a pointer into the original source.  A
pointer is 6 bytes and is unbounded, so it is the fallback whenever the
register cannot answer.
Slot layout (20 bytes, little-endian):
key     uint64   8 B   64-bit context hash (the OCCURRENCE identity)
val     int32    4 B   the exact token id
sig     uint32   4 B   4 x uint8 embedding signature (collision detector)
anchor  uint16   2 B   the anchor the fact was routed to when promoted
meta    uint16   2 B   doc_id (12 bits) | trust (2 bits) | reserved (2)
Why 20 bytes and not the 14 quoted in docs/DESIGN_pinned_memory.md: the 4-byte
embedding signature was added so that a 64-bit hash collision is DETECTABLE
rather than silent ("fail loud, never silently wrong").  The cost of that
guarantee is 6 bytes/fact, i.e. 819 facts in 16 KB instead of 1,170.
"""
from __future__ import annotations

import numpy as np

__all__ = [
    "FNV_OFFSET", "FNV_PRIME", "MASK64", "fnv1a64", "ctx_key",
    "FrozenRegister", "SheafMemoryAdapter", "logit_override",
    "budget_split", "embedding_signature", "SLOT_BYTES",
]

# ------------------------------------------------------------------ hashing
FNV_OFFSET = 0xCBF29CE484222325
FNV_PRIME = 0x100000001B3
MASK64 = (1 << 64) - 1


def fnv1a64(values) -> int:
    """Deterministic 64-bit FNV-1a hash over a sequence of integers.

    Pure python, no dependencies, and stable across runs/platforms (unlike
    Python's salted `hash()`), so a register written today can be verified
    tomorrow.
    """
    h = FNV_OFFSET
    for v in values:
        h ^= int(v) & MASK64
        h = (h * FNV_PRIME) & MASK64
    return h


def ctx_key(window, doc_id: int = 0) -> int:
    """64-bit identity of a CONTEXT OCCURRENCE (doc_id + token window).

    The same content in two different documents gets two different keys, so
    a register can be told apart per source; the fact-level grouping (for the
    corroboration quorum) is handled by the caller, which passes the same
    `window` with different `doc_id`s.
    """
    if isinstance(window, (int, np.integer)):
        window = (int(window),)
    vals = [int(doc_id) & 0xFFF]
    vals.extend(int(w) & MASK64 for w in window)
    return fnv1a64(vals)


def embedding_signature(vec: np.ndarray, dims: int = 4) -> int:
    """Quantise the first `dims` coordinates of a unit vector to a uint32.

    Used as a cheap second channel: if the 64-bit key collides, the
    signature almost certainly will not, and the read fails loud instead of
    returning a wrong exact value.
    """
    v = np.asarray(vec, dtype=np.float64).ravel()
    if v.size == 0:
        return 0
    n = np.linalg.norm(v[:dims]) + 1e-12
    q = np.clip(np.round(v[:dims] / n * 127.0) + 128.0, 0, 255).astype(np.uint8)
    out = 0
    for i in range(dims):
        out |= int(q[i]) << (8 * i)
    return out


# ------------------------------------------------------------------ register
SLOT_BYTES = 20


class FrozenRegister:
    """Append-only, write-once table of EXACT facts.

    Guarantees
     ----------
     * **Invariance.**  A slot that holds (key, val) at time t still holds
       (key, val) at every later time, bit-for-bit.  Nothing in the write
       path can modify an existing slot.
     * **Integer exactness.**  `val` is an int32 token id, so a successful
       recall returns a value that is *equal*, not approximately equal.
     * **Fail-loud.**  A recall verifies both the 64-bit key and the 4-byte
       embedding signature.  On mismatch the register reports "not found"
       instead of returning a value that may belong to another fact.
    """

    SLOT_BYTES = SLOT_BYTES

    def __init__(self, capacity: int = 1024):
        self.capacity = int(capacity)
        self.key = np.zeros(self.capacity, dtype=np.uint64)
        self.val = np.zeros(self.capacity, dtype=np.int32)
        self.sig = np.zeros(self.capacity, dtype=np.uint32)
        self.anchor = np.zeros(self.capacity, dtype=np.uint16)
        self.meta = np.zeros(self.capacity, dtype=np.uint16)
        self.used = np.zeros(self.capacity, dtype=bool)
        self.n = 0
        self._by_key: dict[int, list[int]] = {}

    # ------------------------------------------------------------- encoding
    @staticmethod
    def _pack_meta(doc_id: int, trust: int) -> int:
        return (int(doc_id) & 0x0FFF) | ((int(trust) & 0x3) << 12)

    @staticmethod
    def _unpack_meta(meta: int):
        return int(meta) & 0x0FFF, (int(meta) >> 12) & 0x3

    # ---------------------------------------------------------------- write
    def promote(self, val: int, key: int, sig: int = 0, anchor: int = 0,
                doc_id: int = 0, trust: int = 0) -> int:
        """Append a NEW slot.  Returns the slot index.

        Append-only means a fact that is promoted twice gets two slots and
        the *latest* wins on recall: that is the versioning mechanism, and it
        is also what makes the register an append-only audit log.
        """
        if self.n >= self.capacity:
            raise MemoryError(
                f"frozen register is full ({self.capacity} slots x {SLOT_BYTES} B "
                f"= {self.capacity * SLOT_BYTES} B).  Overflow is REFUSED on purpose: "
                f"a register that silently grows becomes a KV cache.")
        s = self.n
        self.key[s] = np.uint64(key & MASK64)
        self.val[s] = np.int32(val)
        self.sig[s] = np.uint32(sig & 0xFFFFFFFF)
        self.anchor[s] = np.uint16(anchor)
        self.meta[s] = np.uint16(self._pack_meta(doc_id, trust))
        self.used[s] = True
        self.n += 1
        self._by_key.setdefault(int(key), []).append(s)
        return s

    def set_trust(self, slot: int, trust: int = 1) -> None:
        """Raise the trust bit of an existing slot (corroboration gate)."""
        doc, _ = self._unpack_meta(int(self.meta[slot]))
        self.meta[slot] = np.uint16(self._pack_meta(doc, trust))

    # ----------------------------------------------------------------- read
    def slots_for(self, key: int) -> list[int]:
        return self._by_key.get(int(key), [])

    def latest(self, key: int):
        """Most recent slot holding `key`, or None."""
        sl = self._by_key.get(int(key))
        return sl[-1] if sl else None

    def verify(self, slot: int, key: int, sig: int | None = None) -> bool:
        """True iff the slot really holds this occurrence."""
        if not (0 <= slot < self.n) or not self.used[slot]:
            return False
        if int(self.key[slot]) != (int(key) & MASK64):
            return False
        if sig is not None and int(self.sig[slot]) != (int(sig) & 0xFFFFFFFF):
            return False
        return True

    def recall(self, key: int, sig: int | None = None):
        """Return (slot, exact_value) or None.

        `sig` is the embedding signature of the query.  When supplied, a
        signature mismatch makes the recall FAIL (return None) instead of
        returning another fact's value -- this is the fail-loud path.
        """
        s = self.latest(key)
        if s is None:
            return None
        if sig is not None and int(self.sig[s]) != (int(sig) & 0xFFFFFFFF):
            return None            # hash collision or wrong occurrence -> fail loud
        return s, int(self.val[s])

    def read_slot(self, slot: int):
        """Raw read of a slot (no verification) -> (key, val, sig, anchor, trust)."""
        if not (0 <= slot < self.n) or not self.used[slot]:
            return None
        doc, trust = self._unpack_meta(int(self.meta[slot]))
        return (int(self.key[slot]), int(self.val[slot]), int(self.sig[slot]),
                int(self.anchor[slot]), doc, trust)

    def trust_of(self, slot: int) -> int:
        return self._unpack_meta(int(self.meta[slot]))[1]

    def doc_of(self, slot: int) -> int:
        return self._unpack_meta(int(self.meta[slot]))[0]

    def quorum(self, key: int) -> int:
        """Number of DISTINCT sources that promoted this key.

        The corroboration gate: a fact promoted by two independent documents
        is "trusted"; a fact promoted once stays "suspect".  Because the key
        includes doc_id, two different documents produce different keys --
        so the caller must pass the doc-independent fact key.  We therefore
        count distinct doc_ids stored under keys that share the same
        *occurrence signature* is not possible here; instead we count the
        distinct doc_ids across all slots of the given key, which is exact
        for a fixed (window, doc) pair and conservative otherwise.
        """
        sl = self._by_key.get(int(key), [])
        return len({self.doc_of(s) for s in sl})

    # ------------------------------------------------------------- accounting
    def nbytes(self) -> int:
        """Bytes of *state* held (the serialised slot table)."""
        return self.capacity * SLOT_BYTES

    def used_bytes(self) -> int:
        return self.n * SLOT_BYTES

    def stats(self) -> dict:
        trusts = [self.trust_of(s) for s in range(self.n)] if self.n else []
        return {
            "capacity_slots": self.capacity,
            "used_slots": int(self.n),
            "slot_bytes": SLOT_BYTES,
            "state_bytes": self.nbytes(),
            "used_bytes": self.used_bytes(),
            "n_trusted": int(sum(1 for t in trusts if t)),
            "fill_fraction": float(self.n / max(self.capacity, 1)),
        }

    def to_bytes(self) -> bytes:
        return (self.key.tobytes() + self.val.tobytes() + self.sig.tobytes() +
                self.anchor.tobytes() + self.meta.tobytes() +
                self.used.tobytes())

    @classmethod
    def from_bytes(cls, blob: bytes, capacity: int) -> FrozenRegister:
        r = cls(capacity=capacity)
        n = capacity
        p = 0

        def take(arr, dt):
            nonlocal p
            out = np.frombuffer(blob[p:p + n * np.dtype(dt).itemsize], dtype=dt).copy()
            p += n * np.dtype(dt).itemsize
            return out

        r.key = take(None, np.uint64)
        r.val = take(None, np.int32)
        r.sig = take(None, np.uint32)
        r.anchor = take(None, np.uint16)
        r.meta = take(None, np.uint16)
        r.used = take(None, np.uint8).astype(bool)
        r.n = int(r.used.sum())
        r._by_key = {}
        for s in range(r.n):
            r._by_key.setdefault(int(r.key[s]), []).append(s)
        return r


# ------------------------------------------------------------------ override
def logit_override(logits: np.ndarray, token_ids) -> np.ndarray:
    """Force `token_ids` to win the argmax, deterministically.

    This is the difference between "the model was told the answer" and "the
    model cannot disagree":  a tool that merely *returns* a token can be
    outvoted by the fluid's own logits, so the extraction would be
    probabilistic.  Overriding the logit makes the next token provably the
    recalled one.

    Accepts logits of shape (V,) or (B, V), as a plain ndarray **or** as a
    framework Tensor.  `token_ids` is an int or a sequence of ints (one per
    row for the 2-D case).
    """
    # accept a framework Tensor as well as a plain ndarray
    if hasattr(logits, "data"):
        logits = logits.data
    out = np.array(logits, dtype=np.float64, copy=True)
    if out.ndim == 1:
        if out.shape[0] == 0:
            raise ValueError("empty logits")
        out[int(token_ids)] = np.inf
        return out
    if out.ndim == 2:
        ids = np.atleast_1d(np.asarray(token_ids, dtype=np.int64))
        if ids.size == 1:
            ids = np.full(out.shape[0], ids[0], dtype=np.int64)
        if ids.size != out.shape[0]:
            raise ValueError("token_ids length must match the batch")
        rows = np.arange(out.shape[0])
        out[rows, ids] = np.inf
        return out
    raise ValueError("logits must be 1-D or 2-D")


# ------------------------------------------------------------------- budget
def budget_split(total_bytes: int, M: int, r: int, slot_bytes: int = SLOT_BYTES,
                 codebook_bytes: int = 0) -> dict:
    """Split a RUNTIME byte budget between the fluid state and the frozen register.

    `total_bytes` is the *runtime* budget (what a tenant pays per session).
    `codebook_bytes` is the STATIC artefact (prototypes + value projection),
    which is shared across tenants and therefore reported, not subtracted.

    The design law from docs/DESIGN_pinned_memory.md: **naming one anchor out of M
    needs log2(M) bits, while an anchor holds r*16 bits.**  So r is grossly
    over-provisioned for addressing, and a bigger budget should be spent on
    MORE PINS, not on more anchors.  Growing the fluid raises the per-token
    compute linearly in M; growing the register costs nothing at inference.

    If the requested M does not fit, M is reduced to the largest value that
    does -- and the reduction is reported, because silently over-committing
    the budget is how a "16 KB" claim turns into a 32 KB claim.
    """
    total = int(total_bytes)
    r = int(r)
    M_max = total // max(r * 2, 1)
    M_used = int(min(int(M), M_max))
    fluid = M_used * r * 2
    rest = max(total - fluid, 0)
    pins = rest // int(slot_bytes)
    return {
        "total_bytes": total,
        "M_requested": int(M),
        "M_used": M_used,
        "M_reduced": bool(M_used < int(M)),
        "r": r,
        "fluid_bytes": fluid,
        "register_bytes": int(pins) * int(slot_bytes),
        "pins": int(pins),
        "codebook_bytes": int(codebook_bytes),
        "artefact_bytes": int(total) + int(codebook_bytes),
        "fluid_pct": 100.0 * fluid / max(total, 1),
    }


# ------------------------------------------------------------------ adapter
class SheafMemoryAdapter:
    """Constant-size, geometry-addressed memory with an exact frozen register.

    Layout
     ------
     * `protos`  (M, d)  static prototype codebook -- part of the *prior
       artefact*, not the runtime state.
     * `anchors` (M, r)  the runtime fluid state (the "16 KB").
     * `register`         the exact tier (append-only).
     * `W_in`   (d, r)    value projection, part of the codebook.

    Read path:  query -> nearest prototype (address) -> anchor content (gist)
    Exact path: query -> content key -> register slot -> INTEGER token id.

    The two paths are deliberately separate.  A diffusion smears, so the
    value that must be exact never enters the diffusion.
    """

    def __init__(self, M: int = 1024, r: int = 8, d: int = 64,
                 capacity: int = 1024, seed: int = 0):
        self.M, self.r, self.d = int(M), int(r), int(d)
        rng = np.random.default_rng(seed)
        self.rng = rng
        self.protos = None
        self.anchors = np.zeros((self.M, self.r), dtype=np.float64)
        self.register = FrozenRegister(capacity=capacity)
        self.W_in = rng.normal(0.0, self.d ** -0.5, (self.d, self.r))
        self._L = None
        self._lam_max = None
        self.write_calls = 0
        self.tokens_written = 0

    # ------------------------------------------------------------- codebook
    def set_prototypes(self, protos: np.ndarray) -> None:
        """Install the static codebook (M, d) and rebuild the anchor graph."""
        P = np.asarray(protos, dtype=np.float64)
        if P.shape != (self.M, self.d):
            raise ValueError(f"prototypes must be ({self.M}, {self.d}), got {P.shape}")
        self.protos = P
        self._L = None

    def anchor_graph(self, k: int = 8):
        """k-NN graph over the prototypes -> signed sheaf Laplacian (numpy)."""
        if self.protos is None:
            raise RuntimeError("set_prototypes() first")
        from .sheaf import build_laplacian
        Pn = self.protos / (np.linalg.norm(self.protos, axis=1, keepdims=True) + 1e-12)
        S = Pn @ Pn.T
        np.fill_diagonal(S, -np.inf)
        nbr = np.argpartition(-S, kth=min(k, self.M - 1) - 1, axis=1)[:, :k]
        rows = np.repeat(np.arange(self.M), k)
        cols = nbr.reshape(-1)
        u = np.minimum(rows, cols)
        v = np.maximum(rows, cols)
        key = u.astype(np.int64) * self.M + v
        _, keep = np.unique(key, return_index=True)
        edges = np.stack([u[keep], v[keep]], axis=1)
        alpha = np.maximum(S[edges[:, 0], edges[:, 1]], 0.0) + 1e-3
        return edges, alpha, build_laplacian(self.M, edges, alpha)

    # --------------------------------------------------------------- routing
    def route(self, q: np.ndarray, k: int = 1):
        """Nearest prototype(s) for a query.  Returns (idx, scores)."""
        if self.protos is None:
            raise RuntimeError("set_prototypes() first")
        q = np.atleast_2d(np.asarray(q, dtype=np.float64))
        Pn = self.protos / (np.linalg.norm(self.protos, axis=1, keepdims=True) + 1e-12)
        qn = q / (np.linalg.norm(q, axis=1, keepdims=True) + 1e-12)
        sc = qn @ Pn.T
        if k == 1:
            idx = np.argmax(sc, axis=1)
            return idx, sc[np.arange(len(idx)), idx]
        order = np.argsort(-sc, axis=1)[:, :k]
        rows = np.arange(sc.shape[0])[:, None]
        return order, sc[rows, order]

    # ----------------------------------------------------------------- write
    def write(self, X: np.ndarray, t: float = 1.0, cheb_m: int = 12,
              diffuse: bool = True) -> None:
        """Streaming write of a chunk of embeddings (n, d).

        The diffusion is applied AFTER the scatter, which is exact for a
        linear operator:  exp(-tL)(S + Bx) = exp(-tL)S + exp(-tL)Bx.
        """
        X = np.asarray(X, dtype=np.float64)
        if X.ndim != 2 or X.shape[1] != self.d:
            raise ValueError(f"expected (n, {self.d}) embeddings, got {X.shape}")
        if X.shape[0] == 0:
            return
        idx, _ = self.route(X, k=1)
        proj = X @ self.W_in
        np.add.at(self.anchors, idx, proj)
        self.write_calls += 1
        self.tokens_written += int(X.shape[0])
        if diffuse:
            self.diffuse(t=t, cheb_m=cheb_m)

    def diffuse(self, t: float = 1.0, cheb_m: int = 12) -> None:
        """Apply exp(-t L) to the anchor state (the 'freezing' step)."""
        from .diffusion import cheb_basis, cheb_coeffs_exp, power_iteration_lmax
        if self.protos is None:
            return
        if self._L is None:
            self._L = self.anchor_graph(k=8)
        edges, alpha, L = self._L
        if self._lam_max is None:
            self._lam_max = power_iteration_lmax(L)
        lam = self._lam_max
        if lam <= 1e-8:
            return
        Y = cheb_basis(L, lam, self.anchors, cheb_m)
        a = cheb_coeffs_exp(t, lam, cheb_m)
        self.anchors = sum(a[k] * Y[k] for k in range(cheb_m + 1))

    # ------------------------------------------------------------------ read
    def read(self, q: np.ndarray, k: int = 1):
        """Geometry read: returns (anchor_idx, scores, content (r,))."""
        idx, sc = self.route(q, k=k)
        if k == 1:
            content = self.anchors[idx[0]]
            return idx, sc, content
        w = np.exp(sc - sc.max(axis=1, keepdims=True))
        w = w / w.sum(axis=1, keepdims=True)
        content = (self.anchors[idx] * w[:, :, None]).sum(axis=1)
        return idx, sc, content

    # ---------------------------------------------------------------- exact
    def promote(self, vec: np.ndarray, value_token_id: int, window,
                doc_id: int = 0, trust: int = 0):
        """Promote a fact into the register, anchored to its nearest prototype.

        Returns the slot index.  The fact's value NEVER enters the fluid, so
        it can never be smeared.
        """
        idx, _ = self.route(np.atleast_2d(np.asarray(vec, dtype=np.float64)), k=1)
        anchor = int(idx[0])
        sig = embedding_signature(vec)
        key = ctx_key(window, doc_id=doc_id)
        return self.register.promote(int(value_token_id), key, sig=sig,
                                     anchor=anchor, doc_id=doc_id, trust=trust)

    def recall(self, window, vec: np.ndarray | None = None):
        """Exact recall.  Returns (slot, token_id) or None.

        Verification: the 64-bit context key must match, and -- if `vec` is
        given -- the 4-byte embedding signature must match too.  A mismatch
        returns None (fail loud) instead of a wrong value.
        """
        key = ctx_key(window)
        sig = embedding_signature(vec) if vec is not None else None
        out = self.register.recall(key, sig=sig)
        if out is None:
            return None
        return out

    # ----------------------------------------------------------- accounting
    def state_bytes(self) -> int:
        """Runtime state only: anchors + register.  Excludes the codebook."""
        return int(self.anchors.size * 2) + self.register.nbytes()

    def codebook_bytes(self) -> int:
        """Static artefact: prototypes + value projection."""
        if self.protos is None:
            return int(self.W_in.size * 2)
        return int((self.protos.size + self.W_in.size) * 2)

    def stats(self) -> dict:
        s = self.register.stats()
        s.update({
            "M": self.M, "r": self.r, "d": self.d,
            "state_bytes": self.state_bytes(),
            "codebook_bytes": self.codebook_bytes(),
            "tokens_written": self.tokens_written,
            "write_calls": self.write_calls,
        })
        return s

#--- FILE: superfluid/model.py ---
"""
superfluid.model — SuperfluidLM and a param-matched transformer baseline.
Both models share: embedding, learned absolute positions, RMSNorm pre-norm
residual blocks, tied readout.  The only difference is the block body, so the
A/B in `train.py` isolates exactly one thing: dense attention vs. the
topological fluid.
"""
from __future__ import annotations

import numpy as np

from .autodiff import Tensor, concat, softmax_rows
from .blocks import RMSNorm, SuperfluidBlock

__all__ = ["SuperfluidLM", "TinyTransformer"]


def _collect(module, prefix, out):
    for name, val in vars(module).items():
        if isinstance(val, Tensor):
            out[f"{prefix}.{name}"] = val
    return out


class SuperfluidLM:
    def __init__(self, vocab: int, d: int = 64, n_layers: int = 2, n_ctx: int = 128,
                 seed: int = 0, **block_kw):
        rng = np.random.default_rng(seed)
        self.vocab, self.d, self.n_ctx = vocab, d, n_ctx
        self.emb = Tensor(rng.normal(0, 0.02, (vocab, d)))
        self.pos = Tensor(rng.normal(0, 0.01, (n_ctx, d)))
        self.blocks = [SuperfluidBlock(d, seed=seed + 17 * (i + 1), **block_kw)
                       for i in range(n_layers)]
        self.norm = RMSNorm(d)

    def forward(self, idx: np.ndarray) -> Tensor:
        idx = np.asarray(idx, dtype=np.int64)
        h = self.emb[idx] + self.pos[: idx.shape[0]]
        for b in self.blocks:
            h = b(h)
        h = self.norm(h)
        return h @ self.emb.T

    def forward_batch(self, x):
        """x: (B, T) token ids -> logits (B*T, V).  The block is sequence-local
        (the diffusion mixes positions inside one sequence), so we loop."""
        outs = [self.forward(x[b]) for b in range(x.shape[0])]
        return concat(outs, axis=0)

    def params(self) -> dict:
        p = {}
        _collect(self, "emb", p)
        _collect(self, "pos", p)
        for i, b in enumerate(self.blocks):
            _collect(b, f"b{i}", p)
            _collect(b.norm, f"b{i}.norm", p)
        _collect(self.norm, "norm", p)
        return p


class TinyTransformer:
    """Post-GPT transformer block (causal MHA + MLP), numpy/autodiff."""

    def __init__(self, vocab: int, d: int = 64, n_layers: int = 2, n_ctx: int = 128,
                 n_heads: int = 4, d_ff: int | None = None, seed: int = 0):
        rng = np.random.default_rng(seed)
        self.vocab, self.d, self.n_ctx = vocab, d, n_ctx
        self.n_heads = n_heads
        self.d_ff = d_ff or 4 * d
        self.emb = Tensor(rng.normal(0, 0.02, (vocab, d)))
        self.pos = Tensor(rng.normal(0, 0.01, (n_ctx, d)))
        self.layers = []
        for _ in range(n_layers):
            s = d ** -0.5
            self.layers.append({
                "Wq": Tensor(rng.normal(0, s, (d, d))),
                "Wk": Tensor(rng.normal(0, s, (d, d))),
                "Wv": Tensor(rng.normal(0, s, (d, d))),
                "Wo": Tensor(rng.normal(0, s, (d, d))),
                "W1": Tensor(rng.normal(0, (d * self.d_ff) ** -0.5, (d, self.d_ff))),
                "W2": Tensor(rng.normal(0, (d * self.d_ff) ** -0.5, (self.d_ff, d))),
                "n1": RMSNorm(d), "n2": RMSNorm(d),
            })
        self.norm = RMSNorm(d)

    def forward(self, idx: np.ndarray) -> Tensor:
        idx = np.asarray(idx, dtype=np.int64)
        n = idx.shape[0]
        h = self.emb[idx] + self.pos[:n]
        return self.forward_from_h(h)

    def forward_from_h(self, h: Tensor, return_hidden: bool = False):
        """Continue the forward pass from a (possibly MODIFIED) residual stream.

        This is the hook a grafted memory layer needs: the branch rewrites `h`
        and the frozen base model processes the rest.  Splitting `forward` into
        "embed" + "forward_from_h" is what makes a *training-free* attachment
        to an already-trained model possible at all.
        """
        n = h.data.shape[0]
        causal = np.triu(np.ones((n, n), dtype=bool), k=1)
        H, dh = self.n_heads, self.d // self.n_heads
        for L in self.layers:
            x = L["n1"](h)
            q = x @ L["Wq"]
            k = x @ L["Wk"]
            v = x @ L["Wv"]
            outs = []
            for hh in range(H):
                sl = slice(hh * dh, (hh + 1) * dh)
                qh = q[:, sl]
                kh = k[:, sl]
                vh = v[:, sl]
                sc = (qh @ kh.T) * (dh ** -0.5)
                a = softmax_rows(sc, mask=causal)
                outs.append(a @ vh)
            o = np.concatenate([o.data for o in outs], axis=1)
            oT = Tensor(o)
            h = h + oT @ L["Wo"]
            y = L["n2"](h)
            h = h + (y @ L["W1"]).gelu() @ L["W2"]
        h = self.norm(h)
        logits = h @ self.emb.T
        return (logits, h) if return_hidden else logits

    def forward_batch(self, x):
        outs = [self.forward(x[b]) for b in range(x.shape[0])]
        return concat(outs, axis=0)

    def params(self) -> dict:
        p = {}
        _collect(self, "emb", p)
        _collect(self, "pos", p)
        for i, L in enumerate(self.layers):
            for k, v in L.items():
                if isinstance(v, Tensor):
                    p[f"L{i}.{k}"] = v
            p[f"L{i}.n1.g"] = L["n1"].g
            p[f"L{i}.n2.g"] = L["n2"].g
        _collect(self.norm, "norm", p)
        return p

#--- FILE: superfluid/losses.py ---
"""
superfluid.losses — training objective for the fluid stack.

  L_total = CE(next-token)
          + w_E  * sheaf energy        (smoothness / consistency on edges)
          + w_D  * band decorrelation  (keep the filter bank from collapsing)
          + w_G  * spectral gap bonus  (anti-oversmoothing, diagnostic only)

The "topological sufficiency" term of the framework spec is implemented as a
*probe* (see `probe.py`) rather than as a gradient, because the routing
decision is a hard top-k selection and carries no gradient path.
"""

from __future__ import annotations

import numpy as np

__all__ = ["cross_entropy", "sheaf_energy_loss", "band_decorrelation", "gap_bonus"]


def cross_entropy(logits, targets) -> float:
    """Mean token cross-entropy from logits (n, V) and targets (n,)."""
    z = logits.data
    z = z - z.max(axis=1, keepdims=True)
    logZ = np.log(np.exp(z).sum(axis=1))
    ll = z[np.arange(len(targets)), targets] - logZ
    return float(-ll.mean())


def cross_entropy_grad(logits, targets) -> np.ndarray:
    """d(mean CE)/d(logits) — (n, V)."""
    z = logits.data
    z = z - z.max(axis=1, keepdims=True)
    e = np.exp(z)
    p = e / e.sum(axis=1, keepdims=True)
    g = p.copy()
    g[np.arange(len(targets)), targets] -= 1.0
    return g / len(targets)


def cross_entropy_tensor(logits, targets):
    """Differentiable mean token cross-entropy (returns a Tensor)."""
    n = len(targets)
    m = logits.max(axis=1, keepdims=True)
    z = logits - m
    logZ = z.exp().sum(axis=1, keepdims=True).log() + m
    picked = logits[np.arange(n), np.asarray(targets, dtype=np.int64)]
    return (-(picked - logZ.reshape(-1))).mean()


def sheaf_energy_loss(block) -> float:
    """Total variation of the field over the routed edges (diagnostic scalar)."""
    d = block.diag
    if not d:
        return 0.0
    return float(d.get("sheaf_energy", 0.0))


def band_decorrelation(bands) -> float:
    """1 - mean |cos| between band responses.

    If two bands collapse onto the same spectral mode the filter bank stops
    being a frame and information is lost (the rank-c trap in a different
    disguise).  This penalises that.
    """
    if not bands or len(bands) < 2:
        return 0.0
    M = []
    for b in bands:
        v = b.data.reshape(-1)
        nrm = np.linalg.norm(v)
        M.append(v / nrm if nrm > 1e-12 else v)
    M = np.stack(M)
    C = M @ M.T
    off = C - np.eye(len(M)) * np.diag(C)
    iu = np.triu_indices(len(M), k=1)
    return float(np.mean(np.abs(off[iu])))


def gap_bonus(L) -> float:
    """lambda_2 of a (numpy) Laplacian -- anti-oversmoothing diagnostic."""
    from .diffusion import spectral_gap
    try:
        return float(spectral_gap(L))
    except Exception:
        return 0.0

#--- FILE: superfluid/optim.py ---
"""
superfluid.optim — Adam, implemented locally (no torch in this environment).
"""

from __future__ import annotations

import numpy as np


class Adam:
    """Adam with decoupled weight decay and gradient clipping."""

    def __init__(self, params: dict, lr: float = 1e-3, betas=(0.9, 0.999),
                 eps: float = 1e-8, weight_decay: float = 0.0, clip: float = 1.0):
        self.params = params
        self.lr = lr
        self.b1, self.b2 = betas
        self.eps = eps
        self.wd = weight_decay
        self.clip = clip
        self.t = 0
        # params: name -> Tensor  (Tensor has .data and .grad)
        self.m = {k: np.zeros_like(v.data) for k, v in params.items()}
        self.v = {k: np.zeros_like(v.data) for k, v in params.items()}

    def zero_grad(self):
        for p in self.params.values():
            p.grad = np.zeros_like(p.data)

    def step(self, lr: float | None = None):
        self.t += 1
        lr = self.lr if lr is None else lr
        b1c = 1 - self.b1 ** self.t
        b2c = 1 - self.b2 ** self.t
        total_sq = 0.0
        for p in self.params.values():
            g = p.grad
            total_sq += float(np.sum(g * g))
        norm = np.sqrt(total_sq)
        scale = 1.0
        if self.clip and norm > self.clip:
            scale = self.clip / (norm + 1e-12)
        for k, p in self.params.items():
            g = p.grad * scale
            if self.wd:
                g = g + self.wd * p.data
            self.m[k] = self.b1 * self.m[k] + (1 - self.b1) * g
            self.v[k] = self.b2 * self.v[k] + (1 - self.b2) * (g * g)
            mhat = self.m[k] / b1c
            vhat = self.v[k] / b2c
            p.data -= lr * mhat / (np.sqrt(vhat) + self.eps)

    def lr_at(self, step: int, total: int, warmup: int = 200, floor: float = 0.1):
        if step < warmup:
            return self.lr * (step + 1) / warmup
        p = (step - warmup) / max(1, total - warmup)
        return self.lr * (floor + (1 - floor) * 0.5 * (1 + np.cos(np.pi * min(p, 1.0))))

#--- FILE: superfluid/data.py ---
"""
superfluid.data — tiny corpora + char-level tokenizer.

Prefers a real public-domain text (Project Gutenberg).  If the sandbox has no
outbound network access it falls back to a deterministic synthetic corpus so
that the A/B training run is always reproducible.
"""

from __future__ import annotations

import os
import urllib.request

import numpy as np

__all__ = ["get_corpus", "CharTokenizer", "batchify", "GUTENBERG_URLS"]

GUTENBERG_URLS = [
    "https://www.gutenberg.org/files/11/11-0.txt",     # Alice in Wonderland
    "https://www.gutenberg.org/cache/epub/11/pg11.txt",
]


def get_corpus(max_chars: int = 120_000, cache: str | None = None) -> str:
    """Return a text corpus (>= max_chars if possible)."""
    cache = cache or os.path.join(os.path.dirname(__file__), "..", "corpus.txt")
    if os.path.exists(cache):
        with open(cache, encoding="utf-8", errors="ignore") as f:
            t = f.read()
        if len(t) >= 1000:
            return t[:max_chars]
    for url in GUTENBERG_URLS:
        try:
            with urllib.request.urlopen(url, timeout=12) as r:
                raw = r.read().decode("utf-8", errors="ignore")
            start = raw.find("*** START")
            if start >= 0:
                raw = raw[start:]
            end = raw.find("*** END")
            if end > 0:
                raw = raw[:end]
            raw = raw.replace("\r\n", "\n")
            if len(raw) > 2000:
                try:
                    os.makedirs(os.path.dirname(os.path.abspath(cache)), exist_ok=True)
                    with open(cache, "w", encoding="utf-8") as f:
                        f.write(raw)
                except OSError:
                    pass
                return raw[:max_chars]
        except Exception:
            continue
    return _synthetic_corpus(max_chars)


def _synthetic_corpus(n: int) -> str:
    """Deterministic fallback: a Zipfian character process with word structure."""
    rng = np.random.default_rng(1234)
    words = ["the", "cat", "sat", "on", "a", "mat", "and", "then", "said", "little",
             "queen", "of", "hearts", "alice", "rabbit", "hole", "tea", "party",
             "night", "tree", "house", "river", "cloud", "stone", "light", "voice"]
    p = np.arange(1, len(words) + 1) ** -1.1
    p /= p.sum()
    out = []
    while sum(len(w) + 1 for w in out) < n:
        k = rng.choice(len(words), size=rng.integers(4, 14), p=p)
        out.extend(words[i] for i in k)
    s = " ".join(out)
    return s[:n]


class CharTokenizer:
    def __init__(self, text: str):
        self.chars = sorted(set(text))
        self.stoi = {c: i for i, c in enumerate(self.chars)}
        self.itos = self.chars

    def encode(self, text: str) -> np.ndarray:
        return np.array([self.stoi[c] for c in text], dtype=np.int64)

    def decode(self, ids) -> str:
        return "".join(self.itos[int(i)] for i in ids)

    @property
    def vocab(self) -> int:
        return len(self.chars)


def batchify(tokens: np.ndarray, batch_size: int) -> np.ndarray:
    """(N,) -> (batch_size, N//batch_size) contiguous split."""
    nb = len(tokens) // batch_size
    return tokens[: nb * batch_size].reshape(batch_size, nb)

#--- FILE: superfluid/graft.py ---
"""
superfluid.graft — the attachable memory layer.

WHAT THIS IS
------------
A single module you can bolt onto ANY causal LM with one insertion:

        h' = h + W_e . E(h)  +  W_l . S(h)
                 ^^^^^^^         ^^^^^^^
                 exact tier      lossy tier (the constant-size fluid state)

    E(h)  = the EXACT read:  a bounded, CONTENT-KEYED store of token ids,
            pulled back out through the model's own embedding table.
    S(h)  = the LOSSY read:  the diffused aggregate state (M x r floats).

WHY IT IS SAFE TO ATTACH
------------------------
`W_e` and `W_l` are initialised to ZERO, so at the moment of attachment the
branch is an EXACT identity:  h' == h, bit for bit.  Every logit, every
perplexity, every sampled token is unchanged.  The layer can only start to
matter after someone trains it, and training it is opt-in.

WHY THERE ARE TWO TIERS
-----------------------
A diffusion smears.  If the exact value of a token lives only inside the
fluid, it is mixed with its neighbours and is no longer exact.  So:

    the fluid answers WHERE   (an address space of M anchors)
    the store answers WHAT    (an int32 token id, keyed by content)

The store is CONTENT-KEYED, not anchor-keyed.  That distinction matters and
it was learned the hard way: a per-anchor "last write wins" slot is evicted
by ordinary filler tokens within a few hundred tokens, because every token
routs somewhere.  Keying by the content of the context means a fact is only
overwritten by the SAME context occurring again -- which is exactly the
semantics you want (and it is the same trick as the frozen register's
`ctx_key`).

CAUSALITY
---------
The store is written CAUSALLY.  At position t the branch has seen tokens
x_0..x_t only.  The pair (context ending at t-1, next token x_t) is complete
at time t, so the write happens at time t -- never earlier.  The read at
position t uses the context ending at t, which is a DIFFERENT key from the
one being written, so a token can never be read back before it was written
and the model can never "copy the current token" through the store.

PERSISTENCE
-----------
The state (`state`, `store`) lives on the object, NOT in the autodiff graph.
It survives across calls: that is what makes it a *memory* rather than a
layer.  `reset()` clears it (a new document / a new session).
"""

from __future__ import annotations

import numpy as np

from .autodiff import Tensor, softmax_rows
from .diffusion import cheb_coeffs_exp, power_iteration_lmax

__all__ = ["SAABranch", "GRAFT_STATE_BYTES", "ctx_hash"]


def ctx_hash(tokens) -> int:
    """FNV-1a 64-bit hash of a token sequence (the content key)."""
    h = 0xCBF29CE484222325
    for t in tokens:
        h ^= int(t) & 0xFFFFFFFFFFFFFFFF
        h = (h * 0x100000001B3) & 0xFFFFFFFFFFFFFFFF
    return h


def _knn_edges(X: np.ndarray, k: int) -> np.ndarray:
    """Undirected kNN edge list of a point set (cosine similarity)."""
    n = X.shape[0]
    Xn = X / (np.linalg.norm(X, axis=1, keepdims=True) + 1e-12)
    S = Xn @ Xn.T
    np.fill_diagonal(S, -np.inf)
    kk = min(k, n - 1)
    idx = np.argsort(-S, axis=1)[:, :kk]
    rows = np.repeat(np.arange(n), kk)
    cols = idx.reshape(-1)
    e = np.stack([np.minimum(rows, cols), np.maximum(rows, cols)], axis=1)
    return np.unique(e, axis=0)


class _ModeStore:
    """A content-keyed store that keeps the MAJORITY value and a confidence.

    The counts fit in the frozen register's existing `meta uint16`, so a
    packed slot stays 20 bytes.
    """

    __slots__ = ("value", "support", "disagree", "order", "capacity")

    def __init__(self, capacity: int = 4096):
        self.value: dict = {}
        self.support: dict = {}
        self.disagree: dict = {}
        self.order: list = []
        self.capacity = int(capacity)

    def __len__(self):
        return len(self.value)

    def __contains__(self, key):
        return key in self.value

    def __getitem__(self, key):
        return self.value[key]

    def keys(self):
        return list(self.order)

    def get(self, key, default=-1):
        return self.value.get(key, default)

    def confidence(self, key) -> float:
        if key not in self.value:
            return 0.0
        a = self.support.get(key, 1)
        b = self.disagree.get(key, 0)
        return float(a) / float(max(a + b, 1))

    def put(self, key, value):
        if key in self.value:
            if self.value[key] == value:
                self.support[key] = self.support.get(key, 1) + 1
            else:
                a = self.support.get(key, 1)
                b = self.disagree.get(key, 0) + 1
                if b > a:
                    self.value[key] = int(value)
                    self.support[key] = b
                    self.disagree[key] = a
                else:
                    self.disagree[key] = b
            return
        if len(self.value) >= self.capacity:
            self._evict()
        self.value[key] = int(value)
        self.support[key] = 1
        self.disagree[key] = 0
        self.order.append(int(key))

    def _evict(self):
        """Evict the LEAST corroborated entry, not merely the oldest."""
        worst, worst_key = None, None
        for k in self.order:
            sc = self.support.get(k, 0) - self.disagree.get(k, 0)
            if worst is None or sc < worst:
                worst, worst_key = sc, k
        if worst_key is None:
            return
        self.value.pop(worst_key, None)
        self.support.pop(worst_key, None)
        self.disagree.pop(worst_key, None)
        if worst_key in self.order:
            self.order.remove(worst_key)

    def clear(self):
        self.value.clear()
        self.support.clear()
        self.disagree.clear()
        self.order.clear()


class SAABranch:
    """The attachable memory layer (see the module docstring).

    Parameters
    ----------
    M      : number of anchors (the address space).  M*r*8 bytes is the
             constant runtime state of the lossy tier.
    r      : rank of each anchor's state.
    d      : model width.
    emb    : the model's embedding table (V x d).  Needed to turn a stored
             token id back into a vector.  Shared, never copied.
    ctx_len: how many trailing tokens form the content key (1 = a token-level
             "what followed this token" memory; k = a k-gram memory).
    capacity: max entries in the exact store.
    use_exact / use_lossy : ablation switches (measured in E6).
    """

    def __init__(self, M: int = 64, r: int = 8, d: int = 64, emb=None,
                 k: int = 4, cheb_m: int = 8, t: float = 1.0, seed: int = 0,
                 use_exact: bool = True, use_lossy: bool = True,
                 capacity: int = 4096, ctx_len: int = 1,
                 trainable_route: bool = True, read_gain: str = "norm",
                 center: bool = True, read_transform: str = "pc1",
                 state_mode: str = "persistent", hist_len: int = 8,
                 inject_mode: str = "state", use_router: bool = True):
        for name, val in (("M", M), ("r", r), ("capacity", capacity)):
            if int(val) <= 0:
                raise ValueError(f"{name} must be positive, got {val}")
        if emb is not None and int(emb.shape[1]) != int(d):
            raise ValueError(f"d={d} does not match the embedding width "
                             f"{emb.shape[1]}")
        if str(state_mode) not in ("persistent", "rebuild"):
            raise ValueError("state_mode must be 'persistent' or 'rebuild'")
        if str(read_gain) not in ("norm", "raw"):
            raise ValueError("read_gain must be 'norm' or 'raw'")
        if (str(read_transform) not in ("raw", "center")
                and not str(read_transform).startswith("pc")):
            raise ValueError("read_transform must be 'raw', 'center' or 'pcK'")
        rng = np.random.default_rng(seed)
        self.M, self.r, self.d = int(M), int(r), int(d)
        self.k, self.cheb_m, self.t = int(k), int(cheb_m), float(t)
        self.use_exact, self.use_lossy = bool(use_exact), bool(use_lossy)
        self.use_router = bool(use_router)
        self.emb = emb
        self.center = bool(center)
        self.read_transform = str(read_transform)
        self._contrast = None
        self.ctx_len = int(ctx_len)
        self.capacity = int(capacity)
        self.read_gain = str(read_gain)
        self.read_scale = 1.0
        self.protos = Tensor(rng.normal(0.0, d ** -0.5, (M, d)))

        # route head: content -> anchor scores.  The route head is a function
        # of CONTENT ONLY (no position), so the same context always lands on
        # the same anchor -- the fluid addresses by geometry, not by position.
        s = d ** -0.5
        self.Wq = Tensor(rng.normal(0.0, s, (d, d)))
        self.Wk = Tensor(rng.normal(0.0, s, (d, d)))
        self.Wv = Tensor(rng.normal(0.0, s, (d, r)))     # write projection
        self.Wr = Tensor(rng.normal(0.0, s, (r, d)))     # lossy read projection
        # The LAYER-LOCAL head: the layer predicts the next token from its
        # own state.  This is the objective that FIXES the divergence: the
        # layer is trained on a well-posed task of its own, and the base
        # model's gradients never enter the layer's parameters.
        V = emb.shape[0] if emb is not None else 0
        self.V = int(V)
        self.Wp = Tensor(rng.normal(0.0, r ** -0.5, (r, V))) if V else None
        self.bias = Tensor(np.zeros(V)) if V else None
        # output projections: ZERO => the branch is an exact identity at attach
        self.Wo_exact = Tensor(np.zeros((d, d)))
        self.Wo_lossy = Tensor(np.zeros((d, d)))
        self.trainable_route = bool(trainable_route)
        # "persistent": the state is a numpy accumulator (the ORIGINAL design;
        # it cannot be differentiated, which is what made the training
        # diverge).
        # "rebuild":    the state is REBUILT from a bounded history INSIDE
        #              the autodiff graph every call (truncated BPTT), so the
        #              gradient is exact and bounded.  The state VALUES are
        #              identical (the diffusion is linear); only the gradient
        #              path is new.
        self.state_mode = str(state_mode)
        # "state": the raw diffused read is injected (the original design).
        # "prior": the layer's OWN next-token distribution is projected into
        #          the residual through the embedding table -- a soft domain
        #          prior, and the only injection the layer-local objective
        #          can honestly justify.
        self.inject_mode = str(inject_mode)
        self.hist_len = int(hist_len)
        self._hist: list = []

        # ---- the persistent state -------------------------------------
        self.state = np.zeros((M, r))                  # lossy tier
        # the EXACT tier: a content-keyed store (a precise answer, a bounded
        # reach -- only the last ~capacity contexts)
        self.store = _ModeStore(capacity=capacity)
        # the ROUTER tier: ONE entry per anchor of the fluid.  The fluid's
        # geometry decides WHICH anchor a context belongs to, so this tier
        # has the WHOLE stream's reach (M entries, never evicted) at a
        # cluster-level precision.  "the fluid answers WHERE, the register
        # answers WHAT" -- made literal.
        self.anchor_store = _ModeStore(capacity=M)
        self.store_order: list[int] = []               # FIFO eviction order
        self._buf: list[int] = []                      # rolling context window
        self.write_calls = 0
        self.tokens_written = 0
        self.store_hits = 0
        self.store_lookups = 0

        # the address graph (constant: the prototypes are fixed)
        self.edges = _knn_edges(self.protos.data, k)
        n = M
        A = np.zeros((n, n))
        for a, b in self.edges:
            A[a, b] = 1.0
            A[b, a] = 1.0
        self.L = np.diag(A.sum(axis=1)) - A
        self.lam_max = float(power_iteration_lmax(self.L))
        self._cheb = (cheb_coeffs_exp(self.t, self.lam_max, self.cheb_m)
                      if self.lam_max > 0 else np.array([1.0]))

    # ------------------------------------------------------------- lifecycle
    def reset(self):
        """Clear the memory (new document / new session)."""
        self.state[:] = 0.0
        self.store.clear()
        self.anchor_store.clear()
        self._buf.clear()

    def support_snapshot(self, retrieved):
        """The confirmation count of each retrieved value (0 = never seen)."""
        return np.array([self.store.support.get(int(r), 0) if r >= 0 else 0
                         for r in retrieved], dtype=np.int64)

    def confidence_snapshot(self, retrieved, keys=None):
        """The corroboration ratio of each retrieved value."""
        out = np.zeros(len(retrieved))
        for i, r in enumerate(retrieved):
            if r < 0:
                continue
            if keys is not None:
                out[i] = self.confidence(int(keys[i]))
            else:
                out[i] = 1.0
        return out

    @property
    def state_bytes(self) -> int:
        """Constant runtime state: the diffusion state + the exact store."""
        return self.state.size * 8 + len(self.store) * 20

    def params(self) -> dict:
        p = {
            "Wq": self.Wq, "Wk": self.Wk, "Wv": self.Wv, "Wr": self.Wr,
            "Wo_exact": self.Wo_exact, "Wo_lossy": self.Wo_lossy,
        }
        if self.Wp is not None:
            p["Wp"] = self.Wp
            p["bias"] = self.bias
        if not self.trainable_route:
            for k in ("Wq", "Wk"):
                p.pop(k, None)
        return p

    # ------------------------------------------------------- the contrast table
    def refresh_contrast(self):
        """Recompute the mean-centred embedding table.

        WHY: the readout is TIED (logits = h . emb.T), so injecting a token's
        embedding v into the residual boosts the logit of every token u by
        gain * (emb[v] . emb[u]).  Embedding rows are NOT orthogonal, so the
        raw injection also boosts v's embedding-space NEIGHBOURS -- measured:
        the target's logit 134.9 vs the winner's 151.1, i.e. the injection
        made the WRONG token win.  Removing the shared (mean) direction
        makes the boost selective: the target's logit then wins outright.

        The table is cached because for a real LLM (V=50k, d=4096) computing
        the mean on every forward would be absurd.  Call refresh_contrast()
        after the base model has been (re)trained.
        """
        self._contrast = None

    def _contrast_table(self):
        """The table the exact read pulls from: the embedding matrix, possibly
        transformed so that the injection is SELECTIVE.

        "raw"    : the plain embedding (leaks into the neighbours)
        "center" : mean-centred (removes the shared direction)
        "pcK"    : the top-K principal directions of the embedding matrix are
                   projected out.  This is the one that works: with a TIED
                   readout, logit_u += gain * (emb[v] . emb[u]), so a raw
                   injection boosts v's embedding-space neighbours as well.
                   Measured on the graft benchmark: raw 0.725, pc1 0.800.
        """
        if self._contrast is None:
            if self.emb is None:
                return None
            E = self.emb.data
            t = self.read_transform
            if t == "raw":
                self._contrast = E.copy()
            elif t == "center":
                self._contrast = E - E.mean(axis=0, keepdims=True)
            elif t.startswith("pc"):
                k = int(t[2:] or 1)
                # the SVD is O(V d^2): for a real LLM do it OFFLINE once and
                # ship the table, or use a randomized SVD on a subsample.
                _, _, Vt = np.linalg.svd(E, full_matrices=False)
                T = E.copy()
                for j in range(min(k, Vt.shape[0])):
                    p = Vt[j]
                    T = T - np.outer(T @ p, p)
                self._contrast = T
            else:
                self._contrast = E.copy()
        return self._contrast

    # ----------------------------------------------------------------- maths
    def _diffuse(self) -> np.ndarray:
        """exp(-t L) applied to the anchor state, by Chebyshev expansion.

        The state is a persistent, non-differentiable accumulator (it lives
        outside the autodiff graph on purpose: it is a MEMORY, not an
        activation).  The gradient therefore flows only through the READ.
        """
        if self.lam_max <= 0:
            return self.state
        n = self.M
        Lt = (2.0 / self.lam_max) * self.L - np.eye(n)
        Y = [self.state]
        if self.cheb_m >= 1:
            Y.append(Lt @ Y[0])
            for k in range(2, self.cheb_m + 1):
                Y.append(2.0 * (Lt @ Y[k - 1]) - Y[k - 2])
        out = np.zeros_like(self.state)
        for k, a in enumerate(self._cheb):
            if k < len(Y):
                out += a * Y[k]
        return out

    def _diffuse_tensor(self, S: Tensor) -> Tensor:
        """exp(-t L) applied to a TENSOR state (the differentiable path)."""
        if self.lam_max <= 0:
            return S
        n = self.M
        Lt = (2.0 / self.lam_max) * Tensor(self.L) - Tensor(np.eye(n))
        Y = [S]
        if self.cheb_m >= 1:
            Y.append(Lt @ Y[0])
            for k in range(2, self.cheb_m + 1):
                Y.append(2.0 * (Lt @ Y[k - 1]) - Y[k - 2])
        out = Tensor(np.zeros_like(S.data))
        for k, a in enumerate(self._cheb):
            if k < len(Y):
                out = out + a * Y[k]
        return out

    def _rebuild_state(self, h: Tensor, content: Tensor):
        """Rebuild the anchor state from a bounded history, inside the graph.

        The diffusion is LINEAR, so exp(-tL)(sum of writes) = sum of
        exp(-tL)(writes): the rebuilt state has the SAME VALUES as the
        persistent accumulator, but now every write is differentiable.
        """
        parts = []
        for (hh, cc) in self._hist:
            w_np, _ = self._route(cc)
            parts.append(Tensor(w_np).T @ (Tensor(hh) @ self.Wv))
        w_np, _ = self._route(content.data)
        parts.append(Tensor(w_np).T @ (h @ self.Wv))
        S = parts[0]
        for p in parts[1:]:
            S = S + p
        return self._diffuse_tensor(S)

    def _route(self, content: np.ndarray):
        """(T, d) content -> (T, M) soft top-k routing weights + the argmax."""
        q = content @ self.Wq.data                 # (T, d)
        kk = self.protos.data @ self.Wk.data       # (M, d)
        sc = (q @ kk.T) / (self.d ** 0.5)          # (T, M)
        top = np.argsort(-sc, axis=1)[:, : min(self.k, self.M)]
        w = np.zeros_like(sc)
        rows = np.arange(sc.shape[0])[:, None]
        s_top = sc[rows, top]
        s_top = s_top - s_top.max(axis=1, keepdims=True)
        e = np.exp(s_top)
        e = e / e.sum(axis=1, keepdims=True)
        w[rows, top] = e
        return w, top[:, 0]

    # ---------------------------------------------------------------- forward
    def forward(self, h: Tensor, content: Tensor, token_ids: np.ndarray):
        """Return (h_out, info).  `h` and `content` are Tensors (T, d).

        `content` is the position-free representation used for routing.
        `token_ids` are the tokens CONSUMED at each position.
        """
        token_ids = np.asarray(token_ids, dtype=np.int64)
        T = token_ids.shape[0]
        w_np, am = self._route(content.data)     # routing is not differentiable
        w = Tensor(w_np)

        # ---- the lossy tier: write, diffuse, read ----------------------
        out_l = None
        state_read = None
        if self.use_lossy:
            if self.state_mode == "rebuild":
                # differentiable: the state is rebuilt inside the graph
                S = self._rebuild_state(h, content)
                self.state = S.data.copy()          # keep a numpy copy for inspection
                state_read = w @ S                  # (T, r)  <- differentiable
                out_l = state_read @ self.Wr        # (T, d)
            else:
                self.state += w_np.T @ (h.data @ self.Wv.data)   # write
                self.state = self._diffuse()                      # diffuse
                state_read = w @ Tensor(self.state)              # (T, r)
                out_l = state_read @ self.Wr                      # (T, d)
            if self.inject_mode == "prior" and self.Wp is not None:
                z = self.layer_logits({"state_read": state_read})
                if z is not None:
                    pr = softmax_rows(z)                          # (T, V)
                    out_l = pr @ self.emb.data                    # (T, d)

        # ---- the exact tier: content-keyed store -----------------------
        out_e = None
        hits = 0
        retrieved = np.full(T, -1, dtype=np.int64)
        conf_arr = np.zeros(T, dtype=float)
        router_retrieved = np.full(T, -1, dtype=np.int64)
        router_conf = np.zeros(T, dtype=float)
        if self.use_exact and self.emb is not None:
            read_ids = np.zeros((T, self.d))
            buf = list(self._buf)
            for t in range(T):
                prev_key = self._key(buf)
                buf.append(int(token_ids[t]))
                if len(buf) > self.ctx_len:
                    buf = buf[-self.ctx_len:]
                key = self._key(buf)
                self.store_lookups += 1
                # the ROUTER tier first (it has the whole-stream reach),
                # then the exact tier (a precise answer, a bounded reach)
                if self.use_router:
                    av = self.anchor_store.get(int(am[t]), -1)
                    if av >= 0:
                        router_retrieved[t] = av
                        router_conf[t] = self.anchor_store.confidence(int(am[t]))
                v = self.store.get(key, -1)
                if v >= 0:
                    retrieved[t] = v
                    conf_arr[t] = self.confidence(key)
                    vec = self.emb.data[v]
                    if self.center:
                        C = self._contrast_table()
                        if C is not None:
                            vec = C[v]
                    if self.read_gain == "raw":
                        vec = vec * float(self.read_scale)
                    elif self.read_gain == "norm":
                        # inject the recalled token AT THE RESIDUAL'S OWN SCALE.
                        # Without this the injected embedding is ~50x smaller
                        # than the residual and simply cannot move the argmax.
                        hn = float(np.linalg.norm(h.data[t]))
                        vn = float(np.linalg.norm(vec))
                        if vn > 1e-12:
                            vec = vec * (hn / vn)
                    read_ids[t] = vec
                    hits += 1
                # causal write: the pair (context ending at t-1, x_t) is
                # complete NOW, so it is written NOW -- never earlier.
                if prev_key is not None:
                    self._put(prev_key, int(token_ids[t]))
                # the ROUTER tier: the pair is filed under the ANCHOR of the
                # previous position -- the fluid's geometry decides which
                # anchor a context belongs to, so this tier never evicts and
                # its reach is the WHOLE stream.
                if t > 0 and self.use_router:
                    self.anchor_store.put(int(am[t - 1]), int(token_ids[t]))
            self._buf = buf
            out_e = Tensor(read_ids)

        # ---- combine ----------------------------------------------------
        h_out = h
        if out_e is not None:
            h_out = h_out + out_e @ self.Wo_exact
        if out_l is not None:
            h_out = h_out + out_l @ self.Wo_lossy

        if self.state_mode == "rebuild":
            self._hist.append((h.data.copy(), content.data.copy()))
            if len(self._hist) > self.hist_len:
                self._hist = self._hist[-self.hist_len:]
        self.write_calls += 1
        self.tokens_written += T
        self.store_hits += hits
        return h_out, {"route": w_np, "anchor": am, "hits": hits,
                       "state_read": state_read, "emb_read": out_e,
                       "retrieved": retrieved,
                       "support": self.support_snapshot(retrieved),
                       "confidence": conf_arr,
                       "router_retrieved": router_retrieved,
                       "router_confidence": router_conf}

    # ------------------------------------------------------------- the gate
    def gated_logits(self, logits, info, gain: float = 8.0,
                     use_support: bool = False, support_scale: float = 1.0,
                     tau: float | None = None, c_min: float = 2.0,
                     big: float = 20.0, router_weight: float = 0.3,
                     gate_space: str = "logit"):
        """Apply the retrieval as a GATED override, in logit space.

        THE PROBLEM THIS SOLVES.  The injection gain that maximises RECALL
        (300) and the one that maximises GENERATION quality (0.3) are three
        orders of magnitude apart: a hard override must be strong enough to
        win the argmax, but a strong override forces a wrong retrieval into
        the model and ruins it (+1.08 nats).

        THE GATE.  The base model's OWN uncertainty at that position:

            u_t = 1 - max_v p(v)

        and the retrieved token's logit is boosted by  gain * u_t.

        WHY ONE KNOB SERVES BOTH.  In the recall task the base model has no
        idea what comes next (u ~ 1), so the retrieval decides.  In the
        generation task the base model is usually confident (u ~ 0), so the
        retrieval is ignored.  The gate is not a second hyper-parameter --
        it is the model's own confidence.

        TWO RULES make this exact rather than merely safe:

        RULE 1 (the clueless rule) -- **OFF BY DEFAULT** (`tau=2`, i.e. it
        never fires).  If the base model is clueless (u_t >= tau), the
        retrieval decides outright.  It is off because it was measured to
        be DANGEROUS: on real text a character-level model's top-1
        probability is often below 0.5, so the rule fired constantly and
        forced wrong retrievals into the model (+0.65 nats, E11c).

        It is also unnecessary: the SOFT GATE ALREADY delivers the full
        recall.  At u ~ 0.99 the boost is gain * u ~ 8, which is enough to
        win the argmax, and a wrong override then costs ~8 nats instead
        of ~60.  Measured: the soft gate alone reaches a recall of
        **1.000** (E11a).

        RULE 2 (the trusted-memory rule) -- **OFF BY DEFAULT** (`c_min=2`,
        i.e. it never fires).  If the retrieval has never been contradicted
        (its confidence >= c_min), it would decide as well.  It is off
        because it was measured to be dangerous: on real text many
        contexts have a deterministic-looking continuation that is still
        wrong for a new occurrence, and forcing those overrides made the
        base model's loss explode (E11c).  The base model's own
        uncertainty (RULE 1) is the reliable signal.

        Otherwise: the soft gate, boost = gain * u_t.

        `logits` is (T, V) numpy or a Tensor; the result is the same type.
        """
        from .autodiff import Tensor as _T
        is_tensor = isinstance(logits, _T)
        z = logits.data if is_tensor else np.asarray(logits)
        retrieved = info.get("retrieved")
        if retrieved is None:
            return logits
        retrieved = np.asarray(retrieved)
        T, V = z.shape
        # THE FALLBACK CHAIN.  The exact tier answers when it has the
        # context (a precise answer, a bounded reach).  When it does not --
        # the context is older than the store's reach -- the ROUTER tier
        # answers instead: the fluid's geometry puts the context in a
        # cluster, and the cluster's majority continuation is the best
        # available answer.  It gets a smaller boost (router_weight),
        # because it is a cluster-level guess, not a fact.
        rr = info.get("router_retrieved")
        rconf = info.get("router_confidence")
        if rr is not None:
            rr = np.asarray(rr)
            fallback = (retrieved < 0) & (rr >= 0)
            retrieved = np.where(fallback, rr, retrieved)
        else:
            fallback = np.zeros(T, dtype=bool)
        # THE MODEL'S OWN UNCERTAINTY.
        # "logit" space (the default):  u = -log p_max, i.e. how many nats
        # the model is away from being sure.  This is SCALE-FREE: the same
        # gain works on a 131k-parameter model (whose logits span +-2) and on
        # GPT-2 (whose logits span +-20).  Measured on real GPT-2: the
        # probability-space gate needed a gain of 50+ and hurt the
        # perplexity; the logit-space gate works at a gain of ~5.
        # "prob" space:  u = 1 - p_max  (the original formulation).
        # The "never fires" threshold depends on the gate's units: in
        # probability space u <= 1, in logit space u is unbounded (nats).
        if tau is None:
            tau = 2.0 if str(gate_space) != "logit" else 20.0
        e = np.exp(z - z.max(axis=1, keepdims=True))
        p = e / e.sum(axis=1, keepdims=True)
        if str(gate_space) == "logit":
            u = -np.log(np.clip(p.max(axis=1), 1e-12, None))
        else:
            u = 1.0 - p.max(axis=1)
        boost = gain * u
        # the router tier's answer is a CLUSTER-LEVEL guess: a smaller boost,
        # and scaled by how much the cluster actually agrees with itself.
        # Without the confidence scaling the fallback overrules the base
        # model on contexts where the cluster's answer is a coin flip
        # (measured: the fact-task recall fell from 1.000 to 0.625).
        if rconf is not None:
            rc = np.asarray(rconf, dtype=float)
            boost = np.where(fallback,
                             boost * float(router_weight) * np.clip(rc, 0.0, 1.0),
                             boost)
        if use_support:
            sup = info.get("support")
            if sup is not None:
                conf = np.minimum(1.0, np.asarray(sup, dtype=float) / support_scale)
                boost = boost * conf
        # RULE 2: the retrieval's own confidence
        conf = info.get("confidence")
        if conf is None:
            conf = np.zeros(T)
        else:
            conf = np.asarray(conf, dtype=float)
        if rconf is not None:
            conf = np.where(fallback, np.asarray(rconf, dtype=float), conf)
        decide = (u >= tau) | (conf >= c_min)
        boost = np.where(decide, big, boost)
        out = z.copy()
        rows = np.nonzero(retrieved >= 0)[0]
        if len(rows):
            out[rows, retrieved[rows]] += boost[rows]
        return _T(out) if is_tensor else out

    # ------------------------------------------------- the layer-local head
    def layer_logits(self, info):
        """The layer's OWN next-token prediction, from its own state.

        This is the objective that replaces the base model's loss.  It is
        well-posed (the target is the token that actually followed), it never
        touches the base model's parameters, and therefore it CANNOT diverge
        the way the base-model-loss training did.
        """
        sr = info.get("state_read")
        if sr is None or self.Wp is None:
            return None
        return sr @ self.Wp + self.bias

    # ------------------------------------------------------------- the store
    def _key(self, buf):
        if len(buf) < self.ctx_len:
            return None
        if self.ctx_len == 1:
            return int(buf[-1])
        return ctx_hash(buf[-self.ctx_len:])

    def _put(self, key: int, value: int):
        """Record an occurrence: (context -> the token that followed it).

        The store keeps the MAJORITY continuation, not the first one.  The
        first-write-wins policy was exact but blind: a context that occurs
        everywhere kept only its first continuation, so the statistically
        correct answer was lost (measured: 0/3).  An online mode tracker
        keeps the statistically correct answer AND counts the
        corroboration, which gives a CONFIDENCE for free.
        """
        self.store.put(key, value)

    def confidence(self, key: int) -> float:
        """How often the stored value has been corroborated (1.0 = never
        contradicted).  0.0 for an unknown context."""
        return self.store.confidence(key)


def GRAFT_STATE_BYTES(M: int, r: int) -> int:
    """Bytes of persistent state for M anchors of rank r (exact tier + fluid)."""
    return M * r * 8 + 20 * 819

#--- FILE: superfluid/gpt2_tokenizer.py ---
"""
superfluid.gpt2_tokenizer — the GPT-2 byte-level BPE, in pure Python.

WHY THIS FILE EXISTS
--------------------
The project's claim is that a memory layer can be attached to **any**
pretrained LLM.  To test that on a real checkpoint without dragging in
`transformers` (and its `regex` dependency), this file implements the
GPT-2 tokenizer directly: the byte-to-unicode map, the BPE merges, and
the pre-tokenizer regex.  It reads `vocab.json` + `merges.txt` from a
checkpoint directory.

It is exact: `decode(encode(text)) == text` for any text, including text
the checkpoint never saw (the byte fallback is always available).
"""

from __future__ import annotations

import json
import os
import re

__all__ = ["GPT2Tokenizer", "bytes_to_unicode"]


def bytes_to_unicode() -> dict:
    """GPT-2's reversible byte -> unicode map."""
    bs = (list(range(ord("!"), ord("~") + 1))
          + list(range(ord("\xa1"), ord("\xac") + 1))
          + list(range(ord("\xae"), ord("\xff") + 1)))
    cs = bs[:]
    n = 0
    for b in range(2 ** 8):
        if b not in bs:
            bs.append(b)
            cs.append(2 ** 8 + n)
            n += 1
    return dict(zip(bs, [chr(c) for c in cs]))


def _get_pairs(word):
    return {(word[i], word[i + 1]) for i in range(len(word) - 1)}


# GPT-2's pre-tokenizer pattern (the stdlib `re` handles it fine)
_PRE = re.compile(
    r"""'s|'t|'re|'ve|'m|'ll|'d| ?\w+| ?\w+|\S+|\s+""")


class GPT2Tokenizer:
    """The GPT-2 BPE tokenizer, loadable from a checkpoint directory."""

    def __init__(self, vocab: dict, merges: list):
        self.encoder = vocab
        self.decoder = {v: k for k, v in vocab.items()}
        self.byte_encoder = bytes_to_unicode()
        self.byte_decoder = {v: k for k, v in self.byte_encoder.items()}
        self.bpe_ranks = {tuple(m): i for i, m in enumerate(merges)}
        self.cache: dict = {}

    @classmethod
    def from_pretrained(cls, path: str) -> GPT2Tokenizer:
        with open(os.path.join(path, "vocab.json"), encoding="utf-8") as f:
            vocab = json.load(f)
        merges = []
        p = os.path.join(path, "merges.txt")
        if os.path.exists(p):
            with open(p, encoding="utf-8") as f:
                lines = f.read().split("\n")
            merges = [tuple(l.split()) for l in lines[1:] if l.strip()]
        return cls(vocab, merges)

    # ------------------------------------------------------------------ BPE
    def bpe(self, token: str) -> str:
        if token in self.cache:
            return self.cache[token]
        word = tuple(token)
        pairs = _get_pairs(word)
        if not pairs:
            return token
        while True:
            bigram = min(pairs, key=lambda p: self.bpe_ranks.get(p, 1e10))
            if bigram not in self.bpe_ranks:
                break
            first, second = bigram
            new_word = []
            i = 0
            while i < len(word):
                try:
                    j = word.index(first, i)
                except ValueError:
                    new_word.extend(word[i:])
                    break
                new_word.extend(word[i:j])
                i = j
                if word[i] == first and i < len(word) - 1 and word[i + 1] == second:
                    new_word.append(first + second)
                    i += 2
                else:
                    new_word.append(word[i])
                    i += 1
            word = tuple(new_word)
            if len(word) == 1:
                break
            pairs = _get_pairs(word)
        out = " ".join(word)
        self.cache[token] = out
        return out

    # --------------------------------------------------------------- public
    def encode(self, text: str):
        ids = []
        for tok in _PRE.findall(text):
            tok = "".join(self.byte_encoder[b] for b in tok.encode("utf-8"))
            ids.extend(self.encoder[t] for t in self.bpe(tok).split(" "))
        return ids

    def decode(self, ids) -> str:
        text = "".join(self.decoder[int(i)] for i in ids)
        raw = bytearray()
        for c in text:
            raw.append(self.byte_decoder[c])
        return raw.decode("utf-8", errors="replace")

    @property
    def vocab_size(self) -> int:
        return len(self.encoder)

#--- FILE: superfluid/bpe.py ---
"""
superfluid/bpe.py — a byte-level BPE tokenizer, in pure Python (no downloads).

WHY THIS EXISTS
---------------
Every experiment so far ran at the CHARACTER level (vocab 76).  That is
convenient but it is not what a real deployment looks like: real LLM
tokenizers are subword, with a vocabulary of 32k-256k and a very different
redundancy structure.  The character-level corpus is *maximally* redundant
(a 12-gram of characters repeats constantly), which flatters a
content-keyed store.  A subword corpus repeats less.

The point of this file is therefore not "a tokenizer" -- it is the ability
to re-run every measurement at a realistic token granularity, on CPU,
without downloading anything.

THE ALGORITHM
-------------
1. split the text on a word-ish regex,
2. count word frequencies,
3. represent every word as its UTF-8 BYTES (so the tokenizer is lossless
   for any input, including text the training corpus never saw),
4. repeatedly merge the most frequent adjacent symbol pair,
5. emit a vocabulary: the 256 byte tokens + every learned merge.

`encode` is then exact and reversible (`decode(encode(s)) == s` for any
string, because the byte fallback is always available).
"""

from __future__ import annotations

import json
import os
import re
from collections import Counter

__all__ = ["BPETokenizer", "train_bpe"]

_WORD = re.compile(r"\S+|\s+")


class BPETokenizer:
    """A byte-level BPE tokenizer."""

    def __init__(self, merges: dict, id_bytes: dict):
        # merges: {(a, b): new_id}  -- the merge ORDER matters
        # id_bytes: {id: bytes}   -- every id, bytes and merged alike
        self.merges = merges
        self.ranks = {p: i for i, p in enumerate(merges.keys())}
        self.id_to_bytes = dict(id_bytes)

    # ------------------------------------------------------------------ size
    @property
    def vocab_size(self) -> int:
        return len(self.id_to_bytes)

    # --------------------------------------------------------------- encode
    def _word_symbols(self, word: str):
        b = word.encode("utf-8")
        return tuple(b)

    def _merge_word(self, symbols):
        while len(symbols) > 1:
            best = None
            best_i = -1
            for i in range(len(symbols) - 1):
                r = self.ranks.get((symbols[i], symbols[i + 1]))
                if r is not None and (best is None or r < best):
                    best = r
                    best_i = i
            if best is None:
                break
            a, b = symbols[best_i], symbols[best_i + 1]
            new = self.merges.get((a, b))
            if new is None:
                break
            symbols = symbols[:best_i] + (new,) + symbols[best_i + 2:]
        return symbols

    def encode(self, text: str):
        ids = []
        for w in _WORD.findall(text):
            ids.extend(self._merge_word(self._word_symbols(w)))
        return ids

    def decode(self, ids) -> str:
        out = bytearray()
        for i in ids:
            out += self.id_to_bytes[int(i)]
        return out.decode("utf-8", errors="replace")

    # ------------------------------------------------------------------ io
    def save(self, path: str):
        with open(path, "w", encoding="utf-8") as f:
            json.dump({
                "merges": [[list(k), v] for k, v in self.merges.items()],
                "id_bytes": {str(k): list(v) for k, v in self.id_to_bytes.items()},
            }, f)

    @staticmethod
    def load(path: str) -> BPETokenizer:
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        merges = {tuple(m[0]): m[1] for m in d["merges"]}
        id_bytes = {int(k): bytes(v) for k, v in d["id_bytes"].items()}
        return BPETokenizer(merges, id_bytes)


def train_bpe(text: str, vocab_size: int = 1024, verbose: bool = True):
    """Train a byte-level BPE on `text`.  Deterministic, no randomness."""
    words = Counter(_WORD.findall(text))
    # each word -> its symbol tuple; count pairs over the whole corpus
    word_syms = {w: tuple(w.encode("utf-8")) for w in words}
    merges: dict = {}
    id_bytes: dict = {i: bytes([i]) for i in range(256)}

    def recount():
        pairs = Counter()
        for w, s in word_syms.items():
            c = words[w]
            for i in range(len(s) - 1):
                pairs[(s[i], s[i + 1])] += c
        return pairs

    n_merges = vocab_size - 256
    for step in range(n_merges):
        pairs = recount()
        if not pairs:
            break
        # deterministic tie-break: the highest count, then the lowest ids
        best = max(pairs.items(), key=lambda kv: (kv[1], -kv[0][0], -kv[0][1]))
        pair, cnt = best
        if cnt < 2:
            break
        new_id = 256 + len(merges)
        merges[pair] = new_id
        id_bytes[new_id] = id_bytes[pair[0]] + id_bytes[pair[1]]
        # rewrite every word
        for w in list(word_syms):
            s = word_syms[w]
            out = []
            i = 0
            while i < len(s):
                if i + 1 < len(s) and (s[i], s[i + 1]) == pair:
                    out.append(new_id)
                    i += 2
                else:
                    out.append(s[i])
                    i += 1
            word_syms[w] = tuple(out)
        if verbose and step % 100 == 0:
            print(f"    merge {step}: {pair} -> {new_id}  (count {cnt})")
    return BPETokenizer(merges, id_bytes)


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--corpus", default="corpus.txt")
    ap.add_argument("--vocab", type=int, default=1024)
    ap.add_argument("--out", default="prior/bpe_1024.json")
    args = ap.parse_args()
    with open(args.corpus, encoding="utf-8", errors="ignore") as f:
        text = f.read()
    tok = train_bpe(text, args.vocab)
    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    tok.save(args.out)
    ids = tok.encode("Alice was beginning to get very tired of sitting by "
                      "her sister on the bank, and of having nothing to do.")
    print(f"    vocab {tok.vocab_size}  tokens {len(ids)}  "
          f"-> {ids[:12]} ...")
    print(f"    round-trip ok: {tok.decode(ids)[:60]!r}")
    print(f"    wrote {args.out}")

#--- FILE: selftest.py ---
#!/usr/bin/env python3
"""
selftest.py — numerical verification of every claim the Superfluid proposal makes.

Each check either PASSES (numerically confirmed) or FAILS.  Results are written
to results/selftest.json so the report quotes measured numbers, not claims.

  1  P1  jamming bound            ||e^{-tL}u|| <= e^{-lam2 t} ||u||
  2  P1  predicted jam time        t_jam = log(1/eps)/lam2  matches empirical
  3  P2  Chebyshev degree          m = O(sqrt(kappa) log(1/eps)) suffices
  4  P3  linear collapse           pure-linear model cannot fit XOR
  5  P3  the fix                   one pointwise nonlinearity can fit XOR
  6  W2  rank-c trap               frozen state has rank = #components
  7  W2  band bank recovers info   band readout restores the transient
  8  G-balance phase transition    balanced -> non-trivial frozen state
  9  contraction certificate       ||e^{-tL}|| on ker^perp = e^{-t lam2}
 10  frame property                sum of bands == I - exp(-t_B L)
 11  autodiff gradient check       finite-difference vs analytic gradient
 12  autodiff ops                  every op gradient-checked
 13  persistence descriptor        triangle -> beta0=1, beta1=1, 2 finite bars
 14  block Laplacian               == numpy reference, and the fluid is not inert
 15  filter-bank stability         no exp(+alpha) blow-up
 16  M1  register invariance       a promoted value NEVER changes
 17  M1  integer exactness         the recalled value == the promoted value
 18  M1  fail-loud                 a signature mismatch returns None, not a
                                    wrong value
 19  M1  append-only semantics     promoting twice appends, latest wins
 20  M1  serialisation round-trip  the register survives to_bytes/from_bytes
 21  M2  logit override            argmax(next token) IS the recalled token
 22  M2  budget law                the split respects the budget and reduces
                                    M rather than over-committing
 23  M3  constant-size state       the state size does not depend on how much
                                    was written
 24  M3  frustration index         frustration == 0  <=>  a global section
                                    exists  (the right balance diagnostic for
                                    scalar signed sheaves)
 25  M3  Hodge edge participation  = 1 on the diagonal, <= 1 elsewhere
"""

import json
import os
import sys

import numpy as _np
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from superfluid import (
    SLOT_BYTES,
    FrozenRegister,
    SheafMemoryAdapter,
    SuperfluidLM,
    band_times,
    betti_numbers,
    budget_split,
    build_laplacian,
    cheb_basis,
    cheb_coeffs_exp,
    cheb_degree,
    ctx_key,
    embedding_signature,
    exact_exp_action,
    hodge_edge_participation,
    hodge_embedding,
    jam_time,
    kruskal_barcode,
    logit_override,
    power_iteration_lmax,
    spectral_summary,
)
from superfluid.autodiff import Tensor

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")
os.makedirs(OUT, exist_ok=True)
RESULTS = []


def check(name, ok, detail=""):
    RESULTS.append({"name": name, "pass": bool(ok), "detail": detail})
    print(
        f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"  — {detail}" if detail else "")
    )
    return ok


def rand_signed_laplacian(n=48, m=120, seed=0, balanced=False):
    rng = np.random.default_rng(seed)
    edges = np.unique(np.sort(rng.integers(0, n, size=(m * 2, 2)), axis=1), axis=0)
    edges = edges[edges[:, 0] != edges[:, 1]]
    alpha = rng.normal(0, 1.0, edges.shape[0])
    if balanced:
        # enforce balance: sum of incident signed weights = 0 at every node
        # achieved by construction on a union of balanced cycles
        alpha = np.ones(edges.shape[0])
    return edges, alpha, build_laplacian(n, edges, alpha)


# ---------------------------------------------------------------- 1 & 2
def test_jamming():
    print("\n[1-2] Jamming bound and jam-time prediction")
    edges, alpha, L = rand_signed_laplacian(n=48, m=110, seed=1)
    s = spectral_summary(L)
    lam2 = s["lam2"]
    rng = np.random.default_rng(3)
    # random vector orthogonal to the kernel
    w, V = np.linalg.eigh(L)
    ker = np.abs(w) < 1e-9
    u0 = rng.standard_normal((48, 1))
    u0 -= V[:, ker] @ (V[:, ker].T @ u0)
    u0 /= np.linalg.norm(u0)
    eps = 1e-6
    t_pred = jam_time(lam2, eps)
    # empirical: smallest t where the transient norm drops below eps
    t = 0.0
    t_emp = None
    while t < 200:
        u = exact_exp_action(L, t, u0)
        r = u - V[:, ker] @ (V[:, ker].T @ u)
        if np.linalg.norm(r) < eps:
            t_emp = t
            break
        t += 0.5
    # bound at several times
    ratios = []
    for tt in [0.5, 1.0, 2.0, 4.0]:
        u = exact_exp_action(L, tt, u0)
        r = u - V[:, ker] @ (V[:, ker].T @ u)
        ratios.append(
            float(np.linalg.norm(r) / (np.exp(-lam2 * tt) * np.linalg.norm(u0)))
        )
    ok_bound = all(r <= 1.0 + 1e-9 for r in ratios)
    check(
        "P1  ||e^{-tL}u|| <= e^{-lam2 t}||u||",
        ok_bound,
        f"lam2={lam2:.5f}  ratios={[round(r, 6) for r in ratios]}",
    )
    # the formula is an UPPER BOUND on the freezing time, so t_emp <= t_pred
    check(
        "P1  jam time bound log(1/eps)/lam2 is an upper bound on freezing time",
        t_emp is not None and t_emp <= t_pred * 1.02,
        f"upper bound={t_pred:.2f}  empirical={t_emp}  (empirical <= bound ✓)",
    )


# ------------------------------------------------------------------- 3
def test_chebyshev():
    print("\n[3] Chebyshev degree for exp(-tL)")
    edges, alpha, L = rand_signed_laplacian(n=40, m=90, seed=2)
    lam_max = power_iteration_lmax(L)
    w = np.linalg.eigvalsh(L)
    nz = w[w > 1e-9]
    lam2 = nz[0]
    kappa = lam_max / lam2
    X = np.random.default_rng(5).standard_normal((40, 3))
    rows = []
    for m in [4, 8, 12, 16, 24, 32]:
        a = cheb_coeffs_exp(1.0, lam_max, m)
        Y = cheb_basis(L, lam_max, X, m)
        approx = sum(a[k] * Y[k] for k in range(m + 1))
        exact = exact_exp_action(L, 1.0, X)
        err = float(np.linalg.norm(approx - exact) / (np.linalg.norm(exact) + 1e-12))
        rows.append((m, err))
    m_pred = cheb_degree(kappa, 1e-6)
    # find the smallest m whose error is below 1e-6
    m_needed = next((m for m, e in rows if e < 1e-6), None)
    ok = m_needed is not None and m_needed <= max(m_pred, 8) * 1.5
    check(
        "P2  Chebyshev degree m = O(sqrt(kappa) log(1/eps))",
        ok,
        f"kappa={kappa:.1f} predicted m={m_needed} bound m<={m_pred} "
        f"errors={[(m, f'{e:.2e}') for m, e in rows]}",
    )
    return rows


# ------------------------------------------------------------------- 4 & 5
def _fit_xor(nonlinear: bool, steps=4000, seed=0):
    rng = np.random.default_rng(seed)
    X = np.array([[0.0, 0.0], [0.0, 1.0], [1.0, 0.0], [1.0, 1.0]])
    y = np.array([[0.0], [1.0], [1.0], [0.0]])
    H = 8
    W1 = rng.normal(0, 1, (2, H))
    b1 = np.zeros((1, H))
    W2 = rng.normal(0, 1, (H, 1))
    b2 = np.zeros((1, 1))
    lr = 0.08
    for _ in range(steps):
        Z = X @ W1 + b1
        A = np.tanh(Z) if nonlinear else Z
        O = A @ W2 + b2
        dO = 2 * (O - y) / len(X)
        gW2 = A.T @ dO
        gb2 = dO.sum(0, keepdims=True)
        dA = dO @ W2.T
        if nonlinear:
            dZ = dA * (1 - np.tanh(Z) ** 2)
        else:
            dZ = dA
        gW1 = X.T @ dZ
        gb1 = dZ.sum(0, keepdims=True)
        W1 -= lr * gW1
        b1 -= lr * gb1
        W2 -= lr * gW2
        b2 -= lr * gb2
    Z = X @ W1 + b1
    A = np.tanh(Z) if nonlinear else Z
    O = A @ W2 + b2
    acc = float(((O > 0.5).astype(float) == y).mean())
    return acc, float(np.abs(O - y).mean())


def test_linear_collapse():
    print("\n[4-5] Linear collapse (P3) and the nonlinearity fix")
    acc_lin, mse_lin = _fit_xor(nonlinear=False)
    acc_nl, mse_nl = _fit_xor(nonlinear=True)
    check(
        "P3  pure-linear model CANNOT fit XOR",
        acc_lin <= 0.6,
        f"accuracy={acc_lin:.2f} mse={mse_lin:.3f}  (a hyperplane cannot separate XOR)",
    )
    check(
        "P3  + one pointwise nonlinearity CAN fit XOR",
        acc_nl >= 0.99,
        f"accuracy={acc_nl:.2f} mse={mse_nl:.4f}",
    )


# ------------------------------------------------------------------- 6 & 7
def test_rank_c_trap():
    print("\n[6-7] The rank-c trap and the band-bank fix")
    rng = np.random.default_rng(11)
    n, c = 60, 6
    # c disconnected components of 10 nodes each, random signal
    perm = rng.permutation(n)
    L = np.zeros((n, n))
    for comp in range(c):
        idx = perm[comp * 10 : (comp + 1) * 10]
        for a in range(len(idx)):
            for b in range(a + 1, len(idx)):
                L[idx[a], idx[b]] = L[idx[b], idx[a]] = -1.0
    np.fill_diagonal(L, L.sum(axis=1) * -1)
    u = rng.standard_normal((n, 1))
    # frozen state = projection onto kernel (per-component means)
    w, V = np.linalg.eigh(L)
    ker = np.abs(w) < 1e-8
    frozen = V[:, ker] @ (V[:, ker].T @ u)
    err_frozen = float(np.linalg.norm(u - frozen) / np.linalg.norm(u))
    rank_frozen = int(ker.sum())
    # band bank recovers the transient
    lam_max = power_iteration_lmax(L)
    ts = band_times(lam_max, 16, 8)
    ts = np.concatenate([[0.0], ts[1:]])
    bands = []
    Y = cheb_basis(L, lam_max, u, 16)
    for j in range(len(ts) - 1):
        a = cheb_coeffs_exp(ts[j], lam_max, 16)
        b = cheb_coeffs_exp(ts[j + 1], lam_max, 16)
        bands.append(sum((a[k] - b[k]) * Y[k] for k in range(17)))
    recon = sum(bands) + frozen  # frozen + all bands
    err_bands = float(np.linalg.norm(u - recon) / np.linalg.norm(u))
    check(
        "W2  frozen state has rank = #components",
        rank_frozen == c,
        f"rank={rank_frozen} (expected {c}), reconstruction error={err_frozen:.3f}",
    )
    check(
        "W2  band bank restores the lost information",
        err_bands < 1e-3,
        f"error with bands={err_bands:.2e} vs frozen-only={err_frozen:.3f}",
    )
    return {
        "rank_frozen": rank_frozen,
        "err_frozen": err_frozen,
        "err_bands": err_bands,
    }


# ------------------------------------------------------------------- 8
def test_g_balance():
    print("\n[8] G-balance phase transition (freeze vs evaporate)")
    # balanced 4-cycle with signs +,+,-,-  -> every node's incident sum = 0
    edges = np.array([[0, 1], [1, 2], [2, 3], [3, 0]])
    alpha = np.array([1.0, 1.0, -1.0, -1.0])
    L = build_laplacian(4, edges, alpha)
    w, V = np.linalg.eigh(L)
    ker = np.abs(w) < 1e-9
    kv = V[:, ker]
    non_const = False
    if kv.shape[1] > 0:
        nz = np.abs(kv) > 1e-6
        non_const = bool(nz.any(axis=0).sum() > 0)
    check(
        "G-balance  balanced signed cycle has a NON-CONSTANT frozen state",
        non_const and ker.sum() >= 1,
        f"kernel dim={int(ker.sum())}, kernel vectors are non-constant sign patterns",
    )
    # unbalanced triangle +,+,- : balance residual non-zero
    edges2 = np.array([[0, 1], [1, 2], [2, 0]])
    alpha2 = np.array([1.0, 1.0, -1.0])
    L2 = build_laplacian(3, edges2, alpha2)
    res2 = float(np.max(np.abs(L2.sum(axis=1))))
    w2, V2 = np.linalg.eigh(L2)
    ker2 = np.abs(w2) < 1e-9
    const_only = True
    if ker2.sum() > 0:
        kv2 = V2[:, ker2]
        const_only = bool(np.all(np.abs(kv2[0] - kv2[1]) < 1e-6))
    check(
        "G-balance  unbalanced cycle has NO sign-pattern frozen state",
        res2 > 1e-6 and const_only,
        f"balance residual={res2:.3f} (non-zero => field cannot freeze "
        "onto a topology)",
    )


# ------------------------------------------------------------------- 9
def test_contraction():
    print("\n[9] Contraction certificate")
    edges, alpha, L = rand_signed_laplacian(n=36, m=80, seed=7)
    s = spectral_summary(L)
    lam2 = s["lam2"]
    for t in [1.0, 2.0]:
        E = exact_exp_action(L, t, np.eye(36))
        w, V = np.linalg.eigh(L)
        ker = np.abs(w) < 1e-9
        Pk = V[:, ker] @ V[:, ker].T
        Pr = np.eye(36) - Pk
        Eperp = E @ Pr
        op = float(np.linalg.norm(Eperp, 2))
        bound = np.exp(-lam2 * t)
        check(
            f"contraction  ||e^{{-tL}}|| on ker^perp <= e^{{-t lam2}} (t={t})",
            op <= bound + 1e-9,
            f"observed={op:.6f} bound={bound:.6f} lam2={lam2:.4f}",
        )


# ------------------------------------------------------------------- 10
def test_frame_property():
    print("\n[10] Frame property of the band bank")
    edges, alpha, L = rand_signed_laplacian(n=32, m=70, seed=9)
    lam_max = power_iteration_lmax(L)
    X = np.random.default_rng(13).standard_normal((32, 4))
    m = 20
    ts = band_times(lam_max, m, 8)
    ts = np.concatenate([[0.0], ts[1:]])
    Y = cheb_basis(L, lam_max, X, m)
    total = np.zeros_like(X)
    for j in range(len(ts) - 1):
        a = cheb_coeffs_exp(ts[j], lam_max, m)
        b = cheb_coeffs_exp(ts[j + 1], lam_max, m)
        total += sum((a[k] - b[k]) * Y[k] for k in range(m + 1))
    exact = exact_exp_action(L, ts[0], X) - exact_exp_action(L, ts[-1], X)
    err = float(np.linalg.norm(total - exact) / (np.linalg.norm(exact) + 1e-12))
    check(
        "frame  sum of bands == e^{-t0 L} - e^{-tB L}",
        err < 1e-3,
        f"relative error={err:.2e} (t0={ts[0]:.0e}, tB={ts[-1]:.0e})",
    )


# ------------------------------------------------------------------- 11
def _fd_grad(f, x, eps=1e-6):
    g = np.zeros_like(x)
    it = np.nditer(x, flags=["multi_index"])
    while not it.finished:
        i = it.multi_index
        old = x[i]
        x[i] = old + eps
        p = f()
        x[i] = old - eps
        m = f()
        x[i] = old
        g[i] = (p - m) / (2 * eps)
        it.iternext()
    return g


def test_autodiff():
    print("\n[11-12] Autodiff gradient checks")
    rng = np.random.default_rng(21)
    # op-level check on a composite expression
    A = Tensor(rng.standard_normal((4, 5)))
    B = Tensor(rng.standard_normal((5, 3)))
    c = Tensor(rng.standard_normal((4, 3)))

    def loss_t():
        Z = (A @ B + c).gelu()
        return (Z * Z).mean()

    def loss_fn():
        return float(loss_t().data)

    loss_t().backward()
    gA, gB = A.grad.copy(), B.grad.copy()
    A.grad = np.zeros_like(A.data)
    B.grad = np.zeros_like(B.data)
    fdA = _fd_grad(loss_fn, A.data)
    fdB = _fd_grad(loss_fn, B.data)
    eA = float(np.max(np.abs(gA - fdA)))
    eB = float(np.max(np.abs(gB - fdB)))
    check(
        "autodiff  gradient of (A@B+c).gelu() matches finite differences",
        eA < 1e-6 and eB < 1e-6,
        f"max|err| A={eA:.2e} B={eB:.2e}",
    )

    # end-to-end check on the real model
    m = SuperfluidLM(
        vocab=11, d=8, n_layers=1, n_ctx=12, k_neighbors=3, bands=3, cheb_m=4, seed=4
    )
    params = m.params()
    idx = np.array([1, 2, 3, 4, 5, 6], dtype=np.int64)
    tgt = np.array([2, 3, 4, 5, 6, 7], dtype=np.int64)

    from superfluid.losses import cross_entropy_tensor

    def model_loss_t():
        return cross_entropy_tensor(m.forward(idx), tgt)

    def model_loss():
        return float(model_loss_t().data)

    val = model_loss()
    loss_t = model_loss_t()
    loss_t.backward()
    # (a) exact path: channel-mixing weight (does not touch the routing or the
    #     spectral scale), so the analytic and finite-difference gradients must
    #     agree to machine precision.
    key = "b0.Wmix"
    g_analytic = params[key].grad.copy()
    params[key].grad = np.zeros_like(params[key].data)
    fd = _fd_grad(model_loss, params[key].data, eps=1e-6)
    e = float(np.max(np.abs(g_analytic - fd)) / (np.max(np.abs(fd)) + 1e-12))
    check(
        "autodiff  SuperfluidLM end-to-end gradient matches finite differences",
        e < 1e-3,
        f"relative max error on {key} = {e:.2e}  (loss={val:.4f})",
    )

    # (b) the restriction-map path goes through |alpha| in the degree term,
    #     which has a kink at alpha = 0 -- so the finite difference is only
    #     accurate to first order.  We require agreement in DIRECTION.
    key2 = "b0.edge2"
    g2 = params[key2].grad.copy()
    params[key2].grad = np.zeros_like(params[key2].data)
    fd2 = _fd_grad(model_loss, params[key2].data, eps=1e-6)
    a = g2.reshape(-1)
    b = fd2.reshape(-1)
    corr = float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-16))
    rel2 = float(np.max(np.abs(a - b)) / (np.max(np.abs(b)) + 1e-12))
    check(
        "autodiff  restriction-map gradient points the same way as finite differences",
        corr > 0.8,
        f"correlation = {corr:.4f}  (magnitude rel.err {rel2:.2e}; "
        f"the |alpha| degree term is piecewise-linear)",
    )


# ------------------------------------------------------------------- 13
def test_persistence():
    print("\n[13] Persistence descriptor correctness")
    # a triangle: 1 component, 1 cycle
    edges = np.array([[0, 1], [1, 2], [2, 0]])
    b = betti_numbers(3, edges)
    pairs, b0 = kruskal_barcode(3, edges, np.array([1.0, 1.0, 2.0]))
    finite = [(a, d) for a, d in pairs if np.isfinite(d)]
    ok = b["beta0"] == 1 and b["beta1"] == 1 and b0 == 1 and len(finite) == 2
    check(
        "persistence  triangle -> beta0=1, beta1=1, 2 finite bars",
        ok,
        f"beta0={b['beta0']} beta1={b['beta1']} bars={finite}",
    )


# ------------------------------------------------------------------- 14
def test_block_laplacian():
    """The Laplacian the BLOCK builds must equal the numpy reference, and the
    fluid must actually move the field (guards against a silently inert fluid)."""
    print("\n[14] Block Laplacian == numpy reference, and the fluid is not a no-op")
    import numpy as _np

    from superfluid.autodiff import Tensor as _T
    from superfluid.blocks import SuperfluidBlock
    from superfluid.sheaf import build_laplacian as np_build_laplacian

    rng = _np.random.default_rng(5)
    n, d = 16, 8
    edges = _np.array([[0, 1], [1, 2], [2, 3], [3, 4], [4, 5], [5, 0], [2, 5], [7, 9]])
    alpha = rng.normal(0, 0.7, edges.shape[0])
    Lref = np_build_laplacian(n, edges, alpha)
    blk = SuperfluidBlock(d, k_neighbors=3, bands=3, cheb_m=6, seed=1)
    Lblk = blk._laplacian(n, edges, _T(alpha))
    err = float(_np.abs(Lblk.data - Lref).max())
    check(
        "block Laplacian matches the numpy reference",
        err < 1e-10,
        f"max abs diff = {err:.2e}",
    )

    # the fluid must change the field
    x = _T(rng.normal(0, 1, (n, d)))
    bands = blk._bands(Lblk, float(_np.abs(Lblk.data).max()), x)
    moved = sum(float(_np.abs(b.data - x.data).max()) for b in bands)
    check(
        "the fluid actually moves the field (bands are not identity)",
        moved > 1e-8,
        f"total band displacement = {moved:.3e}",
    )

    # the harmonic branch must be the per-component mean
    from superfluid.topology import connected_components as _cc

    lab, nc = _cc(n, edges)
    means = _np.zeros((nc, d))
    for i in range(n):
        means[lab[i]] += x.data[i]
    counts = _np.bincount(lab, minlength=nc)[:, None]
    means = means / counts
    expect = means[lab]
    got = blk._harmonic(x, edges).data
    herr = float(_np.abs(got - expect).max())
    check(
        "harmonic branch == per-component mean (the Hodge projection)",
        herr < 1e-10,
        f"max abs diff = {herr:.2e}, components = {nc}",
    )


# ------------------------------------------------------------------- 15
def test_band_stability():
    """The filter bank must be numerically STABLE: band energies may not blow up.

    Regression test: an earlier version used exp(+alpha) instead of exp(-alpha)
    in the Chebyshev coefficients, which multiplied the bands by e^(2 alpha)
    (~1e6) and made the whole model diverge.
    """
    print("\n[15] Filter-bank stability (regression: exp(-alpha) sign error)")
    from superfluid.autodiff import Tensor as _T
    from superfluid.blocks import SuperfluidBlock

    rng = _np.random.default_rng(4)
    n, d = 20, 8
    edges = _np.array(
        [[i, (i + 1) % n] for i in range(n)] + [[i, (i + 7) % n] for i in range(n // 2)]
    )
    blk = SuperfluidBlock(d, k_neighbors=4, bands=5, cheb_m=10, seed=2)
    x = _T(rng.normal(0, 1, (n, d)))
    L = blk._laplacian(n, edges, _T(rng.normal(0, 0.5, edges.shape[0])))
    bands = blk._bands(L, float(_np.abs(L.data).max()), x)
    e = _np.array([float((b.data**2).sum()) for b in bands])
    scale = float((x.data**2).sum())
    ok = bool(e.max() < 1e6 * max(scale, 1e-12))
    check(
        "filter bank is numerically stable (no exponential blow-up)",
        ok,
        f"band energies = {[_np.format_float_scientific(v, 2) for v in e]}",
    )
    # and the band sum must be bounded by the identity-scale operator
    tot = float(_np.linalg.norm(sum(b.data for b in bands)))
    check(
        "band sum stays on the scale of the input",
        tot < 1e4 * max(scale, 1e-12),
        f"||sum of bands|| = {tot:.3e}  vs ||x||^2 = {scale:.3e}",
    )


# ============================================================ 16-20  MEMORY
def test_register():
    """The FROZEN REGISTER: invariance, integer exactness, fail-loud, append-only."""
    print("\n[16-20] The frozen register")
    reg = FrozenRegister(capacity=64)
    key = ctx_key([1, 2, 3], doc_id=0)
    sig = embedding_signature(np.array([1.0, 0.0, 0.0, 0.0]))
    s0 = reg.promote(4242, key, sig=sig, anchor=3, doc_id=0)
    val0 = int(reg.val[s0])

    # (16) INVARIANCE: writing more slots must not touch an existing one.
    for k in range(20):
        reg.promote(1000 + k, ctx_key([k]), sig=0, anchor=k, doc_id=1)
    check(
        "M1  a promoted value NEVER changes (append-only invariance)",
        int(reg.val[s0]) == val0 and reg.key[s0] == np.uint64(key),
        f"slot {s0} still holds {int(reg.val[s0])} after 20 further writes",
    )

    # (17) INTEGER EXACTNESS: the recalled value is EQUAL, not approximate.
    got = reg.recall(key, sig=sig)
    ok = got is not None and int(got[1]) == 4242 and isinstance(int(got[1]), int)
    check(
        "M1  the recalled value is bit-exact (integer token id)",
        ok,
        f"recalled {None if got is None else int(got[1])} (expected 4242)",
    )

    # (18) FAIL LOUD: a signature mismatch must return None, NOT a wrong value.
    bad = reg.recall(key, sig=embedding_signature(np.array([0.0, 1.0, 0.0, 0.0])))
    check(
        "M1  a signature mismatch FAILS LOUD (returns None, never a wrong value)",
        bad is None,
        f"mismatched signature returned {bad}",
    )

    # (19) APPEND-ONLY: promoting the same key twice appends, latest wins.
    s1 = reg.promote(777, key, sig=sig, anchor=3, doc_id=2)
    latest = reg.recall(key, sig=sig)
    check(
        "M1  promoting the same key appends a slot; the latest wins",
        s1 != s0 and reg.n == s0 + 22 and int(latest[1]) == 777,
        f"slots {s0} and {s1} coexist; latest value = {int(latest[1])}",
    )

    # (20) SERIALISATION ROUND-TRIP.
    blob = reg.to_bytes()
    back = FrozenRegister.from_bytes(blob, 64)
    g2 = back.recall(key, sig=sig)
    check(
        "M1  the register survives a to_bytes/from_bytes round-trip",
        g2 is not None and int(g2[1]) == 777 and back.n == reg.n,
        f"{len(blob)} B, {back.n} slots, value {None if g2 is None else int(g2[1])}",
    )
    return {"slots": reg.n, "state_bytes": reg.nbytes()}


# ================================================================= 21-22
def test_override_and_budget():
    print("\n[21-22] The logit override and the budget law")
    rng = np.random.default_rng(0)
    lg = rng.standard_normal(64)
    want = 37
    out = logit_override(lg, want)
    check(
        "M2  the logit override makes argmax(next token) == the recalled token",
        int(out.argmax()) == want and int(lg.argmax()) != want,
        f"argmax {int(lg.argmax())} -> {int(out.argmax())} (forced {want})",
    )
    lg2 = rng.standard_normal((4, 32))
    o2 = logit_override(lg2, [1, 5, 9, 31])
    check(
        "M2  the batched override forces every row",
        list(o2.argmax(axis=1)) == [1, 5, 9, 31],
        f"argmax per row = {list(o2.argmax(axis=1))}",
    )

    # the override must also accept a framework Tensor (that is how the
    # model actually hands you its logits)
    from superfluid.autodiff import Tensor

    t = Tensor(lg.copy())
    o3 = logit_override(t, want)
    check(
        "M2  the logit override accepts a framework Tensor as well as an ndarray",
        int(o3.argmax()) == want,
        f"Tensor input -> argmax {int(o3.argmax())} (forced {want})",
    )

    # budget law: the split must never exceed the budget
    b = budget_split(16 * 1024, M=1024, r=8, slot_bytes=SLOT_BYTES)
    fits = (b["fluid_bytes"] + b["register_bytes"]) <= 16 * 1024
    b2 = budget_split(16 * 1024, M=100000, r=8, slot_bytes=SLOT_BYTES)
    reduced = (
        b2["M_reduced"] and (b2["fluid_bytes"] + b2["register_bytes"]) <= 16 * 1024
    )
    check(
        "M2  the budget law never over-commits (M is reduced instead)",
        fits and reduced,
        f"16KB -> M={b['M_used']} fluid={b['fluid_bytes']}B "
        f"register={b['register_bytes']}B; "
        f"asking M=100000 -> M={b2['M_used']} (reduced={b2['M_reduced']})",
    )


# ==================================================================== 23
def test_constant_state():
    """The runtime state must be CONSTANT SIZE no matter how much is written."""
    print("\n[23] The state is constant size")
    M, d, r = 32, 16, 8
    ad = SheafMemoryAdapter(M=M, r=r, d=d, capacity=64, seed=3)
    rng = np.random.default_rng(4)
    ad.set_prototypes(rng.standard_normal((M, d)))
    before = ad.state_bytes()
    for _ in range(20):
        ad.write(rng.standard_normal((256, d)), t=0.1, cheb_m=4)
    after = ad.state_bytes()
    check(
        "M3  the runtime state does NOT grow with the amount written",
        before == after == M * r * 2 + 64 * SLOT_BYTES,
        f"state {before} B before, {after} B after 5,120 tokens "
        f"(anchors {M}x{r} fp16 + register 64 x {SLOT_BYTES} B)",
    )

    # and the fluid really did absorb the writes
    moved = float(np.abs(ad.anchors).sum())
    check(
        "M3  the fluid actually absorbed the writes (not inert)",
        moved > 1e-8,
        f"sum |anchors| = {moved:.3e}",
    )


# ==================================================================== 24
def _frustration(n, edges, alpha):
    """Number of edges whose sign disagrees with the best global sign assignment."""
    if edges.shape[0] == 0:
        return 0
    parent = list(range(n))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    s = np.zeros(n, dtype=np.int64)
    seen = np.zeros(n, dtype=bool)
    for e in np.argsort(-np.abs(alpha), kind="stable"):
        u, v = int(edges[e, 0]), int(edges[e, 1])
        ru, rv = find(u), find(v)
        if ru == rv:
            continue
        if not seen[u]:
            s[u] = 1
            seen[u] = True
        if not seen[v]:
            s[v] = 1
            seen[v] = True
        s[v] = int(s[u] * (1 if alpha[e] > 0 else -1))
        parent[rv] = ru
    bad = 0
    for e in range(edges.shape[0]):
        u, v = int(edges[e, 0]), int(edges[e, 1])
        if int(s[u] * (1 if alpha[e] > 0 else -1) * s[v]) < 0:
            bad += 1
    return int(bad)


def test_frustration():
    print("\n[24] The frustration index is the right balance diagnostic")
    rng = np.random.default_rng(9)
    n = 24
    agree = 0
    trials = 40
    for _ in range(trials):
        edges = np.stack([np.arange(n), (np.arange(n) + 1) % n], axis=1)
        alpha = rng.choice([-1.0, 1.0], size=n)
        L = build_laplacian(n, edges, alpha)
        w = np.linalg.eigvalsh(L)
        has_section = bool((np.abs(w) < 1e-8).sum() >= 1)
        fr = _frustration(n, edges, alpha)
        agree += int((fr == 0) == has_section)
    check(
        "M3  frustration == 0  <=>  a non-trivial global section exists",
        agree == trials,
        f"{agree}/{trials} random signed cycles agree",
    )

    # the contrast with the framework's ||L 1|| residual: they are NOT the
    # same property, and only the frustration index tracks the kernel.
    edges = np.stack([np.arange(n), (np.arange(n) + 1) % n], axis=1)
    alpha = -np.ones(n)  # all-negative EVEN cycle
    L = build_laplacian(n, edges, alpha)
    w = np.linalg.eigvalsh(L)
    kdim = int((np.abs(w) < 1e-8).sum())
    V = np.linalg.eigh(L)[1][:, np.abs(w) < 1e-8]
    nonconst = kdim > 0 and float(np.max(np.abs(V[0] - V[-1]))) > 1e-6
    check(
        "M3  an all-NEGATIVE even cycle freezes onto a non-constant sign pattern",
        kdim >= 1 and nonconst,
        f"kernel dim={kdim}, ||L1||inf={float(np.max(np.abs(L.sum(1)))):.1f} "
        f"(so ||L1|| does NOT detect this) ",
    )


# ==================================================================== 25
def test_hodge_edge_participation():
    print("\n[25] The Hodge edge participation")
    edges = np.stack([np.arange(8), (np.arange(8) + 1) % 8], axis=1)
    alpha = np.ones(8)
    Psi = hodge_embedding(8, edges, alpha)
    d = hodge_edge_participation(Psi, np.arange(8), np.arange(8))
    o = hodge_edge_participation(Psi, np.zeros(4, dtype=np.int64), np.arange(4))
    check(
        "M3  Hodge edge participation is 1 on the diagonal and <= 1 elsewhere",
        bool(np.allclose(d, 1.0))
        and bool(np.all(o <= 1.0 + 1e-12))
        and bool(np.all(o >= 0)),
        f"diagonal in [{d.min():.4f}, {d.max():.4f}], off-diagonal max {o.max():.4f}",
    )


# ==================================================================== 26
def test_graft():
    """The attachable memory layer: attaching it must change NOTHING, and
    the exact tier must return a token the base model cannot see."""
    print("\n[26] The graft: attaching the layer is a provable no-op")
    from superfluid.graft import SAABranch
    from superfluid.model import TinyTransformer

    m = TinyTransformer(32, d=32, n_layers=2, n_ctx=32, seed=0)
    br = SAABranch(M=16, r=4, d=32, emb=m.emb, ctx_len=1, seed=0)

    tok = np.array([3, 7, 11, 5, 9, 2, 8, 13], dtype=np.int64)
    lg0 = m.forward(tok)
    h0 = m.emb[tok] + m.pos[: len(tok)]
    h1, _ = br.forward(h0, m.emb[tok], tok)
    lg1 = m.forward_from_h(h1)
    same = np.array_equal(lg0.data, lg1.data)
    check(
        "M3  attaching the layer leaves the logits BIT-IDENTICAL",
        same,
        f"max abs diff {float(np.abs(lg0.data - lg1.data).max()):.3e}",
    )

    n_state = br.state_bytes
    for _ in range(5):
        br.forward(h0, m.emb[tok], tok)
    check(
        "M3  the layer's state stays bounded while it is used",
        br.state_bytes <= n_state + 4096,
        f"state {n_state} B -> {br.state_bytes} B after 5 writes",
    )

    br2 = SAABranch(M=16, r=4, d=32, emb=m.emb, ctx_len=1, seed=0)
    br2.Wo_exact.data = np.eye(32)
    br2.read_gain = "raw"
    br2.read_scale = 300.0
    br2.read_transform = "pc1"
    br2.refresh_contrast()
    seq = np.array([4, 21, 6, 30, 12, 17, 2, 25], dtype=np.int64)
    br2.reset()
    br2.forward(m.emb[seq] + m.pos[: len(seq)], m.emb[seq], seq)
    # the store maps a CONTEXT to the token that followed it
    stored = br2.store.get(int(seq[-2]), -1)
    check(
        "M3  the exact tier stores a token id and returns it bit-exactly",
        stored == int(seq[-1]) and isinstance(stored, int),
        f"store[{seq[-2]}] = {stored} (expected {int(seq[-1])})",
    )


# ==================================================================== 27
def test_gate():
    """The gate: the base model's OWN uncertainty decides how much the
    retrieval speaks.

    This is what makes one knob serve both use cases.  A hard override
    strong enough to win the argmax (needed for recall) also forces a wrong
    retrieval into the model (which cost +1.08 nats in E9).  Scaling the
    override by the model's uncertainty fixes that without a second knob.
    """
    print("\n[27] The gate: the model's own uncertainty")
    from superfluid.graft import SAABranch
    from superfluid.model import TinyTransformer

    m = TinyTransformer(32, d=32, n_layers=2, n_ctx=32, seed=0)
    br = SAABranch(M=16, r=4, d=32, emb=m.emb, ctx_len=1, seed=0)
    br.Wo_exact.data = np.eye(32)
    br.read_gain = "raw"
    br.read_scale = 300.0
    br.read_transform = "pc1"
    br.refresh_contrast()

    # plant a fact: the pair (2 -> 25)
    seq = np.array([4, 21, 6, 30, 12, 17, 2, 25], dtype=np.int64)
    br.reset()
    br.forward(m.emb[seq] + m.pos[: len(seq)], m.emb[seq], seq)
    assert br.store.get(2) == 25, "the fact was not stored"

    # query: a window that ENDS with the key 2
    q = np.array([7, 19, 2], dtype=np.int64)
    h0 = m.emb[q] + m.pos[: len(q)]
    _, info = br.forward(h0, m.emb[q], q)
    hit = int(info["retrieved"][-1])
    check(
        "M3  the layer reports WHAT it retrieved for the query position",
        hit == 25,
        f"retrieved {hit} (expected 25)",
    )

    # a CONFIDENT base model: the gate must NOT move the argmax
    conf = np.full((3, 32), -10.0)
    conf[2, 5] = 10.0
    g1 = br.gated_logits(conf, info, gain=20.0)
    # an UNSURE base model (uniform logits): the gate must let the
    # retrieval win, because the model has nothing better to say
    uns = np.zeros((3, 32))
    g2 = br.gated_logits(uns, info, gain=20.0)
    check(
        "M3  the gate IGNORES the retrieval when the base model is confident",
        int(g1[-1].argmax()) == 5,
        f"argmax stayed {int(g1[-1].argmax())} (the base was sure of 5)",
    )
    check(
        "M3  the gate LETS THE RETRIEVAL WIN when the base model is unsure",
        int(g2[-1].argmax()) == 25,
        f"argmax moved {int(uns[-1].argmax())} -> {int(g2[-1].argmax())} "
        f"(the retrieved token)",
    )

    # no hit -> the gate must not touch the logits at all
    miss = {"retrieved": np.array([-1, -1, -1]), "support": np.zeros(3)}
    g3 = br.gated_logits(uns, miss, gain=20.0)
    check(
        "M3  the gate is a no-op when the store has no hit",
        np.array_equal(g3, uns),
        f"max abs diff {float(np.abs(g3 - uns).max()):.3e}",
    )


# ==================================================================== 28
def test_exact_memory():
    """The memory must be EXACT: the mode is kept, the confidence is
    counted, and the corroborated entries survive the eviction."""
    print("\n[28] The exact memory: the mode tracker and the eviction")
    from superfluid.graft import SAABranch
    from superfluid.model import TinyTransformer

    class _Emb:
        def __init__(self, V=32, d=32):
            self.data = np.random.default_rng(0).normal(0, 0.02, (V, d))
            self.shape = self.data.shape

    br = SAABranch(M=8, r=4, d=32, emb=_Emb(), ctx_len=1, capacity=8, seed=0)

    # the store keeps the MAJORITY continuation, not the first one
    for v in (5, 5, 7, 7, 7):
        br._put(42, v)
    check(
        "M3  the store keeps the MAJORITY continuation of a context",
        br.store[42] == 7,
        f"store[42] = {br.store[42]} (5,5,7,7,7 -> the mode is 7)",
    )

    # the confidence counts the corroboration
    conf = br.confidence(42)
    check(
        "M3  the store carries a CONFIDENCE (the corroboration ratio)",
        0.0 <= conf <= 1.0 and conf > 0.0,
        f"confidence(42) = {conf:.3f}",
    )

    # and the majority can flip
    for v in (9, 9, 9, 9):
        br._put(42, v)
    check(
        "M3  the stored value follows the majority when it flips",
        br.store[42] == 9,
        f"store[42] = {br.store[42]} (after 4 more 9s)",
    )

    # the EVICTION keeps the corroborated entries, not merely the newest
    br2 = SAABranch(M=8, r=4, d=32, emb=_Emb(), ctx_len=1, capacity=4, seed=0)
    for _ in range(20):
        br2._put(1, 77)  # heavily corroborated
    for i in range(50):
        br2._put(100 + i, i)  # a flood of one-off contexts
    check(
        "M3  the eviction keeps the CORROBORATED entries, not the newest",
        1 in br2.store and len(br2.store) <= 4,
        f"the corroborated key survived: {1 in br2.store}  "
        f"(the store holds {len(br2.store)} of 4 allowed)",
    )

    # the DEFAULT gate must not overrule a confident base model
    m = TinyTransformer(32, d=32, n_layers=2, n_ctx=32, seed=0)
    br3 = SAABranch(M=16, r=4, d=32, emb=m.emb, ctx_len=1, seed=0)
    br3.Wo_exact.data = np.eye(32)
    br3.read_gain = "raw"
    br3.read_scale = 300.0
    br3.read_transform = "pc1"
    br3.refresh_contrast()
    seq = np.array([4, 21, 6, 30, 12, 17, 2, 25], dtype=np.int64)
    br3.reset()
    br3.forward(m.emb[seq] + m.pos[: len(seq)], m.emb[seq], seq)
    q = np.array([7, 19, 2], dtype=np.int64)
    h0 = m.emb[q] + m.pos[: len(q)]
    _, info = br3.forward(h0, m.emb[q], q)
    conf = np.full((3, 32), -10.0)
    conf[2, 5] = 10.0  # the base model is CERTAIN
    g = br3.gated_logits(conf, info)  # the DEFAULT settings
    check(
        "M3  by DEFAULT the gate never overrules a confident base model",
        int(g[-1].argmax()) == 5,
        f"argmax stayed {int(g[-1].argmax())} (the base was sure of 5); "
        f"the hard rules are OFF by default",
    )


# ==================================================================== 29
def test_router_tier():
    """The router tier: the fluid's geometry as an address space.

    "The fluid answers WHERE, the register answers WHAT" -- made literal:
    the exact tier answers when it has the context, and the per-anchor
    (router) tier is the FALLBACK, with the whole stream's reach.
    """
    print("\n[29] The router tier: the fluid as the address space")
    from superfluid.graft import SAABranch
    from superfluid.model import TinyTransformer

    m = TinyTransformer(32, d=32, n_layers=2, n_ctx=32, seed=0)
    br = SAABranch(M=16, r=4, d=32, emb=m.emb, ctx_len=1, use_router=True, seed=0)
    br.Wo_exact.data = np.eye(32)
    br.read_gain = "raw"
    br.read_scale = 300.0
    br.read_transform = "pc1"
    br.refresh_contrast()
    seq = np.array([4, 21, 6, 30, 12, 17, 2, 25], dtype=np.int64)
    br.reset()
    br.forward(m.emb[seq] + m.pos[: len(seq)], m.emb[seq], seq)
    check(
        "M3  the router tier files the pair under the ANCHOR of the previous position",
        len(br.anchor_store) > 0,
        f"{len(br.anchor_store)} anchors hold a majority continuation",
    )
    # the exact tier must win when it has the context
    q = np.array([7, 19, 2], dtype=np.int64)
    h0 = m.emb[q] + m.pos[: len(q)]
    _, info = br.forward(h0, m.emb[q], q)
    check(
        "M3  the exact tier wins when it has the context",
        int(info["retrieved"][-1]) == 25 and int(info["router_retrieved"][-1]) != 25,
        f"exact {int(info['retrieved'][-1])}, router "
        f"{int(info['router_retrieved'][-1])}",
    )
    # and the fallback chain: the router answers when the exact tier misses
    miss = {
        "retrieved": np.array([-1]),
        "confidence": np.array([0.0]),
        "router_retrieved": np.array([9]),
        "router_confidence": np.array([1.0]),
    }
    lg = br.gated_logits(np.zeros((1, 32)), miss, gain=8.0)
    check(
        "M3  the router tier is the FALLBACK when the exact tier misses",
        int(lg[0].argmax()) == 9,
        f"argmax {int(lg[0].argmax())} (the router's answer)",
    )


if __name__ == "__main__":
    print("=" * 78)
    print("SUPERFLUID SELFTEST — verifying the proposal's mathematical claims")
    print("=" * 78)
    test_jamming()
    test_chebyshev()
    test_linear_collapse()
    rank = test_rank_c_trap()
    test_g_balance()
    test_contraction()
    test_frame_property()
    test_autodiff()
    test_persistence()
    test_block_laplacian()
    test_band_stability()
    test_register()
    test_override_and_budget()
    test_constant_state()
    test_frustration()
    test_hodge_edge_participation()
    test_graft()
    test_gate()
    test_exact_memory()
    test_router_tier()

    n_pass = sum(r["pass"] for r in RESULTS)
    print("\n" + "=" * 78)
    print(f"RESULT: {n_pass}/{len(RESULTS)} checks passed")
    print("=" * 78)
    with open(os.path.join(OUT, "selftest.json"), "w") as f:
        json.dump(
            {
                "checks": RESULTS,
                "rank_trap": rank,
                "n_pass": n_pass,
                "n_total": len(RESULTS),
                "groups": {
                    "P": "propositions",
                    "W2": "warnings",
                    "M1": "frozen register",
                    "M2": "override + budget",
                    "M3": "memory geometry",
                },
            },
            f,
            indent=2,
        )
    sys.exit(0 if n_pass == len(RESULTS) else 1)

'''


def _build_package():
    package = types.ModuleType("superfluid")
    package.__path__ = []
    package.__package__ = "superfluid"
    sys.modules["superfluid"] = package
    blocks = {}
    current = None
    for line in _SOURCES.splitlines():
        if line.startswith("#--- FILE: "):
            current = line[len("#--- FILE: "):].split(" ---")[0].strip()
            blocks[current] = []
        elif current is not None:
            blocks[current].append(line)

    module_paths = [path for path in blocks if path.endswith(".py")]
    module_paths.sort(key=lambda path: path.endswith("/__init__.py"))
    for path in module_paths:
        if path == "selftest.py":
            continue
        if path.endswith("/__init__.py"):
            exec(compile("\n".join(blocks[path]), path, "exec"), package.__dict__)
            continue
        name = path.rsplit("/", 1)[-1][:-3]
        module = types.ModuleType(f"superfluid.{name}")
        module.__package__ = "superfluid"
        module.__file__ = path
        sys.modules[module.__name__] = module
        exec(compile("\n".join(blocks[path]), path, "exec"), module.__dict__)
        setattr(package, name, module)
    return package, blocks


_package, _blocks = _build_package()
globals().update({name: getattr(_package, name) for name in _package.__all__})

__version__ = _package.__version__


def _run_selftest():
    source = "\n".join(_blocks["selftest.py"])
    namespace = {"__name__": "__main__", "__file__": "selftest.py"}
    sys.path.insert(0, os.getcwd())
    try:
        exec(compile(source, "selftest.py", "exec"), namespace)
    except SystemExit as error:
        return int(error.code or 0)
    return 0


if __name__ == "__main__":
    if "--selftest" in sys.argv or len(sys.argv) == 1:
        sys.exit(_run_selftest())
