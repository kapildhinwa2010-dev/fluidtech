#!/usr/bin/env python3
"""
train.py — the empirical A/B for the Superfluid framework.

Experiment 1 (headline): character-level language modelling on a real corpus
(Project Gutenberg), SuperfluidLM vs a param-matched TinyTransformer, same
tokens, same optimiser, same schedule.  Records train/val loss curves, wall
clock and the model's *internal geometry diagnostics* (spectral gap, G-balance
residual, band energies, topological descriptor) so you can watch the fluid
"jam" during training.

Experiment 2 (mechanism): a global-aggregation task whose answer is exactly
the quantity the Hodge limit computes (the mean over the sequence).  Compares
Superfluid (global diffusion) vs TinyTransformer (global attention) vs a
LocalMLP with a fixed receptive field (cannot see the whole sequence).
This isolates "global geometry in ONE pass".

Usage:  python3 train.py [--steps 600] [--d 64] [--layers 2] [--ctx 64] [--batch 16]
"""

import json
import os
import sys
import time
import argparse

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from superfluid import SuperfluidLM, TinyTransformer, cross_entropy, cross_entropy_tensor
from superfluid.data import get_corpus, CharTokenizer
from superfluid.optim import Adam

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")
os.makedirs(OUT, exist_ok=True)


# --------------------------------------------------------------------- utils
def sample_batch(tokens, batch, ctx, rng):
    ix = rng.integers(0, len(tokens) - ctx - 1, size=batch)
    x = np.stack([tokens[i:i + ctx] for i in ix])
    y = np.stack([tokens[i + 1:i + 1 + ctx] for i in ix])
    return x, y


def count_params(model):
    return int(sum(p.data.size for p in model.params().values()))


def zero_grads(params):
    for p in params.values():
        p.grad = np.zeros_like(p.data)


def train_model(model, tokens, val_tokens, steps, batch, ctx, lr, seed, log_every,
                name, diag_every=0):
    rng = np.random.default_rng(seed)
    params = model.params()
    opt = Adam(params, lr=lr, betas=(0.9, 0.95), weight_decay=0.01, clip=1.0)
    curve, diags = [], []
    t0 = time.time()
    for step in range(steps):
        x, y = sample_batch(tokens, batch, ctx, rng)
        zero_grads(params)                 # <- BEFORE the forward pass
        logits = model.forward_batch(x)
        tgt = y.reshape(-1)
        loss = cross_entropy_tensor(logits, tgt)
        loss.backward()
        opt.step(opt.lr_at(step, steps))
        if step % log_every == 0 or step == steps - 1:
            vx, vy = sample_batch(val_tokens, 8, ctx, rng)
            with np.errstate(divide="ignore"):
                vl = cross_entropy(model.forward_batch(vx), vy.reshape(-1))
            curve.append({"step": step, "train": float(loss.data), "val": float(vl),
                          "lr": float(opt.lr_at(step, steps)),
                          "elapsed": round(time.time() - t0, 2)})
            print(f"    [{name}] step {step:>5}/{steps}  train {float(loss.data):.4f}  "
                  f"val {vl:.4f}  ({time.time()-t0:.1f}s)")
        if diag_every and (step % diag_every == 0):
            d = collect_diag(model)
            if d:
                diags.append({"step": step, **d})
    return curve, diags, round(time.time() - t0, 2)


def collect_diag(model):
    out = {}
    for i, b in enumerate(getattr(model, "blocks", [])):
        d = getattr(b, "diag", None)
        if not d:
            continue
        be = d.get("band_energy")
        out[f"block{i}"] = {
            "lam_max": round(d.get("lam_max", 0.0), 4),
            "balance_res": round(d.get("balance_res", 0.0), 4),
            "alpha_abs_mean": round(d.get("alpha_abs_mean", 0.0), 4),
            "alpha_neg_frac": round(d.get("alpha_neg_frac", 0.0), 4),
            "n_edges": d.get("n_edges", 0),
            "band_energy": [round(float(x), 4) for x in (be if be is not None else [])],
            "topo": [round(float(x), 3) for x in d.get("topo", [])],
        }
    return out


# --------------------------------------------------- experiment 2: global agg
class LocalMLP:
    """Causal MLP with a FIXED receptive field R (no global mixing)."""

    def __init__(self, vocab, d=64, R=8, n_layers=2, seed=0):
        rng = np.random.default_rng(seed)
        self.vocab, self.d, self.R = vocab, d, R
        self.emb = _T(rng.normal(0, 0.02, (vocab, d)))
        self.blocks = []
        for _ in range(n_layers):
            self.blocks.append({
                "W1": _T(rng.normal(0, d ** -0.5, (d, 4 * d))),
                "W2": _T(rng.normal(0, (4 * d) ** -0.5, (4 * d, d))),
                "b1": _T(np.zeros((1, 4 * d))),
                "b2": _T(np.zeros((1, d))),
                "g": _T(np.ones(d)),
            })
        self.out = _T(rng.normal(0, d ** -0.5, (d, vocab)))

    def forward(self, idx):
        idx = np.asarray(idx, dtype=np.int64)
        n = idx.shape[0]
        h = self.emb[idx]
        R = self.R
        for L in self.blocks:
            hd = h.data
            pad = np.concatenate([np.zeros((R, hd.shape[1])), hd], axis=0)
            ctx = _T(np.stack([pad[i:i + R] for i in range(n)]))   # (n, R, d)
            c = ctx.mean(axis=1)                               # local aggregate only
            z = (c @ L["W1"] + L["b1"]).gelu() @ L["W2"] + L["b2"]
            h = h + z * L["g"]
        return h @ self.out

    def forward_batch(self, x):
        from superfluid.autodiff import concat
        outs = [self.forward(x[b]) for b in range(x.shape[0])]
        return concat(outs, axis=0)

    def params(self):
        p = {"emb": self.emb, "out": self.out}
        for i, L in enumerate(self.blocks):
            for k, v in L.items():
                p[f"b{i}.{k}"] = v
        return p


def _T(a):
    from superfluid.autodiff import Tensor
    return Tensor(a)


def run_global_agg(steps, d, layers, ctx, batch, seed=0, ctx_agg=None, batch_agg=None):
    """Label = bucket of the sequence mean; only global models can solve it."""
    rng = np.random.default_rng(seed)
    V = 8                 # input token types
    NB = 8                # label buckets
    ctx = ctx_agg or ctx
    batch = batch_agg or batch
    ntrain, nval = 8000, 1000

    def make(n):
        seq = rng.integers(0, V, size=(n, ctx))
        mean = seq.mean(axis=1)
        lab = np.clip((mean / (V - 1) * NB).astype(np.int64), 0, NB - 1)
        return seq, lab

    Xtr, Ytr = make(ntrain)
    Xva, Yva = make(nval)
    results = {}
    models = {
        "Superfluid": SuperfluidLM(vocab=V + NB, d=d, n_layers=layers, n_ctx=ctx,
                                   k_neighbors=6, bands=5, cheb_m=10, seed=seed),
        "Transformer": TinyTransformer(vocab=V + NB, d=d, n_layers=layers, n_ctx=ctx,
                                       n_heads=4, seed=seed),
        "LocalMLP(R=8)": LocalMLP(vocab=V + NB, d=d, R=8, n_layers=layers, seed=seed),
    }
    for name, model in models.items():
        params = model.params()
        opt = Adam(params, lr=2e-3, betas=(0.9, 0.95), weight_decay=0.0, clip=1.0)
        accs = []
        for step in range(steps):
            ix = rng.integers(0, ntrain, size=batch)
            zero_grads(params)
            x = Xtr[ix].reshape(-1)
            y = Ytr[ix]
            # multi-task: predict the bucket at every position from a causal prefix
            logits = model.forward_batch(Xtr[ix])
            lg = logits.data.reshape(len(ix), ctx, -1)[:, -1, :]
            from superfluid.autodiff import Tensor
            loss = cross_entropy_tensor(Tensor(lg), y + V)
            loss.backward()
            zero_grads(params)
            opt.step(opt.lr_at(step, steps))
        # eval on the full-sequence mean bucket
        correct = 0
        with np.errstate(divide="ignore"):
            for s in range(0, nval, 64):
                xb = Xva[s:s + 64].reshape(-1)
                lg = model.forward_batch(Xva[s:s+64]).data
                lg = lg.reshape(len(Xva[s:s + 64]), ctx, -1)[:, -1, :]
                pred = lg.argmax(axis=1) - V
                correct += int((pred == Yva[s:s + 64]).sum())
        acc = correct / nval
        results[name] = {"val_acc": acc, "params": count_params(model)}
        print(f"    [global-agg] {name:<16} val acc = {acc*100:.1f}%  "
              f"(params {count_params(model)})")
    return results


# ------------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--steps", type=int, default=500)
    ap.add_argument("--d", type=int, default=64)
    ap.add_argument("--layers", type=int, default=2)
    ap.add_argument("--ctx", type=int, default=64)
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--lr", type=float, default=3e-3)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--skip-lm", action="store_true")
    ap.add_argument("--only-agg", action="store_true")
    ap.add_argument("--agg-steps", type=int, default=600)
    ap.add_argument("--agg-ctx", type=int, default=32)
    ap.add_argument("--agg-batch", type=int, default=8)
    ap.add_argument("--skip-agg", action="store_true")
    args = ap.parse_args()

    print("=" * 78)
    print("SUPERFLUID FRAMEWORK — empirical A/B")
    print("=" * 78)
    out = {"config": vars(args), "lm": {}, "global_agg": {}}
    if args.only_agg:
        prev = os.path.join(OUT, "train_results.json")
        if os.path.exists(prev):
            with open(prev) as f:
                out = json.load(f)

    if not args.skip_lm and not args.only_agg:
        print("\n[1] Character-level LM on Project Gutenberg (real text)")
        text = get_corpus(max_chars=120000)
        tok = CharTokenizer(text)
        ids = tok.encode(text)
        split = int(len(ids) * 0.95)
        train_ids, val_ids = ids[:split], ids[split:]
        print(f"    corpus: {len(text)} chars, vocab {tok.vocab}, "
              f"train {len(train_ids)} / val {len(val_ids)} tokens")
        models = {
            "Superfluid": SuperfluidLM(vocab=tok.vocab, d=args.d, n_layers=args.layers,
                                       n_ctx=args.ctx, k_neighbors=8, bands=6, cheb_m=12,
                                       seed=args.seed),
            "Transformer": TinyTransformer(vocab=tok.vocab, d=args.d, n_layers=args.layers,
                                          n_ctx=args.ctx, n_heads=4, seed=args.seed),
        }
        for name, model in models.items():
            print(f"  -> {name}  ({count_params(model)} params)")
            curve, diags, secs = train_model(
                model, train_ids, val_ids, args.steps, args.batch, args.ctx,
                args.lr, args.seed, log_every=max(1, args.steps // 10),
                name=name, diag_every=max(1, args.steps // 5))
            out["lm"][name] = {"curve": curve, "diags": diags, "seconds": secs,
                               "params": count_params(model)}
            with open(os.path.join(OUT, "train_results.json"), "w") as f:
                json.dump(out, f, indent=2)

    if not args.skip_agg:
        print("\n[2] Global-aggregation task (the quantity the Hodge limit computes)")
        out["global_agg"] = run_global_agg(args.agg_steps, args.d,
                                           args.layers, args.ctx, args.batch, args.seed,
                                           ctx_agg=args.agg_ctx, batch_agg=args.agg_batch)
        with open(os.path.join(OUT, "train_results.json"), "w") as f:
            json.dump(out, f, indent=2)

    path = os.path.join(OUT, "train_results.json")
    with open(path, "w") as f:
        json.dump(out, f, indent=2)
    print(f"\nsaved -> {path}")


if __name__ == "__main__":
    main()
