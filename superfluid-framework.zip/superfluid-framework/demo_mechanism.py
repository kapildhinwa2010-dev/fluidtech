#!/usr/bin/env python3
"""
demo_mechanism.py — a decisive test of the one architectural claim that matters:

    "the fluid computes a GLOBAL geometric statistic in ONE pass."

Design (deliberately minimal, so only the aggregator differs between arms):

  * input        : x_i = value_i * w   with a FIXED random unit vector w in R^d
                   -> the only information in the sequence is its scalar values
  * target       : the mean of the values (a global, order-invariant statistic)
  * aggregator   : one of three mechanisms
                     (a) SUPERFLUID  -- the sheaf diffusion block (global mixing)
                     (b) ATTENTION   -- standard causal self-attention (global mixing)
                     (c) LOCAL(R)    -- causal mean over the last R tokens only
  * head         : a trainable linear map d -> 1 (predict the mean)
  * metric       : sign accuracy of the predicted mean vs. the true mean,
                   and RMSE of the regression

Nothing else is trainable, so any difference in the result is attributable to
the aggregation mechanism alone.  This is the cleanest possible test of the
"global geometry in one pass" claim -- and of whether the fluid's aggregation
is genuinely global.
"""

import json
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from superfluid.autodiff import Tensor, softmax_rows, concat
from superfluid.blocks import SuperfluidBlock
from superfluid.optim import Adam

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")
os.makedirs(OUT, exist_ok=True)


class FluidAggregator:
    """SuperfluidBlock as a pure global aggregator (fixed input features)."""

    def __init__(self, d=48, seed=0, **kw):
        self.block = SuperfluidBlock(d, seed=seed, **kw)

    def __call__(self, x):                 # x: (n, d) Tensor
        return self.block(x)

    def params(self):
        from superfluid.model import _collect
        p = {}
        _collect(self.block, "blk", p)
        _collect(self.block.norm, "blk.norm", p)
        return p


class AttentionAggregator:
    """Standard causal self-attention, one layer, as the global aggregator."""

    def __init__(self, d=48, seed=0):
        rng = np.random.default_rng(seed)
        s = d ** -0.5
        self.Wq = Tensor(rng.normal(0, s, (d, d)))
        self.Wk = Tensor(rng.normal(0, s, (d, d)))
        self.Wv = Tensor(rng.normal(0, s, (d, d)))
        self.Wo = Tensor(rng.normal(0, s, (d, d)))
        self.g = Tensor(np.ones(d))

    def __call__(self, x):
        n = x.shape[0]
        xn = x * self.g
        q = xn @ self.Wq
        k = xn @ self.Wk
        v = xn @ self.Wv
        sc = (q @ k.T) * (x.shape[1] ** -0.5)
        causal = np.triu(np.ones((n, n), dtype=bool), k=1)
        a = softmax_rows(sc, mask=causal)
        return a @ v @ self.Wo

    def params(self):
        return {"Wq": self.Wq, "Wk": self.Wk, "Wv": self.Wv, "Wo": self.Wo, "g": self.g}


class LocalAggregator:
    """Causal mean over the last R tokens: a strictly local aggregator."""

    def __init__(self, d=48, R=4, seed=0):
        self.R = R
        self.g = Tensor(np.ones(d))

    def __call__(self, x):
        n = x.shape[0]
        hd = x.data
        pad = np.concatenate([np.zeros((self.R, hd.shape[1])), hd], axis=0)
        ctx = np.stack([pad[i:i + self.R] for i in range(n)])
        return Tensor(ctx.mean(axis=1)) * self.g

    def params(self):
        return {"g": self.g}


def apply_agg(agg, x3):
    """Apply a sequence aggregator to a batch of sequences (loop over batch)."""
    outs = [agg(Tensor(x3[b])) for b in range(x3.shape[0])]
    return concat(outs, axis=0)


def run(name, agg, d, steps, batch, ctx, Xtr, Ytr, Xva, Yva, lr=5e-3, seed=0):
    rng = np.random.default_rng(seed)
    head_w = Tensor(np.random.default_rng(seed + 1).normal(0, d ** -0.5, (d, 1)))
    head_b = Tensor(np.zeros((1, 1)))
    params = dict(agg.params())
    params["head_w"] = head_w
    params["head_b"] = head_b
    opt = Adam(params, lr=lr, betas=(0.9, 0.95), weight_decay=0.0, clip=1.0)
    t0 = time.time()
    for step in range(steps):
        ix = rng.integers(0, len(Xtr), size=batch)
        for p in params.values():
            p.grad = np.zeros_like(p.data)
        h = apply_agg(agg, Xtr[ix])
        pred = (h @ head_w + head_b).reshape(batch, ctx)[:, -1]   # last position only
        tgt = Tensor(Ytr[ix])
        loss = ((pred - tgt) ** 2).mean()
        loss.backward()
        opt.step(opt.lr_at(step, steps))
    # eval on the LAST position (the only position where the full prefix is visible)
    hs, ps, ts = [], [], []
    for s in range(0, len(Xva), 64):
        xb = Xva[s:s + 64]
        h = apply_agg(agg, xb)
        pr = (h @ head_w + head_b).data.reshape(len(xb), -1)[:, -1]
        hs.append(pr)
        ts.append(Yva[s:s + 64])
    pred = np.concatenate(hs)
    true = np.concatenate(ts)
    sign_acc = float(((pred > 0) == (true > 0)).mean())
    rmse = float(np.sqrt(((pred - true) ** 2).mean()))
    base = float(np.sqrt(((true - true.mean()) ** 2).mean()))   # constant-mean baseline RMSE
    print(f"    {name:<26} sign acc = {sign_acc*100:5.1f}%   RMSE = {rmse:.3f}  "
          f"(constant baseline {base:.3f})   [{time.time()-t0:.0f}s]")
    return {"name": name, "sign_acc": sign_acc, "rmse": rmse,
            "baseline_rmse": base, "seconds": round(time.time() - t0, 1)}


def main():
    steps = int(sys.argv[1]) if len(sys.argv) > 1 else 400
    ctx = 24
    d = 48
    rng = np.random.default_rng(0)
    w = rng.normal(0, 1, d)
    w /= np.linalg.norm(w)

    def make(n):
        vals = rng.uniform(-1, 1, size=(n, ctx))
        feats = vals[:, :, None] * w[None, None, :]
        return feats, vals.mean(axis=1)

    Xtr, Ytr = make(4000)
    Xva, Yva = make(1000)
    print("=" * 78)
    print("MECHANISM DEMO — can the aggregator compute a GLOBAL statistic in ONE pass?")
    print(f"    target = mean of {ctx} scalars; only the aggregation mechanism differs")
    print("=" * 78)
    results = []
    results.append(run("SUPERFLUID (fluid)", FluidAggregator(d, seed=0, k_neighbors=6,
                                                             bands=5, cheb_m=10),
                       d, steps, 16, ctx, Xtr, Ytr, Xva, Yva))
    results.append(run("ATTENTION (causal)", AttentionAggregator(d, seed=0),
                       d, steps, 16, ctx, Xtr, Ytr, Xva, Yva))
    results.append(run("LOCAL (R=4)", LocalAggregator(d, R=4, seed=0),
                       d, steps, 16, ctx, Xtr, Ytr, Xva, Yva))
    results.append(run("LOCAL (R=8)", LocalAggregator(d, R=8, seed=0),
                       d, steps, 16, ctx, Xtr, Ytr, Xva, Yva))
    with open(os.path.join(OUT, "mechanism.json"), "w") as f:
        json.dump({"ctx": ctx, "d": d, "steps": steps, "results": results}, f, indent=2)
    print("\nsaved -> results/mechanism.json")


if __name__ == "__main__":
    main()
