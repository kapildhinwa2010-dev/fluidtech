# Changelog

All notable changes to this project are documented here.
The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.2.0] — 2026-10-29

### Added
- **the real-model experiment** (E14): `superfluid/gpt2_model.py` (a GPT-2
  forward pass in PyTorch, no `transformers` needed) and
  `superfluid/gpt2_tokenizer.py` (the GPT-2 byte-level BPE in pure Python).
  The graft on **real GPT-2 (124M)**: the attach is bit-identical, a fact
  planted 2,947 tokens before the query is recalled exactly, and the
  perplexity improves by 0.027 nats.  The honest caveat: on a strong model
  the kNN-LM interpolation beats the gated override on perplexity.
- **the gate is now scale-free**: `u = -log p_max` (nats) instead of
  `1 - p_max`, because a probability-space gain means different things on
  models whose logits span ±2 and ±20.
- **the kNN-LM baseline** (E13): the comparison against the closest prior
  art, which this repository had been missing.  With a **16 KB** store the
  gated layer beats the interpolation by **7.4×** on the loss; with a 1 MB
  store the kNN-LM wins by 6.4×.  The claim is now precise: **the gate is
  the contribution under a hard memory budget**.
- **`docs/COMPARISON.md`** now covers kNN-LM, RETRO and REALM.
- **the ROUTER tier** (E12): the fluid's M anchors are used as an address
  space, each anchor holding the majority continuation of the contexts
  routed to it.  The exact tier wins when it has the context; the router
  tier is the fallback.  Measured: it rescues the recall when the exact
  store is too small (**0.100 → 0.625**) and fixes the hard contexts where
  the base model has no idea (**+0.053 → −0.071 nats**), at 0.0005 % of a
  transformer's compute per token.  This finally gives the diffusion tier
  a measured job.
- **`experiments/e12_router.py`** — the router benchmark.
- **the exact memory** (E11): the store keeps the **majority** continuation
  of a context and counts the corroboration (a confidence for free), the
  eviction drops the **least corroborated** entry rather than the oldest,
  and the gate's two hard rules are available but **off by default**
  because both were measured to hurt.  Result: the cross-window recall
  **1.000**, the common-context case **1.000** (was 0/3), the corroborated
  entries survive the eviction (**40/40**), and the base model's perplexity
  improves to **11.78**.
- **`experiments/e11_exact.py`** — the exact-memory benchmark.
- **`SAABranch.gated_logits`** — the GATE: the base model's own uncertainty
  (`u = 1 - max p`) scales the retrieval's logit boost, so one knob serves
  both use cases.  Measured (E10): the cross-window recall is **unchanged
  (0.975)** and the base model's perplexity **improves** from 13.61 to
  **11.78** — where the ungated layer cost **+1.08 nats** at the same
  gain.  The torch twin has it too.
- **`experiments/e10_gate.py`** — the gate benchmark: the recall task, the
  generation task, and the (recall, harm) frontier.
- **`experiments/e9_ten_million.py`** — what happens at ten million tokens:
  the footprint, what the memory can still reach, and the gain tension
  that the gate then solved.
- **`tools/bpe.py`** — a byte-level BPE tokenizer in pure Python, so every
  measurement can be repeated at a realistic token granularity.
- **`superfluid/graft.py`** — the attachable memory layer.  One residual-stream
  insertion, two tiers (a lossy diffusion state and an exact, content-keyed
  store of token ids).  Attaching it is a **provable no-op**: the output
  projections start at zero, so the logits are bit-identical.
- **`superfluid/torch_graft.py`** — the same layer in PyTorch, for attaching
  to a real pretrained LLM.  *Not executed in the development sandbox.*
- **`superfluid/toplevel`-level API**: `SAABranch`, `GRAFT_STATE_BYTES`,
  `ctx_hash` are exported from the package root.
- **`experiments/e6_graft.py`** — the graft benchmark: attach safety, the
  perplexity effect, and the cross-window verbatim-recall capability.
- **`experiments/e6_real_corpus.py`** — the same measurement on real English,
  with a `--tokenizer {char,bpe}` switch and a per-tier ablation.
- **`experiments/e7_lossy_fix.py`** — the fix for the diffusion tier's
  training signal (a layer-local objective and a differentiable state).
- **`experiments/gpu_graft.py`** — the GPU-scale driver for a real LLM.
- **`tools/bpe.py`** — a byte-level BPE tokenizer in pure Python (no
  downloads), so every measurement can be repeated at a realistic token
  granularity.
- **Six self-verification groups** covering the frozen register, the logit
  override, the budget law, the frustration index, the Hodge participation
  and the graft.

### Changed
- The selftest grew from 21 to **50 checks**.
- **`tools/fetch_pypi.py`** -- installs packages from PyPI when pip's index
  client cannot reach the index (this sandbox's proxy resets it); it
  verifies the sha256 and resumes truncated downloads.
- `TinyTransformer.forward` was split into `forward` + `forward_from_h` so a
  frozen model can be driven from a modified residual stream.
- The design documents moved to `docs/`.

### Fixed (all found by running the code)
- the `‖L·1‖∞` balance diagnostic was wrong for scalar signed sheaves (the
  frustration index is the right one — now verified on 150/150 random cycles);
- the per-anchor "last write wins" store was evicted by ordinary filler
  tokens, so the store is now **content-keyed**;
- an injection of a token's embedding is **not selective** when the readout is
  tied — the top principal direction of the embedding matrix is now projected
  out (`pc1`);
- `logit_override` now accepts a framework `Tensor`, not only an ndarray;
- the single-file bundle now includes the `graft` module.

### Measured results (all reproducible, see `docs/GRAFT.md`)
- attaching the layer: **bit-identical** logits (max diff 0.0);
- cross-window verbatim recall: **0.050 → 0.800** (chance 0.125), delivered
  entirely by the exact tier — the diffusion tier alone: 0.050;
- the diffusion tier, trained through the base model's loss, **degrades** the
  model it is attached to (**+0.81 nats** char level, **+0.98** subword);
- the fix removes the damage (**+0.0000**) but the tier still has no upside:
  the optimal injection gain is **zero**.

## [1.1.0]

- the frozen register (20 B per fact, bit-exact, append-only, fail-loud);
- the domain-prior artefact (`tools/pretrain_prior.py`);
- the E1/E2/E4/E5 experiments.

## [1.0.0]

- the first working framework: a pure-NumPy sheaf-diffusion LM with a
  21-check self-verification harness.
