---
name: Feature request
about: Suggest a capability the layer should have
title: "[feature] "
labels: enhancement
---

## What should the layer be able to do?

## Why it matters

<!-- what breaks today -->

## What you have measured

<!-- if you have run an experiment, please include it: a feature request
     backed by a measurement is much more likely to be accepted -->

## Alternatives you have considered
