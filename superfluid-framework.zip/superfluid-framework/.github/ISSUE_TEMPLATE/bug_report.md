---
name: Bug report
about: Something is wrong or the numbers do not match
title: "[bug] "
labels: bug
---

## What happened

<!-- the smallest description of the wrong behaviour -->

## How to reproduce

```python
# the smallest code that shows it
```

## What you expected

## What you got

## Environment

- python:
- numpy:
- commit / tag:
- CPU or GPU:

## Is this a measurement disagreement?

If the numbers in `docs/` do not match what you get, please paste the
command and the output. **Disagreements are the most valuable bug reports
this project can receive** — the whole point is that every number is
reproducible, so a mismatch is a bug in the code or in the documentation.
